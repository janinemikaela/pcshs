<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Icons / Boxicons - NiceAdmin Bootstrap Template</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="assets/img/favicon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.gstatic.com" rel="preconnect">
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Nunito:300,300i,400,400i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/quill/quill.snow.css" rel="stylesheet">
  <link href="assets/vendor/quill/quill.bubble.css" rel="stylesheet">
  <link href="assets/vendor/remixicon/remixicon.css" rel="stylesheet">
  <link href="assets/vendor/simple-datatables/style.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">

  <!-- =======================================================
  * Template Name: NiceAdmin
  * Updated: Sep 18 2023 with Bootstrap v5.3.2
  * Template URL: https://bootstrapmade.com/nice-admin-bootstrap-admin-html-template/
  * Author: BootstrapMade.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->
</head>

<body>

  <!-- ======= Header ======= -->
  <header id="header" class="header fixed-top d-flex align-items-center">

    <div class="d-flex align-items-center justify-content-between">
      <a href="index.html" class="logo d-flex align-items-center">
        <img src="assets/img/logo.png" alt="">
        <span class="d-none d-lg-block">NiceAdmin</span>
      </a>
      <i class="bi bi-list toggle-sidebar-btn"></i>
    </div><!-- End Logo -->

    <div class="search-bar">
      <form class="search-form d-flex align-items-center" method="POST" action="#">
        <input type="text" name="query" placeholder="Search" title="Enter search keyword">
        <button type="submit" title="Search"><i class="bi bi-search"></i></button>
      </form>
    </div><!-- End Search Bar -->

    <nav class="header-nav ms-auto">
      <ul class="d-flex align-items-center">

        <li class="nav-item d-block d-lg-none">
          <a class="nav-link nav-icon search-bar-toggle " href="#">
            <i class="bi bi-search"></i>
          </a>
        </li><!-- End Search Icon-->

        <li class="nav-item dropdown">

          <a class="nav-link nav-icon" href="#" data-bs-toggle="dropdown">
            <i class="bi bi-bell"></i>
            <span class="badge bg-primary badge-number">4</span>
          </a><!-- End Notification Icon -->

          <ul class="dropdown-menu dropdown-menu-end dropdown-menu-arrow notifications">
            <li class="dropdown-header">
              You have 4 new notifications
              <a href="#"><span class="badge rounded-pill bg-primary p-2 ms-2">View all</span></a>
            </li>
            <li>
              <hr class="dropdown-divider">
            </li>

            <li class="notification-item">
              <i class="bi bi-exclamation-circle text-warning"></i>
              <div>
                <h4>Lorem Ipsum</h4>
                <p>Quae dolorem earum veritatis oditseno</p>
                <p>30 min. ago</p>
              </div>
            </li>

            <li>
              <hr class="dropdown-divider">
            </li>

            <li class="notification-item">
              <i class="bi bi-x-circle text-danger"></i>
              <div>
                <h4>Atque rerum nesciunt</h4>
                <p>Quae dolorem earum veritatis oditseno</p>
                <p>1 hr. ago</p>
              </div>
            </li>

            <li>
              <hr class="dropdown-divider">
            </li>

            <li class="notification-item">
              <i class="bi bi-check-circle text-success"></i>
              <div>
                <h4>Sit rerum fuga</h4>
                <p>Quae dolorem earum veritatis oditseno</p>
                <p>2 hrs. ago</p>
              </div>
            </li>

            <li>
              <hr class="dropdown-divider">
            </li>

            <li class="notification-item">
              <i class="bi bi-info-circle text-primary"></i>
              <div>
                <h4>Dicta reprehenderit</h4>
                <p>Quae dolorem earum veritatis oditseno</p>
                <p>4 hrs. ago</p>
              </div>
            </li>

            <li>
              <hr class="dropdown-divider">
            </li>
            <li class="dropdown-footer">
              <a href="#">Show all notifications</a>
            </li>

          </ul><!-- End Notification Dropdown Items -->

        </li><!-- End Notification Nav -->

        <li class="nav-item dropdown">

          <a class="nav-link nav-icon" href="#" data-bs-toggle="dropdown">
            <i class="bi bi-chat-left-text"></i>
            <span class="badge bg-success badge-number">3</span>
          </a><!-- End Messages Icon -->

          <ul class="dropdown-menu dropdown-menu-end dropdown-menu-arrow messages">
            <li class="dropdown-header">
              You have 3 new messages
              <a href="#"><span class="badge rounded-pill bg-primary p-2 ms-2">View all</span></a>
            </li>
            <li>
              <hr class="dropdown-divider">
            </li>

            <li class="message-item">
              <a href="#">
                <img src="assets/img/messages-1.jpg" alt="" class="rounded-circle">
                <div>
                  <h4>Maria Hudson</h4>
                  <p>Velit asperiores et ducimus soluta repudiandae labore officia est ut...</p>
                  <p>4 hrs. ago</p>
                </div>
              </a>
            </li>
            <li>
              <hr class="dropdown-divider">
            </li>

            <li class="message-item">
              <a href="#">
                <img src="assets/img/messages-2.jpg" alt="" class="rounded-circle">
                <div>
                  <h4>Anna Nelson</h4>
                  <p>Velit asperiores et ducimus soluta repudiandae labore officia est ut...</p>
                  <p>6 hrs. ago</p>
                </div>
              </a>
            </li>
            <li>
              <hr class="dropdown-divider">
            </li>

            <li class="message-item">
              <a href="#">
                <img src="assets/img/messages-3.jpg" alt="" class="rounded-circle">
                <div>
                  <h4>David Muldon</h4>
                  <p>Velit asperiores et ducimus soluta repudiandae labore officia est ut...</p>
                  <p>8 hrs. ago</p>
                </div>
              </a>
            </li>
            <li>
              <hr class="dropdown-divider">
            </li>

            <li class="dropdown-footer">
              <a href="#">Show all messages</a>
            </li>

          </ul><!-- End Messages Dropdown Items -->

        </li><!-- End Messages Nav -->

        <li class="nav-item dropdown pe-3">

          <a class="nav-link nav-profile d-flex align-items-center pe-0" href="#" data-bs-toggle="dropdown">
            <img src="assets/img/profile-img.jpg" alt="Profile" class="rounded-circle">
            <span class="d-none d-md-block dropdown-toggle ps-2">K. Anderson</span>
          </a><!-- End Profile Iamge Icon -->

          <ul class="dropdown-menu dropdown-menu-end dropdown-menu-arrow profile">
            <li class="dropdown-header">
              <h6>Kevin Anderson</h6>
              <span>Web Designer</span>
            </li>
            <li>
              <hr class="dropdown-divider">
            </li>

            <li>
              <a class="dropdown-item d-flex align-items-center" href="users-profile.html">
                <i class="bi bi-person"></i>
                <span>My Profile</span>
              </a>
            </li>
            <li>
              <hr class="dropdown-divider">
            </li>

            <li>
              <a class="dropdown-item d-flex align-items-center" href="users-profile.html">
                <i class="bi bi-gear"></i>
                <span>Account Settings</span>
              </a>
            </li>
            <li>
              <hr class="dropdown-divider">
            </li>

            <li>
              <a class="dropdown-item d-flex align-items-center" href="pages-faq.html">
                <i class="bi bi-question-circle"></i>
                <span>Need Help?</span>
              </a>
            </li>
            <li>
              <hr class="dropdown-divider">
            </li>

            <li>
              <a class="dropdown-item d-flex align-items-center" href="#">
                <i class="bi bi-box-arrow-right"></i>
                <span>Sign Out</span>
              </a>
            </li>

          </ul><!-- End Profile Dropdown Items -->
        </li><!-- End Profile Nav -->

      </ul>
    </nav><!-- End Icons Navigation -->

  </header><!-- End Header -->

  <!-- ======= Sidebar ======= -->
  <aside id="sidebar" class="sidebar">

    <ul class="sidebar-nav" id="sidebar-nav">

      <li class="nav-item">
        <a class="nav-link collapsed" href="index.html">
          <i class="bi bi-grid"></i>
          <span>Dashboard</span>
        </a>
      </li><!-- End Dashboard Nav -->

      <li class="nav-item">
        <a class="nav-link collapsed" data-bs-target="#components-nav" data-bs-toggle="collapse" href="#">
          <i class="bi bi-menu-button-wide"></i><span>Components</span><i class="bi bi-chevron-down ms-auto"></i>
        </a>
        <ul id="components-nav" class="nav-content collapse " data-bs-parent="#sidebar-nav">
          <li>
            <a href="components-alerts.html">
              <i class="bi bi-circle"></i><span>Alerts</span>
            </a>
          </li>
          <li>
            <a href="components-accordion.html">
              <i class="bi bi-circle"></i><span>Accordion</span>
            </a>
          </li>
          <li>
            <a href="components-badges.html">
              <i class="bi bi-circle"></i><span>Badges</span>
            </a>
          </li>
          <li>
            <a href="components-breadcrumbs.html">
              <i class="bi bi-circle"></i><span>Breadcrumbs</span>
            </a>
          </li>
          <li>
            <a href="components-buttons.html">
              <i class="bi bi-circle"></i><span>Buttons</span>
            </a>
          </li>
          <li>
            <a href="components-cards.html">
              <i class="bi bi-circle"></i><span>Cards</span>
            </a>
          </li>
          <li>
            <a href="components-carousel.html">
              <i class="bi bi-circle"></i><span>Carousel</span>
            </a>
          </li>
          <li>
            <a href="components-list-group.html">
              <i class="bi bi-circle"></i><span>List group</span>
            </a>
          </li>
          <li>
            <a href="components-modal.html">
              <i class="bi bi-circle"></i><span>Modal</span>
            </a>
          </li>
          <li>
            <a href="components-tabs.html">
              <i class="bi bi-circle"></i><span>Tabs</span>
            </a>
          </li>
          <li>
            <a href="components-pagination.html">
              <i class="bi bi-circle"></i><span>Pagination</span>
            </a>
          </li>
          <li>
            <a href="components-progress.html">
              <i class="bi bi-circle"></i><span>Progress</span>
            </a>
          </li>
          <li>
            <a href="components-spinners.html">
              <i class="bi bi-circle"></i><span>Spinners</span>
            </a>
          </li>
          <li>
            <a href="components-tooltips.html">
              <i class="bi bi-circle"></i><span>Tooltips</span>
            </a>
          </li>
        </ul>
      </li><!-- End Components Nav -->

      <li class="nav-item">
        <a class="nav-link collapsed" data-bs-target="#forms-nav" data-bs-toggle="collapse" href="#">
          <i class="bi bi-journal-text"></i><span>Forms</span><i class="bi bi-chevron-down ms-auto"></i>
        </a>
        <ul id="forms-nav" class="nav-content collapse " data-bs-parent="#sidebar-nav">
          <li>
            <a href="forms-elements.html">
              <i class="bi bi-circle"></i><span>Form Elements</span>
            </a>
          </li>
          <li>
            <a href="forms-layouts.html">
              <i class="bi bi-circle"></i><span>Form Layouts</span>
            </a>
          </li>
          <li>
            <a href="forms-editors.html">
              <i class="bi bi-circle"></i><span>Form Editors</span>
            </a>
          </li>
          <li>
            <a href="forms-validation.html">
              <i class="bi bi-circle"></i><span>Form Validation</span>
            </a>
          </li>
        </ul>
      </li><!-- End Forms Nav -->

      <li class="nav-item">
        <a class="nav-link collapsed" data-bs-target="#tables-nav" data-bs-toggle="collapse" href="#">
          <i class="bi bi-layout-text-window-reverse"></i><span>Tables</span><i class="bi bi-chevron-down ms-auto"></i>
        </a>
        <ul id="tables-nav" class="nav-content collapse " data-bs-parent="#sidebar-nav">
          <li>
            <a href="tables-general.html">
              <i class="bi bi-circle"></i><span>General Tables</span>
            </a>
          </li>
          <li>
            <a href="tables-data.html">
              <i class="bi bi-circle"></i><span>Data Tables</span>
            </a>
          </li>
        </ul>
      </li><!-- End Tables Nav -->

      <li class="nav-item">
        <a class="nav-link collapsed" data-bs-target="#charts-nav" data-bs-toggle="collapse" href="#">
          <i class="bi bi-bar-chart"></i><span>Charts</span><i class="bi bi-chevron-down ms-auto"></i>
        </a>
        <ul id="charts-nav" class="nav-content collapse " data-bs-parent="#sidebar-nav">
          <li>
            <a href="charts-chartjs.html">
              <i class="bi bi-circle"></i><span>Chart.js</span>
            </a>
          </li>
          <li>
            <a href="charts-apexcharts.html">
              <i class="bi bi-circle"></i><span>ApexCharts</span>
            </a>
          </li>
          <li>
            <a href="charts-echarts.html">
              <i class="bi bi-circle"></i><span>ECharts</span>
            </a>
          </li>
        </ul>
      </li><!-- End Charts Nav -->

      <li class="nav-item">
        <a class="nav-link " data-bs-target="#icons-nav" data-bs-toggle="collapse" href="#">
          <i class="bi bi-gem"></i><span>Icons</span><i class="bi bi-chevron-down ms-auto"></i>
        </a>
        <ul id="icons-nav" class="nav-content collapse show" data-bs-parent="#sidebar-nav">
          <li>
            <a href="icons-bootstrap.html">
              <i class="bi bi-circle"></i><span>Bootstrap Icons</span>
            </a>
          </li>
          <li>
            <a href="icons-remix.html">
              <i class="bi bi-circle"></i><span>Remix Icons</span>
            </a>
          </li>
          <li>
            <a href="icons-boxicons.html" class="active">
              <i class="bi bi-circle"></i><span>Boxicons</span>
            </a>
          </li>
        </ul>
      </li><!-- End Icons Nav -->

      <li class="nav-heading">Pages</li>

      <li class="nav-item">
        <a class="nav-link collapsed" href="users-profile.html">
          <i class="bi bi-person"></i>
          <span>Profile</span>
        </a>
      </li><!-- End Profile Page Nav -->

      <li class="nav-item">
        <a class="nav-link collapsed" href="pages-faq.html">
          <i class="bi bi-question-circle"></i>
          <span>F.A.Q</span>
        </a>
      </li><!-- End F.A.Q Page Nav -->

      <li class="nav-item">
        <a class="nav-link collapsed" href="pages-contact.html">
          <i class="bi bi-envelope"></i>
          <span>Contact</span>
        </a>
      </li><!-- End Contact Page Nav -->

      <li class="nav-item">
        <a class="nav-link collapsed" href="pages-register.html">
          <i class="bi bi-card-list"></i>
          <span>Register</span>
        </a>
      </li><!-- End Register Page Nav -->

      <li class="nav-item">
        <a class="nav-link collapsed" href="pages-login.html">
          <i class="bi bi-box-arrow-in-right"></i>
          <span>Login</span>
        </a>
      </li><!-- End Login Page Nav -->

      <li class="nav-item">
        <a class="nav-link collapsed" href="pages-error-404.html">
          <i class="bi bi-dash-circle"></i>
          <span>Error 404</span>
        </a>
      </li><!-- End Error 404 Page Nav -->

      <li class="nav-item">
        <a class="nav-link collapsed" href="pages-blank.html">
          <i class="bi bi-file-earmark"></i>
          <span>Blank</span>
        </a>
      </li><!-- End Blank Page Nav -->

    </ul>

  </aside><!-- End Sidebar-->

  <main id="main" class="main">

    <div class="pagetitle">
      <h1>Boxicons</h1>
      <nav>
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="index.html">Home</a></li>
          <li class="breadcrumb-item">Icons</li>
          <li class="breadcrumb-item active">Boxicons</li>
        </ol>
      </nav>
    </div><!-- End Page Title -->

    <section class="section">
      <p>
        Use the following pattern to add the Boxicons icons to anywhere in your project. <code>&lt;i class=&quot;bx <strong>bxl-adobe</strong>&quot;&gt;&lt;/i&gt;</code> Replace the bold part with the below icon names.
        Check the <a href="https://boxicons.com/" target="_blank">Official website</a> for more info.
      </p>

      <div class="iconslist">

        <div class="icon">
          <i class="bx bxl-500px"></i>
          <div class="label">bxl-500px</div>
        </div>
        <div class="icon">
          <i class="bx bxl-adobe"></i>
          <div class="label">bxl-adobe</div>
        </div>
        <div class="icon">
          <i class="bx bxl-airbnb"></i>
          <div class="label">bxl-airbnb</div>
        </div>
        <div class="icon">
          <i class="bx bxl-algolia"></i>
          <div class="label">bxl-algolia</div>
        </div>
        <div class="icon">
          <i class="bx bxl-amazon"></i>
          <div class="label">bxl-amazon</div>
        </div>
        <div class="icon">
          <i class="bx bxl-android"></i>
          <div class="label">bxl-android</div>
        </div>
        <div class="icon">
          <i class="bx bxl-angular"></i>
          <div class="label">bxl-angular</div>
        </div>
        <div class="icon">
          <i class="bx bxl-apple"></i>
          <div class="label">bxl-apple</div>
        </div>
        <div class="icon">
          <i class="bx bxl-audible"></i>
          <div class="label">bxl-audible</div>
        </div>
        <div class="icon">
          <i class="bx bxl-aws"></i>
          <div class="label">bxl-aws</div>
        </div>
        <div class="icon">
          <i class="bx bxl-baidu"></i>
          <div class="label">bxl-baidu</div>
        </div>
        <div class="icon">
          <i class="bx bxl-behance"></i>
          <div class="label">bxl-behance</div>
        </div>
        <div class="icon">
          <i class="bx bxl-bing"></i>
          <div class="label">bxl-bing</div>
        </div>
        <div class="icon">
          <i class="bx bxl-bitcoin"></i>
          <div class="label">bxl-bitcoin</div>
        </div>
        <div class="icon">
          <i class="bx bxl-blender"></i>
          <div class="label">bxl-blender</div>
        </div>
        <div class="icon">
          <i class="bx bxl-blogger"></i>
          <div class="label">bxl-blogger</div>
        </div>
        <div class="icon">
          <i class="bx bxl-bootstrap"></i>
          <div class="label">bxl-bootstrap</div>
        </div>
        <div class="icon">
          <i class="bx bxl-chrome"></i>
          <div class="label">bxl-chrome</div>
        </div>
        <div class="icon">
          <i class="bx bxl-codepen"></i>
          <div class="label">bxl-codepen</div>
        </div>
        <div class="icon">
          <i class="bx bxl-c-plus-plus"></i>
          <div class="label">bxl-c-plus-plus</div>
        </div>
        <div class="icon">
          <i class="bx bxl-creative-commons"></i>
          <div class="label">bxl-creative-commons</div>
        </div>
        <div class="icon">
          <i class="bx bxl-css3"></i>
          <div class="label">bxl-css3</div>
        </div>
        <div class="icon">
          <i class="bx bxl-dailymotion"></i>
          <div class="label">bxl-dailymotion</div>
        </div>
        <div class="icon">
          <i class="bx bxl-deviantart"></i>
          <div class="label">bxl-deviantart</div>
        </div>
        <div class="icon">
          <i class="bx bxl-dev-to"></i>
          <div class="label">bxl-dev-to</div>
        </div>
        <div class="icon">
          <i class="bx bxl-digg"></i>
          <div class="label">bxl-digg</div>
        </div>
        <div class="icon">
          <i class="bx bxl-digitalocean"></i>
          <div class="label">bxl-digitalocean</div>
        </div>
        <div class="icon">
          <i class="bx bxl-discord"></i>
          <div class="label">bxl-discord</div>
        </div>
        <div class="icon">
          <i class="bx bxl-discord-alt"></i>
          <div class="label">bxl-discord-alt</div>
        </div>
        <div class="icon">
          <i class="bx bxl-discourse"></i>
          <div class="label">bxl-discourse</div>
        </div>
        <div class="icon">
          <i class="bx bxl-django"></i>
          <div class="label">bxl-django</div>
        </div>
        <div class="icon">
          <i class="bx bxl-docker"></i>
          <div class="label">bxl-docker</div>
        </div>
        <div class="icon">
          <i class="bx bxl-dribbble"></i>
          <div class="label">bxl-dribbble</div>
        </div>
        <div class="icon">
          <i class="bx bxl-dropbox"></i>
          <div class="label">bxl-dropbox</div>
        </div>
        <div class="icon">
          <i class="bx bxl-drupal"></i>
          <div class="label">bxl-drupal</div>
        </div>
        <div class="icon">
          <i class="bx bxl-ebay"></i>
          <div class="label">bxl-ebay</div>
        </div>
        <div class="icon">
          <i class="bx bxl-edge"></i>
          <div class="label">bxl-edge</div>
        </div>
        <div class="icon">
          <i class="bx bxl-etsy"></i>
          <div class="label">bxl-etsy</div>
        </div>
        <div class="icon">
          <i class="bx bxl-facebook"></i>
          <div class="label">bxl-facebook</div>
        </div>
        <div class="icon">
          <i class="bx bxl-facebook-circle"></i>
          <div class="label">bxl-facebook-circle</div>
        </div>
        <div class="icon">
          <i class="bx bxl-facebook-square"></i>
          <div class="label">bxl-facebook-square</div>
        </div>
        <div class="icon">
          <i class="bx bxl-figma"></i>
          <div class="label">bxl-figma</div>
        </div>
        <div class="icon">
          <i class="bx bxl-firebase"></i>
          <div class="label">bxl-firebase</div>
        </div>
        <div class="icon">
          <i class="bx bxl-firefox"></i>
          <div class="label">bxl-firefox</div>
        </div>
        <div class="icon">
          <i class="bx bxl-flickr"></i>
          <div class="label">bxl-flickr</div>
        </div>
        <div class="icon">
          <i class="bx bxl-flickr-square"></i>
          <div class="label">bxl-flickr-square</div>
        </div>
        <div class="icon">
          <i class="bx bxl-flutter"></i>
          <div class="label">bxl-flutter</div>
        </div>
        <div class="icon">
          <i class="bx bxl-foursquare"></i>
          <div class="label">bxl-foursquare</div>
        </div>
        <div class="icon">
          <i class="bx bxl-git"></i>
          <div class="label">bxl-git</div>
        </div>
        <div class="icon">
          <i class="bx bxl-github"></i>
          <div class="label">bxl-github</div>
        </div>
        <div class="icon">
          <i class="bx bxl-gitlab"></i>
          <div class="label">bxl-gitlab</div>
        </div>
        <div class="icon">
          <i class="bx bxl-google"></i>
          <div class="label">bxl-google</div>
        </div>
        <div class="icon">
          <i class="bx bxl-google-cloud"></i>
          <div class="label">bxl-google-cloud</div>
        </div>
        <div class="icon">
          <i class="bx bxl-google-plus"></i>
          <div class="label">bxl-google-plus</div>
        </div>
        <div class="icon">
          <i class="bx bxl-google-plus-circle"></i>
          <div class="label">bxl-google-plus-circle</div>
        </div>
        <div class="icon">
          <i class="bx bxl-html5"></i>
          <div class="label">bxl-html5</div>
        </div>
        <div class="icon">
          <i class="bx bxl-imdb"></i>
          <div class="label">bxl-imdb</div>
        </div>
        <div class="icon">
          <i class="bx bxl-instagram"></i>
          <div class="label">bxl-instagram</div>
        </div>
        <div class="icon">
          <i class="bx bxl-instagram-alt"></i>
          <div class="label">bxl-instagram-alt</div>
        </div>
        <div class="icon">
          <i class="bx bxl-internet-explorer"></i>
          <div class="label">bxl-internet-explorer</div>
        </div>
        <div class="icon">
          <i class="bx bxl-invision"></i>
          <div class="label">bxl-invision</div>
        </div>
        <div class="icon">
          <i class="bx bxl-javascript"></i>
          <div class="label">bxl-javascript</div>
        </div>
        <div class="icon">
          <i class="bx bxl-joomla"></i>
          <div class="label">bxl-joomla</div>
        </div>
        <div class="icon">
          <i class="bx bxl-jquery"></i>
          <div class="label">bxl-jquery</div>
        </div>
        <div class="icon">
          <i class="bx bxl-jsfiddle"></i>
          <div class="label">bxl-jsfiddle</div>
        </div>
        <div class="icon">
          <i class="bx bxl-kickstarter"></i>
          <div class="label">bxl-kickstarter</div>
        </div>
        <div class="icon">
          <i class="bx bxl-kubernetes"></i>
          <div class="label">bxl-kubernetes</div>
        </div>
        <div class="icon">
          <i class="bx bxl-less"></i>
          <div class="label">bxl-less</div>
        </div>
        <div class="icon">
          <i class="bx bxl-linkedin"></i>
          <div class="label">bxl-linkedin</div>
        </div>
        <div class="icon">
          <i class="bx bxl-linkedin-square"></i>
          <div class="label">bxl-linkedin-square</div>
        </div>
        <div class="icon">
          <i class="bx bxl-magento"></i>
          <div class="label">bxl-magento</div>
        </div>
        <div class="icon">
          <i class="bx bxl-mailchimp"></i>
          <div class="label">bxl-mailchimp</div>
        </div>
        <div class="icon">
          <i class="bx bxl-markdown"></i>
          <div class="label">bxl-markdown</div>
        </div>
        <div class="icon">
          <i class="bx bxl-mastercard"></i>
          <div class="label">bxl-mastercard</div>
        </div>
        <div class="icon">
          <i class="bx bxl-mastodon"></i>
          <div class="label">bxl-mastodon</div>
        </div>
        <div class="icon">
          <i class="bx bxl-medium"></i>
          <div class="label">bxl-medium</div>
        </div>
        <div class="icon">
          <i class="bx bxl-medium-old"></i>
          <div class="label">bxl-medium-old</div>
        </div>
        <div class="icon">
          <i class="bx bxl-medium-square"></i>
          <div class="label">bxl-medium-square</div>
        </div>
        <div class="icon">
          <i class="bx bxl-messenger"></i>
          <div class="label">bxl-messenger</div>
        </div>
        <div class="icon">
          <i class="bx bxl-microsoft"></i>
          <div class="label">bxl-microsoft</div>
        </div>
        <div class="icon">
          <i class="bx bxl-microsoft-teams"></i>
          <div class="label">bxl-microsoft-teams</div>
        </div>
        <div class="icon">
          <i class="bx bxl-nodejs"></i>
          <div class="label">bxl-nodejs</div>
        </div>
        <div class="icon">
          <i class="bx bxl-ok-ru"></i>
          <div class="label">bxl-ok-ru</div>
        </div>
        <div class="icon">
          <i class="bx bxl-opera"></i>
          <div class="label">bxl-opera</div>
        </div>
        <div class="icon">
          <i class="bx bxl-patreon"></i>
          <div class="label">bxl-patreon</div>
        </div>
        <div class="icon">
          <i class="bx bxl-paypal"></i>
          <div class="label">bxl-paypal</div>
        </div>
        <div class="icon">
          <i class="bx bxl-periscope"></i>
          <div class="label">bxl-periscope</div>
        </div>
        <div class="icon">
          <i class="bx bxl-php"></i>
          <div class="label">bxl-php</div>
        </div>
        <div class="icon">
          <i class="bx bxl-pinterest"></i>
          <div class="label">bxl-pinterest</div>
        </div>
        <div class="icon">
          <i class="bx bxl-pinterest-alt"></i>
          <div class="label">bxl-pinterest-alt</div>
        </div>
        <div class="icon">
          <i class="bx bxl-play-store"></i>
          <div class="label">bxl-play-store</div>
        </div>
        <div class="icon">
          <i class="bx bxl-pocket"></i>
          <div class="label">bxl-pocket</div>
        </div>
        <div class="icon">
          <i class="bx bxl-product-hunt"></i>
          <div class="label">bxl-product-hunt</div>
        </div>
        <div class="icon">
          <i class="bx bxl-python"></i>
          <div class="label">bxl-python</div>
        </div>
        <div class="icon">
          <i class="bx bxl-quora"></i>
          <div class="label">bxl-quora</div>
        </div>
        <div class="icon">
          <i class="bx bxl-react"></i>
          <div class="label">bxl-react</div>
        </div>
        <div class="icon">
          <i class="bx bxl-redbubble"></i>
          <div class="label">bxl-redbubble</div>
        </div>
        <div class="icon">
          <i class="bx bxl-reddit"></i>
          <div class="label">bxl-reddit</div>
        </div>
        <div class="icon">
          <i class="bx bxl-redux"></i>
          <div class="label">bxl-redux</div>
        </div>
        <div class="icon">
          <i class="bx bxl-sass"></i>
          <div class="label">bxl-sass</div>
        </div>
        <div class="icon">
          <i class="bx bxl-shopify"></i>
          <div class="label">bxl-shopify</div>
        </div>
        <div class="icon">
          <i class="bx bxl-sketch"></i>
          <div class="label">bxl-sketch</div>
        </div>
        <div class="icon">
          <i class="bx bxl-skype"></i>
          <div class="label">bxl-skype</div>
        </div>
        <div class="icon">
          <i class="bx bxl-slack"></i>
          <div class="label">bxl-slack</div>
        </div>
        <div class="icon">
          <i class="bx bxl-slack-old"></i>
          <div class="label">bxl-slack-old</div>
        </div>
        <div class="icon">
          <i class="bx bxl-snapchat"></i>
          <div class="label">bxl-snapchat</div>
        </div>
        <div class="icon">
          <i class="bx bxl-soundcloud"></i>
          <div class="label">bxl-soundcloud</div>
        </div>
        <div class="icon">
          <i class="bx bxl-spotify"></i>
          <div class="label">bxl-spotify</div>
        </div>
        <div class="icon">
          <i class="bx bxl-spring-boot"></i>
          <div class="label">bxl-spring-boot</div>
        </div>
        <div class="icon">
          <i class="bx bxl-squarespace"></i>
          <div class="label">bxl-squarespace</div>
        </div>
        <div class="icon">
          <i class="bx bxl-stack-overflow"></i>
          <div class="label">bxl-stack-overflow</div>
        </div>
        <div class="icon">
          <i class="bx bxl-steam"></i>
          <div class="label">bxl-steam</div>
        </div>
        <div class="icon">
          <i class="bx bxl-stripe"></i>
          <div class="label">bxl-stripe</div>
        </div>
        <div class="icon">
          <i class="bx bxl-tailwind-css"></i>
          <div class="label">bxl-tailwind-css</div>
        </div>
        <div class="icon">
          <i class="bx bxl-telegram"></i>
          <div class="label">bxl-telegram</div>
        </div>
        <div class="icon">
          <i class="bx bxl-tiktok"></i>
          <div class="label">bxl-tiktok</div>
        </div>
        <div class="icon">
          <i class="bx bxl-trello"></i>
          <div class="label">bxl-trello</div>
        </div>
        <div class="icon">
          <i class="bx bxl-trip-advisor"></i>
          <div class="label">bxl-trip-advisor</div>
        </div>
        <div class="icon">
          <i class="bx bxl-tumblr"></i>
          <div class="label">bxl-tumblr</div>
        </div>
        <div class="icon">
          <i class="bx bxl-tux"></i>
          <div class="label">bxl-tux</div>
        </div>
        <div class="icon">
          <i class="bx bxl-twitch"></i>
          <div class="label">bxl-twitch</div>
        </div>
        <div class="icon">
          <i class="bx bxl-twitter"></i>
          <div class="label">bxl-twitter</div>
        </div>
        <div class="icon">
          <i class="bx bxl-unity"></i>
          <div class="label">bxl-unity</div>
        </div>
        <div class="icon">
          <i class="bx bxl-unsplash"></i>
          <div class="label">bxl-unsplash</div>
        </div>
        <div class="icon">
          <i class="bx bxl-vimeo"></i>
          <div class="label">bxl-vimeo</div>
        </div>
        <div class="icon">
          <i class="bx bxl-visa"></i>
          <div class="label">bxl-visa</div>
        </div>
        <div class="icon">
          <i class="bx bxl-visual-studio"></i>
          <div class="label">bxl-visual-studio</div>
        </div>
        <div class="icon">
          <i class="bx bxl-vk"></i>
          <div class="label">bxl-vk</div>
        </div>
        <div class="icon">
          <i class="bx bxl-vuejs"></i>
          <div class="label">bxl-vuejs</div>
        </div>
        <div class="icon">
          <i class="bx bxl-whatsapp"></i>
          <div class="label">bxl-whatsapp</div>
        </div>
        <div class="icon">
          <i class="bx bxl-whatsapp-square"></i>
          <div class="label">bxl-whatsapp-square</div>
        </div>
        <div class="icon">
          <i class="bx bxl-wikipedia"></i>
          <div class="label">bxl-wikipedia</div>
        </div>
        <div class="icon">
          <i class="bx bxl-windows"></i>
          <div class="label">bxl-windows</div>
        </div>
        <div class="icon">
          <i class="bx bxl-wix"></i>
          <div class="label">bxl-wix</div>
        </div>
        <div class="icon">
          <i class="bx bxl-wordpress"></i>
          <div class="label">bxl-wordpress</div>
        </div>
        <div class="icon">
          <i class="bx bxl-yahoo"></i>
          <div class="label">bxl-yahoo</div>
        </div>
        <div class="icon">
          <i class="bx bxl-yelp"></i>
          <div class="label">bxl-yelp</div>
        </div>
        <div class="icon">
          <i class="bx bxl-youtube"></i>
          <div class="label">bxl-youtube</div>
        </div>
        <div class="icon">
          <i class="bx bxl-zoom"></i>
          <div class="label">bxl-zoom</div>
        </div>
        <div class="icon">
          <i class="bx bxs-add-to-queue"></i>
          <div class="label">bxs-add-to-queue</div>
        </div>
        <div class="icon">
          <i class="bx bxs-adjust"></i>
          <div class="label">bxs-adjust</div>
        </div>
        <div class="icon">
          <i class="bx bxs-adjust-alt"></i>
          <div class="label">bxs-adjust-alt</div>
        </div>
        <div class="icon">
          <i class="bx bxs-alarm"></i>
          <div class="label">bxs-alarm</div>
        </div>
        <div class="icon">
          <i class="bx bxs-alarm-add"></i>
          <div class="label">bxs-alarm-add</div>
        </div>
        <div class="icon">
          <i class="bx bxs-alarm-exclamation"></i>
          <div class="label">bxs-alarm-exclamation</div>
        </div>
        <div class="icon">
          <i class="bx bxs-alarm-off"></i>
          <div class="label">bxs-alarm-off</div>
        </div>
        <div class="icon">
          <i class="bx bxs-alarm-snooze"></i>
          <div class="label">bxs-alarm-snooze</div>
        </div>
        <div class="icon">
          <i class="bx bxs-album"></i>
          <div class="label">bxs-album</div>
        </div>
        <div class="icon">
          <i class="bx bxs-ambulance"></i>
          <div class="label">bxs-ambulance</div>
        </div>
        <div class="icon">
          <i class="bx bxs-analyse"></i>
          <div class="label">bxs-analyse</div>
        </div>
        <div class="icon">
          <i class="bx bxs-angry"></i>
          <div class="label">bxs-angry</div>
        </div>
        <div class="icon">
          <i class="bx bxs-arch"></i>
          <div class="label">bxs-arch</div>
        </div>
        <div class="icon">
          <i class="bx bxs-archive"></i>
          <div class="label">bxs-archive</div>
        </div>
        <div class="icon">
          <i class="bx bxs-archive-in"></i>
          <div class="label">bxs-archive-in</div>
        </div>
        <div class="icon">
          <i class="bx bxs-archive-out"></i>
          <div class="label">bxs-archive-out</div>
        </div>
        <div class="icon">
          <i class="bx bxs-area"></i>
          <div class="label">bxs-area</div>
        </div>
        <div class="icon">
          <i class="bx bxs-arrow-from-bottom"></i>
          <div class="label">bxs-arrow-from-bottom</div>
        </div>
        <div class="icon">
          <i class="bx bxs-arrow-from-left"></i>
          <div class="label">bxs-arrow-from-left</div>
        </div>
        <div class="icon">
          <i class="bx bxs-arrow-from-right"></i>
          <div class="label">bxs-arrow-from-right</div>
        </div>
        <div class="icon">
          <i class="bx bxs-arrow-from-top"></i>
          <div class="label">bxs-arrow-from-top</div>
        </div>
        <div class="icon">
          <i class="bx bxs-arrow-to-bottom"></i>
          <div class="label">bxs-arrow-to-bottom</div>
        </div>
        <div class="icon">
          <i class="bx bxs-arrow-to-left"></i>
          <div class="label">bxs-arrow-to-left</div>
        </div>
        <div class="icon">
          <i class="bx bxs-arrow-to-right"></i>
          <div class="label">bxs-arrow-to-right</div>
        </div>
        <div class="icon">
          <i class="bx bxs-arrow-to-top"></i>
          <div class="label">bxs-arrow-to-top</div>
        </div>
        <div class="icon">
          <i class="bx bxs-award"></i>
          <div class="label">bxs-award</div>
        </div>
        <div class="icon">
          <i class="bx bxs-baby-carriage"></i>
          <div class="label">bxs-baby-carriage</div>
        </div>
        <div class="icon">
          <i class="bx bxs-backpack"></i>
          <div class="label">bxs-backpack</div>
        </div>
        <div class="icon">
          <i class="bx bxs-badge"></i>
          <div class="label">bxs-badge</div>
        </div>
        <div class="icon">
          <i class="bx bxs-badge-check"></i>
          <div class="label">bxs-badge-check</div>
        </div>
        <div class="icon">
          <i class="bx bxs-badge-dollar"></i>
          <div class="label">bxs-badge-dollar</div>
        </div>
        <div class="icon">
          <i class="bx bxs-ball"></i>
          <div class="label">bxs-ball</div>
        </div>
        <div class="icon">
          <i class="bx bxs-band-aid"></i>
          <div class="label">bxs-band-aid</div>
        </div>
        <div class="icon">
          <i class="bx bxs-bank"></i>
          <div class="label">bxs-bank</div>
        </div>
        <div class="icon">
          <i class="bx bxs-bar-chart-alt-2"></i>
          <div class="label">bxs-bar-chart-alt-2</div>
        </div>
        <div class="icon">
          <i class="bx bxs-bar-chart-square"></i>
          <div class="label">bxs-bar-chart-square</div>
        </div>
        <div class="icon">
          <i class="bx bxs-barcode"></i>
          <div class="label">bxs-barcode</div>
        </div>
        <div class="icon">
          <i class="bx bxs-baseball"></i>
          <div class="label">bxs-baseball</div>
        </div>
        <div class="icon">
          <i class="bx bxs-basket"></i>
          <div class="label">bxs-basket</div>
        </div>
        <div class="icon">
          <i class="bx bxs-basketball"></i>
          <div class="label">bxs-basketball</div>
        </div>
        <div class="icon">
          <i class="bx bxs-bath"></i>
          <div class="label">bxs-bath</div>
        </div>
        <div class="icon">
          <i class="bx bxs-battery"></i>
          <div class="label">bxs-battery</div>
        </div>
        <div class="icon">
          <i class="bx bxs-battery-charging"></i>
          <div class="label">bxs-battery-charging</div>
        </div>
        <div class="icon">
          <i class="bx bxs-battery-full"></i>
          <div class="label">bxs-battery-full</div>
        </div>
        <div class="icon">
          <i class="bx bxs-battery-low"></i>
          <div class="label">bxs-battery-low</div>
        </div>
        <div class="icon">
          <i class="bx bxs-bed"></i>
          <div class="label">bxs-bed</div>
        </div>
        <div class="icon">
          <i class="bx bxs-been-here"></i>
          <div class="label">bxs-been-here</div>
        </div>
        <div class="icon">
          <i class="bx bxs-beer"></i>
          <div class="label">bxs-beer</div>
        </div>
        <div class="icon">
          <i class="bx bxs-bell"></i>
          <div class="label">bxs-bell</div>
        </div>
        <div class="icon">
          <i class="bx bxs-bell-minus"></i>
          <div class="label">bxs-bell-minus</div>
        </div>
        <div class="icon">
          <i class="bx bxs-bell-off"></i>
          <div class="label">bxs-bell-off</div>
        </div>
        <div class="icon">
          <i class="bx bxs-bell-plus"></i>
          <div class="label">bxs-bell-plus</div>
        </div>
        <div class="icon">
          <i class="bx bxs-bell-ring"></i>
          <div class="label">bxs-bell-ring</div>
        </div>
        <div class="icon">
          <i class="bx bxs-bible"></i>
          <div class="label">bxs-bible</div>
        </div>
        <div class="icon">
          <i class="bx bxs-binoculars"></i>
          <div class="label">bxs-binoculars</div>
        </div>
        <div class="icon">
          <i class="bx bxs-blanket"></i>
          <div class="label">bxs-blanket</div>
        </div>
        <div class="icon">
          <i class="bx bxs-bolt"></i>
          <div class="label">bxs-bolt</div>
        </div>
        <div class="icon">
          <i class="bx bxs-bolt-circle"></i>
          <div class="label">bxs-bolt-circle</div>
        </div>
        <div class="icon">
          <i class="bx bxs-bomb"></i>
          <div class="label">bxs-bomb</div>
        </div>
        <div class="icon">
          <i class="bx bxs-bone"></i>
          <div class="label">bxs-bone</div>
        </div>
        <div class="icon">
          <i class="bx bxs-bong"></i>
          <div class="label">bxs-bong</div>
        </div>
        <div class="icon">
          <i class="bx bxs-book"></i>
          <div class="label">bxs-book</div>
        </div>
        <div class="icon">
          <i class="bx bxs-book-add"></i>
          <div class="label">bxs-book-add</div>
        </div>
        <div class="icon">
          <i class="bx bxs-book-alt"></i>
          <div class="label">bxs-book-alt</div>
        </div>
        <div class="icon">
          <i class="bx bxs-book-bookmark"></i>
          <div class="label">bxs-book-bookmark</div>
        </div>
        <div class="icon">
          <i class="bx bxs-book-content"></i>
          <div class="label">bxs-book-content</div>
        </div>
        <div class="icon">
          <i class="bx bxs-book-heart"></i>
          <div class="label">bxs-book-heart</div>
        </div>
        <div class="icon">
          <i class="bx bxs-bookmark"></i>
          <div class="label">bxs-bookmark</div>
        </div>
        <div class="icon">
          <i class="bx bxs-bookmark-alt"></i>
          <div class="label">bxs-bookmark-alt</div>
        </div>
        <div class="icon">
          <i class="bx bxs-bookmark-alt-minus"></i>
          <div class="label">bxs-bookmark-alt-minus</div>
        </div>
        <div class="icon">
          <i class="bx bxs-bookmark-alt-plus"></i>
          <div class="label">bxs-bookmark-alt-plus</div>
        </div>
        <div class="icon">
          <i class="bx bxs-bookmark-heart"></i>
          <div class="label">bxs-bookmark-heart</div>
        </div>
        <div class="icon">
          <i class="bx bxs-bookmark-minus"></i>
          <div class="label">bxs-bookmark-minus</div>
        </div>
        <div class="icon">
          <i class="bx bxs-bookmark-plus"></i>
          <div class="label">bxs-bookmark-plus</div>
        </div>
        <div class="icon">
          <i class="bx bxs-bookmarks"></i>
          <div class="label">bxs-bookmarks</div>
        </div>
        <div class="icon">
          <i class="bx bxs-bookmark-star"></i>
          <div class="label">bxs-bookmark-star</div>
        </div>
        <div class="icon">
          <i class="bx bxs-book-open"></i>
          <div class="label">bxs-book-open</div>
        </div>
        <div class="icon">
          <i class="bx bxs-book-reader"></i>
          <div class="label">bxs-book-reader</div>
        </div>
        <div class="icon">
          <i class="bx bxs-bot"></i>
          <div class="label">bxs-bot</div>
        </div>
        <div class="icon">
          <i class="bx bxs-bowling-ball"></i>
          <div class="label">bxs-bowling-ball</div>
        </div>
        <div class="icon">
          <i class="bx bxs-box"></i>
          <div class="label">bxs-box</div>
        </div>
        <div class="icon">
          <i class="bx bxs-brain"></i>
          <div class="label">bxs-brain</div>
        </div>
        <div class="icon">
          <i class="bx bxs-briefcase"></i>
          <div class="label">bxs-briefcase</div>
        </div>
        <div class="icon">
          <i class="bx bxs-briefcase-alt"></i>
          <div class="label">bxs-briefcase-alt</div>
        </div>
        <div class="icon">
          <i class="bx bxs-briefcase-alt-2"></i>
          <div class="label">bxs-briefcase-alt-2</div>
        </div>
        <div class="icon">
          <i class="bx bxs-brightness"></i>
          <div class="label">bxs-brightness</div>
        </div>
        <div class="icon">
          <i class="bx bxs-brightness-half"></i>
          <div class="label">bxs-brightness-half</div>
        </div>
        <div class="icon">
          <i class="bx bxs-brush"></i>
          <div class="label">bxs-brush</div>
        </div>
        <div class="icon">
          <i class="bx bxs-brush-alt"></i>
          <div class="label">bxs-brush-alt</div>
        </div>
        <div class="icon">
          <i class="bx bxs-bug"></i>
          <div class="label">bxs-bug</div>
        </div>
        <div class="icon">
          <i class="bx bxs-bug-alt"></i>
          <div class="label">bxs-bug-alt</div>
        </div>
        <div class="icon">
          <i class="bx bxs-building"></i>
          <div class="label">bxs-building</div>
        </div>
        <div class="icon">
          <i class="bx bxs-building-house"></i>
          <div class="label">bxs-building-house</div>
        </div>
        <div class="icon">
          <i class="bx bxs-buildings"></i>
          <div class="label">bxs-buildings</div>
        </div>
        <div class="icon">
          <i class="bx bxs-bulb"></i>
          <div class="label">bxs-bulb</div>
        </div>
        <div class="icon">
          <i class="bx bxs-bullseye"></i>
          <div class="label">bxs-bullseye</div>
        </div>
        <div class="icon">
          <i class="bx bxs-buoy"></i>
          <div class="label">bxs-buoy</div>
        </div>
        <div class="icon">
          <i class="bx bxs-bus"></i>
          <div class="label">bxs-bus</div>
        </div>
        <div class="icon">
          <i class="bx bxs-business"></i>
          <div class="label">bxs-business</div>
        </div>
        <div class="icon">
          <i class="bx bxs-bus-school"></i>
          <div class="label">bxs-bus-school</div>
        </div>
        <div class="icon">
          <i class="bx bxs-cabinet"></i>
          <div class="label">bxs-cabinet</div>
        </div>
        <div class="icon">
          <i class="bx bxs-cake"></i>
          <div class="label">bxs-cake</div>
        </div>
        <div class="icon">
          <i class="bx bxs-calculator"></i>
          <div class="label">bxs-calculator</div>
        </div>
        <div class="icon">
          <i class="bx bxs-calendar"></i>
          <div class="label">bxs-calendar</div>
        </div>
        <div class="icon">
          <i class="bx bxs-calendar-alt"></i>
          <div class="label">bxs-calendar-alt</div>
        </div>
        <div class="icon">
          <i class="bx bxs-calendar-check"></i>
          <div class="label">bxs-calendar-check</div>
        </div>
        <div class="icon">
          <i class="bx bxs-calendar-edit"></i>
          <div class="label">bxs-calendar-edit</div>
        </div>
        <div class="icon">
          <i class="bx bxs-calendar-event"></i>
          <div class="label">bxs-calendar-event</div>
        </div>
        <div class="icon">
          <i class="bx bxs-calendar-exclamation"></i>
          <div class="label">bxs-calendar-exclamation</div>
        </div>
        <div class="icon">
          <i class="bx bxs-calendar-heart"></i>
          <div class="label">bxs-calendar-heart</div>
        </div>
        <div class="icon">
          <i class="bx bxs-calendar-minus"></i>
          <div class="label">bxs-calendar-minus</div>
        </div>
        <div class="icon">
          <i class="bx bxs-calendar-plus"></i>
          <div class="label">bxs-calendar-plus</div>
        </div>
        <div class="icon">
          <i class="bx bxs-calendar-star"></i>
          <div class="label">bxs-calendar-star</div>
        </div>
        <div class="icon">
          <i class="bx bxs-calendar-week"></i>
          <div class="label">bxs-calendar-week</div>
        </div>
        <div class="icon">
          <i class="bx bxs-calendar-x"></i>
          <div class="label">bxs-calendar-x</div>
        </div>
        <div class="icon">
          <i class="bx bxs-camera"></i>
          <div class="label">bxs-camera</div>
        </div>
        <div class="icon">
          <i class="bx bxs-camera-home"></i>
          <div class="label">bxs-camera-home</div>
        </div>
        <div class="icon">
          <i class="bx bxs-camera-movie"></i>
          <div class="label">bxs-camera-movie</div>
        </div>
        <div class="icon">
          <i class="bx bxs-camera-off"></i>
          <div class="label">bxs-camera-off</div>
        </div>
        <div class="icon">
          <i class="bx bxs-camera-plus"></i>
          <div class="label">bxs-camera-plus</div>
        </div>
        <div class="icon">
          <i class="bx bxs-capsule"></i>
          <div class="label">bxs-capsule</div>
        </div>
        <div class="icon">
          <i class="bx bxs-captions"></i>
          <div class="label">bxs-captions</div>
        </div>
        <div class="icon">
          <i class="bx bxs-car"></i>
          <div class="label">bxs-car</div>
        </div>
        <div class="icon">
          <i class="bx bxs-car-battery"></i>
          <div class="label">bxs-car-battery</div>
        </div>
        <div class="icon">
          <i class="bx bxs-car-crash"></i>
          <div class="label">bxs-car-crash</div>
        </div>
        <div class="icon">
          <i class="bx bxs-card"></i>
          <div class="label">bxs-card</div>
        </div>
        <div class="icon">
          <i class="bx bxs-caret-down-circle"></i>
          <div class="label">bxs-caret-down-circle</div>
        </div>
        <div class="icon">
          <i class="bx bxs-caret-down-square"></i>
          <div class="label">bxs-caret-down-square</div>
        </div>
        <div class="icon">
          <i class="bx bxs-caret-left-circle"></i>
          <div class="label">bxs-caret-left-circle</div>
        </div>
        <div class="icon">
          <i class="bx bxs-caret-left-square"></i>
          <div class="label">bxs-caret-left-square</div>
        </div>
        <div class="icon">
          <i class="bx bxs-caret-right-circle"></i>
          <div class="label">bxs-caret-right-circle</div>
        </div>
        <div class="icon">
          <i class="bx bxs-caret-right-square"></i>
          <div class="label">bxs-caret-right-square</div>
        </div>
        <div class="icon">
          <i class="bx bxs-caret-up-circle"></i>
          <div class="label">bxs-caret-up-circle</div>
        </div>
        <div class="icon">
          <i class="bx bxs-caret-up-square"></i>
          <div class="label">bxs-caret-up-square</div>
        </div>
        <div class="icon">
          <i class="bx bxs-car-garage"></i>
          <div class="label">bxs-car-garage</div>
        </div>
        <div class="icon">
          <i class="bx bxs-car-mechanic"></i>
          <div class="label">bxs-car-mechanic</div>
        </div>
        <div class="icon">
          <i class="bx bxs-carousel"></i>
          <div class="label">bxs-carousel</div>
        </div>
        <div class="icon">
          <i class="bx bxs-cart"></i>
          <div class="label">bxs-cart</div>
        </div>
        <div class="icon">
          <i class="bx bxs-cart-add"></i>
          <div class="label">bxs-cart-add</div>
        </div>
        <div class="icon">
          <i class="bx bxs-cart-alt"></i>
          <div class="label">bxs-cart-alt</div>
        </div>
        <div class="icon">
          <i class="bx bxs-cart-download"></i>
          <div class="label">bxs-cart-download</div>
        </div>
        <div class="icon">
          <i class="bx bxs-car-wash"></i>
          <div class="label">bxs-car-wash</div>
        </div>
        <div class="icon">
          <i class="bx bxs-category"></i>
          <div class="label">bxs-category</div>
        </div>
        <div class="icon">
          <i class="bx bxs-category-alt"></i>
          <div class="label">bxs-category-alt</div>
        </div>
        <div class="icon">
          <i class="bx bxs-cctv"></i>
          <div class="label">bxs-cctv</div>
        </div>
        <div class="icon">
          <i class="bx bxs-certification"></i>
          <div class="label">bxs-certification</div>
        </div>
        <div class="icon">
          <i class="bx bxs-chalkboard"></i>
          <div class="label">bxs-chalkboard</div>
        </div>
        <div class="icon">
          <i class="bx bxs-chart"></i>
          <div class="label">bxs-chart</div>
        </div>
        <div class="icon">
          <i class="bx bxs-chat"></i>
          <div class="label">bxs-chat</div>
        </div>
        <div class="icon">
          <i class="bx bxs-checkbox"></i>
          <div class="label">bxs-checkbox</div>
        </div>
        <div class="icon">
          <i class="bx bxs-checkbox-checked"></i>
          <div class="label">bxs-checkbox-checked</div>
        </div>
        <div class="icon">
          <i class="bx bxs-checkbox-minus"></i>
          <div class="label">bxs-checkbox-minus</div>
        </div>
        <div class="icon">
          <i class="bx bxs-check-circle"></i>
          <div class="label">bxs-check-circle</div>
        </div>
        <div class="icon">
          <i class="bx bxs-check-shield"></i>
          <div class="label">bxs-check-shield</div>
        </div>
        <div class="icon">
          <i class="bx bxs-check-square"></i>
          <div class="label">bxs-check-square</div>
        </div>
        <div class="icon">
          <i class="bx bxs-chess"></i>
          <div class="label">bxs-chess</div>
        </div>
        <div class="icon">
          <i class="bx bxs-chevron-down"></i>
          <div class="label">bxs-chevron-down</div>
        </div>
        <div class="icon">
          <i class="bx bxs-chevron-down-circle"></i>
          <div class="label">bxs-chevron-down-circle</div>
        </div>
        <div class="icon">
          <i class="bx bxs-chevron-down-square"></i>
          <div class="label">bxs-chevron-down-square</div>
        </div>
        <div class="icon">
          <i class="bx bxs-chevron-left"></i>
          <div class="label">bxs-chevron-left</div>
        </div>
        <div class="icon">
          <i class="bx bxs-chevron-left-circle"></i>
          <div class="label">bxs-chevron-left-circle</div>
        </div>
        <div class="icon">
          <i class="bx bxs-chevron-left-square"></i>
          <div class="label">bxs-chevron-left-square</div>
        </div>
        <div class="icon">
          <i class="bx bxs-chevron-right"></i>
          <div class="label">bxs-chevron-right</div>
        </div>
        <div class="icon">
          <i class="bx bxs-chevron-right-circle"></i>
          <div class="label">bxs-chevron-right-circle</div>
        </div>
        <div class="icon">
          <i class="bx bxs-chevron-right-square"></i>
          <div class="label">bxs-chevron-right-square</div>
        </div>
        <div class="icon">
          <i class="bx bxs-chevrons-down"></i>
          <div class="label">bxs-chevrons-down</div>
        </div>
        <div class="icon">
          <i class="bx bxs-chevrons-left"></i>
          <div class="label">bxs-chevrons-left</div>
        </div>
        <div class="icon">
          <i class="bx bxs-chevrons-right"></i>
          <div class="label">bxs-chevrons-right</div>
        </div>
        <div class="icon">
          <i class="bx bxs-chevrons-up"></i>
          <div class="label">bxs-chevrons-up</div>
        </div>
        <div class="icon">
          <i class="bx bxs-chevron-up"></i>
          <div class="label">bxs-chevron-up</div>
        </div>
        <div class="icon">
          <i class="bx bxs-chevron-up-circle"></i>
          <div class="label">bxs-chevron-up-circle</div>
        </div>
        <div class="icon">
          <i class="bx bxs-chevron-up-square"></i>
          <div class="label">bxs-chevron-up-square</div>
        </div>
        <div class="icon">
          <i class="bx bxs-chip"></i>
          <div class="label">bxs-chip</div>
        </div>
        <div class="icon">
          <i class="bx bxs-church"></i>
          <div class="label">bxs-church</div>
        </div>
        <div class="icon">
          <i class="bx bxs-circle"></i>
          <div class="label">bxs-circle</div>
        </div>
        <div class="icon">
          <i class="bx bxs-city"></i>
          <div class="label">bxs-city</div>
        </div>
        <div class="icon">
          <i class="bx bxs-clinic"></i>
          <div class="label">bxs-clinic</div>
        </div>
        <div class="icon">
          <i class="bx bxs-cloud"></i>
          <div class="label">bxs-cloud</div>
        </div>
        <div class="icon">
          <i class="bx bxs-cloud-download"></i>
          <div class="label">bxs-cloud-download</div>
        </div>
        <div class="icon">
          <i class="bx bxs-cloud-lightning"></i>
          <div class="label">bxs-cloud-lightning</div>
        </div>
        <div class="icon">
          <i class="bx bxs-cloud-rain"></i>
          <div class="label">bxs-cloud-rain</div>
        </div>
        <div class="icon">
          <i class="bx bxs-cloud-upload"></i>
          <div class="label">bxs-cloud-upload</div>
        </div>
        <div class="icon">
          <i class="bx bxs-coffee"></i>
          <div class="label">bxs-coffee</div>
        </div>
        <div class="icon">
          <i class="bx bxs-coffee-alt"></i>
          <div class="label">bxs-coffee-alt</div>
        </div>
        <div class="icon">
          <i class="bx bxs-coffee-togo"></i>
          <div class="label">bxs-coffee-togo</div>
        </div>
        <div class="icon">
          <i class="bx bxs-cog"></i>
          <div class="label">bxs-cog</div>
        </div>
        <div class="icon">
          <i class="bx bxs-coin"></i>
          <div class="label">bxs-coin</div>
        </div>
        <div class="icon">
          <i class="bx bxs-coin-stack"></i>
          <div class="label">bxs-coin-stack</div>
        </div>
        <div class="icon">
          <i class="bx bxs-collection"></i>
          <div class="label">bxs-collection</div>
        </div>
        <div class="icon">
          <i class="bx bxs-color-fill"></i>
          <div class="label">bxs-color-fill</div>
        </div>
        <div class="icon">
          <i class="bx bxs-comment"></i>
          <div class="label">bxs-comment</div>
        </div>
        <div class="icon">
          <i class="bx bxs-comment-add"></i>
          <div class="label">bxs-comment-add</div>
        </div>
        <div class="icon">
          <i class="bx bxs-comment-check"></i>
          <div class="label">bxs-comment-check</div>
        </div>
        <div class="icon">
          <i class="bx bxs-comment-detail"></i>
          <div class="label">bxs-comment-detail</div>
        </div>
        <div class="icon">
          <i class="bx bxs-comment-dots"></i>
          <div class="label">bxs-comment-dots</div>
        </div>
        <div class="icon">
          <i class="bx bxs-comment-edit"></i>
          <div class="label">bxs-comment-edit</div>
        </div>
        <div class="icon">
          <i class="bx bxs-comment-error"></i>
          <div class="label">bxs-comment-error</div>
        </div>
        <div class="icon">
          <i class="bx bxs-comment-minus"></i>
          <div class="label">bxs-comment-minus</div>
        </div>
        <div class="icon">
          <i class="bx bxs-comment-x"></i>
          <div class="label">bxs-comment-x</div>
        </div>
        <div class="icon">
          <i class="bx bxs-compass"></i>
          <div class="label">bxs-compass</div>
        </div>
        <div class="icon">
          <i class="bx bxs-component"></i>
          <div class="label">bxs-component</div>
        </div>
        <div class="icon">
          <i class="bx bxs-confused"></i>
          <div class="label">bxs-confused</div>
        </div>
        <div class="icon">
          <i class="bx bxs-contact"></i>
          <div class="label">bxs-contact</div>
        </div>
        <div class="icon">
          <i class="bx bxs-conversation"></i>
          <div class="label">bxs-conversation</div>
        </div>
        <div class="icon">
          <i class="bx bxs-cookie"></i>
          <div class="label">bxs-cookie</div>
        </div>
        <div class="icon">
          <i class="bx bxs-cool"></i>
          <div class="label">bxs-cool</div>
        </div>
        <div class="icon">
          <i class="bx bxs-copy"></i>
          <div class="label">bxs-copy</div>
        </div>
        <div class="icon">
          <i class="bx bxs-copy-alt"></i>
          <div class="label">bxs-copy-alt</div>
        </div>
        <div class="icon">
          <i class="bx bxs-copyright"></i>
          <div class="label">bxs-copyright</div>
        </div>
        <div class="icon">
          <i class="bx bxs-coupon"></i>
          <div class="label">bxs-coupon</div>
        </div>
        <div class="icon">
          <i class="bx bxs-credit-card"></i>
          <div class="label">bxs-credit-card</div>
        </div>
        <div class="icon">
          <i class="bx bxs-credit-card-alt"></i>
          <div class="label">bxs-credit-card-alt</div>
        </div>
        <div class="icon">
          <i class="bx bxs-credit-card-front"></i>
          <div class="label">bxs-credit-card-front</div>
        </div>
        <div class="icon">
          <i class="bx bxs-crop"></i>
          <div class="label">bxs-crop</div>
        </div>
        <div class="icon">
          <i class="bx bxs-crown"></i>
          <div class="label">bxs-crown</div>
        </div>
        <div class="icon">
          <i class="bx bxs-cube"></i>
          <div class="label">bxs-cube</div>
        </div>
        <div class="icon">
          <i class="bx bxs-cube-alt"></i>
          <div class="label">bxs-cube-alt</div>
        </div>
        <div class="icon">
          <i class="bx bxs-cuboid"></i>
          <div class="label">bxs-cuboid</div>
        </div>
        <div class="icon">
          <i class="bx bxs-customize"></i>
          <div class="label">bxs-customize</div>
        </div>
        <div class="icon">
          <i class="bx bxs-cylinder"></i>
          <div class="label">bxs-cylinder</div>
        </div>
        <div class="icon">
          <i class="bx bxs-dashboard"></i>
          <div class="label">bxs-dashboard</div>
        </div>
        <div class="icon">
          <i class="bx bxs-data"></i>
          <div class="label">bxs-data</div>
        </div>
        <div class="icon">
          <i class="bx bxs-detail"></i>
          <div class="label">bxs-detail</div>
        </div>
        <div class="icon">
          <i class="bx bxs-devices"></i>
          <div class="label">bxs-devices</div>
        </div>
        <div class="icon">
          <i class="bx bxs-diamond"></i>
          <div class="label">bxs-diamond</div>
        </div>
        <div class="icon">
          <i class="bx bxs-dice-1"></i>
          <div class="label">bxs-dice-1</div>
        </div>
        <div class="icon">
          <i class="bx bxs-dice-2"></i>
          <div class="label">bxs-dice-2</div>
        </div>
        <div class="icon">
          <i class="bx bxs-dice-3"></i>
          <div class="label">bxs-dice-3</div>
        </div>
        <div class="icon">
          <i class="bx bxs-dice-4"></i>
          <div class="label">bxs-dice-4</div>
        </div>
        <div class="icon">
          <i class="bx bxs-dice-5"></i>
          <div class="label">bxs-dice-5</div>
        </div>
        <div class="icon">
          <i class="bx bxs-dice-6"></i>
          <div class="label">bxs-dice-6</div>
        </div>
        <div class="icon">
          <i class="bx bxs-direction-left"></i>
          <div class="label">bxs-direction-left</div>
        </div>
        <div class="icon">
          <i class="bx bxs-direction-right"></i>
          <div class="label">bxs-direction-right</div>
        </div>
        <div class="icon">
          <i class="bx bxs-directions"></i>
          <div class="label">bxs-directions</div>
        </div>
        <div class="icon">
          <i class="bx bxs-disc"></i>
          <div class="label">bxs-disc</div>
        </div>
        <div class="icon">
          <i class="bx bxs-discount"></i>
          <div class="label">bxs-discount</div>
        </div>
        <div class="icon">
          <i class="bx bxs-dish"></i>
          <div class="label">bxs-dish</div>
        </div>
        <div class="icon">
          <i class="bx bxs-dislike"></i>
          <div class="label">bxs-dislike</div>
        </div>
        <div class="icon">
          <i class="bx bxs-dizzy"></i>
          <div class="label">bxs-dizzy</div>
        </div>
        <div class="icon">
          <i class="bx bxs-dock-bottom"></i>
          <div class="label">bxs-dock-bottom</div>
        </div>
        <div class="icon">
          <i class="bx bxs-dock-left"></i>
          <div class="label">bxs-dock-left</div>
        </div>
        <div class="icon">
          <i class="bx bxs-dock-right"></i>
          <div class="label">bxs-dock-right</div>
        </div>
        <div class="icon">
          <i class="bx bxs-dock-top"></i>
          <div class="label">bxs-dock-top</div>
        </div>
        <div class="icon">
          <i class="bx bxs-dollar-circle"></i>
          <div class="label">bxs-dollar-circle</div>
        </div>
        <div class="icon">
          <i class="bx bxs-donate-blood"></i>
          <div class="label">bxs-donate-blood</div>
        </div>
        <div class="icon">
          <i class="bx bxs-donate-heart"></i>
          <div class="label">bxs-donate-heart</div>
        </div>
        <div class="icon">
          <i class="bx bxs-door-open"></i>
          <div class="label">bxs-door-open</div>
        </div>
        <div class="icon">
          <i class="bx bxs-doughnut-chart"></i>
          <div class="label">bxs-doughnut-chart</div>
        </div>
        <div class="icon">
          <i class="bx bxs-down-arrow"></i>
          <div class="label">bxs-down-arrow</div>
        </div>
        <div class="icon">
          <i class="bx bxs-down-arrow-alt"></i>
          <div class="label">bxs-down-arrow-alt</div>
        </div>
        <div class="icon">
          <i class="bx bxs-down-arrow-circle"></i>
          <div class="label">bxs-down-arrow-circle</div>
        </div>
        <div class="icon">
          <i class="bx bxs-down-arrow-square"></i>
          <div class="label">bxs-down-arrow-square</div>
        </div>
        <div class="icon">
          <i class="bx bxs-download"></i>
          <div class="label">bxs-download</div>
        </div>
        <div class="icon">
          <i class="bx bxs-downvote"></i>
          <div class="label">bxs-downvote</div>
        </div>
        <div class="icon">
          <i class="bx bxs-drink"></i>
          <div class="label">bxs-drink</div>
        </div>
        <div class="icon">
          <i class="bx bxs-droplet"></i>
          <div class="label">bxs-droplet</div>
        </div>
        <div class="icon">
          <i class="bx bxs-droplet-half"></i>
          <div class="label">bxs-droplet-half</div>
        </div>
        <div class="icon">
          <i class="bx bxs-dryer"></i>
          <div class="label">bxs-dryer</div>
        </div>
        <div class="icon">
          <i class="bx bxs-duplicate"></i>
          <div class="label">bxs-duplicate</div>
        </div>
        <div class="icon">
          <i class="bx bxs-edit"></i>
          <div class="label">bxs-edit</div>
        </div>
        <div class="icon">
          <i class="bx bxs-edit-alt"></i>
          <div class="label">bxs-edit-alt</div>
        </div>
        <div class="icon">
          <i class="bx bxs-edit-location"></i>
          <div class="label">bxs-edit-location</div>
        </div>
        <div class="icon">
          <i class="bx bxs-eject"></i>
          <div class="label">bxs-eject</div>
        </div>
        <div class="icon">
          <i class="bx bxs-envelope"></i>
          <div class="label">bxs-envelope</div>
        </div>
        <div class="icon">
          <i class="bx bxs-envelope-open"></i>
          <div class="label">bxs-envelope-open</div>
        </div>
        <div class="icon">
          <i class="bx bxs-eraser"></i>
          <div class="label">bxs-eraser</div>
        </div>
        <div class="icon">
          <i class="bx bxs-error"></i>
          <div class="label">bxs-error</div>
        </div>
        <div class="icon">
          <i class="bx bxs-error-alt"></i>
          <div class="label">bxs-error-alt</div>
        </div>
        <div class="icon">
          <i class="bx bxs-error-circle"></i>
          <div class="label">bxs-error-circle</div>
        </div>
        <div class="icon">
          <i class="bx bxs-ev-station"></i>
          <div class="label">bxs-ev-station</div>
        </div>
        <div class="icon">
          <i class="bx bxs-exit"></i>
          <div class="label">bxs-exit</div>
        </div>
        <div class="icon">
          <i class="bx bxs-extension"></i>
          <div class="label">bxs-extension</div>
        </div>
        <div class="icon">
          <i class="bx bxs-eyedropper"></i>
          <div class="label">bxs-eyedropper</div>
        </div>
        <div class="icon">
          <i class="bx bxs-face"></i>
          <div class="label">bxs-face</div>
        </div>
        <div class="icon">
          <i class="bx bxs-face-mask"></i>
          <div class="label">bxs-face-mask</div>
        </div>
        <div class="icon">
          <i class="bx bxs-factory"></i>
          <div class="label">bxs-factory</div>
        </div>
        <div class="icon">
          <i class="bx bxs-fast-forward-circle"></i>
          <div class="label">bxs-fast-forward-circle</div>
        </div>
        <div class="icon">
          <i class="bx bxs-file"></i>
          <div class="label">bxs-file</div>
        </div>
        <div class="icon">
          <i class="bx bxs-file-archive"></i>
          <div class="label">bxs-file-archive</div>
        </div>
        <div class="icon">
          <i class="bx bxs-file-blank"></i>
          <div class="label">bxs-file-blank</div>
        </div>
        <div class="icon">
          <i class="bx bxs-file-css"></i>
          <div class="label">bxs-file-css</div>
        </div>
        <div class="icon">
          <i class="bx bxs-file-doc"></i>
          <div class="label">bxs-file-doc</div>
        </div>
        <div class="icon">
          <i class="bx bxs-file-export"></i>
          <div class="label">bxs-file-export</div>
        </div>
        <div class="icon">
          <i class="bx bxs-file-find"></i>
          <div class="label">bxs-file-find</div>
        </div>
        <div class="icon">
          <i class="bx bxs-file-gif"></i>
          <div class="label">bxs-file-gif</div>
        </div>
        <div class="icon">
          <i class="bx bxs-file-html"></i>
          <div class="label">bxs-file-html</div>
        </div>
        <div class="icon">
          <i class="bx bxs-file-image"></i>
          <div class="label">bxs-file-image</div>
        </div>
        <div class="icon">
          <i class="bx bxs-file-import"></i>
          <div class="label">bxs-file-import</div>
        </div>
        <div class="icon">
          <i class="bx bxs-file-jpg"></i>
          <div class="label">bxs-file-jpg</div>
        </div>
        <div class="icon">
          <i class="bx bxs-file-js"></i>
          <div class="label">bxs-file-js</div>
        </div>
        <div class="icon">
          <i class="bx bxs-file-json"></i>
          <div class="label">bxs-file-json</div>
        </div>
        <div class="icon">
          <i class="bx bxs-file-md"></i>
          <div class="label">bxs-file-md</div>
        </div>
        <div class="icon">
          <i class="bx bxs-file-pdf"></i>
          <div class="label">bxs-file-pdf</div>
        </div>
        <div class="icon">
          <i class="bx bxs-file-plus"></i>
          <div class="label">bxs-file-plus</div>
        </div>
        <div class="icon">
          <i class="bx bxs-file-png"></i>
          <div class="label">bxs-file-png</div>
        </div>
        <div class="icon">
          <i class="bx bxs-file-txt"></i>
          <div class="label">bxs-file-txt</div>
        </div>
        <div class="icon">
          <i class="bx bxs-film"></i>
          <div class="label">bxs-film</div>
        </div>
        <div class="icon">
          <i class="bx bxs-filter-alt"></i>
          <div class="label">bxs-filter-alt</div>
        </div>
        <div class="icon">
          <i class="bx bxs-first-aid"></i>
          <div class="label">bxs-first-aid</div>
        </div>
        <div class="icon">
          <i class="bx bxs-flag"></i>
          <div class="label">bxs-flag</div>
        </div>
        <div class="icon">
          <i class="bx bxs-flag-alt"></i>
          <div class="label">bxs-flag-alt</div>
        </div>
        <div class="icon">
          <i class="bx bxs-flag-checkered"></i>
          <div class="label">bxs-flag-checkered</div>
        </div>
        <div class="icon">
          <i class="bx bxs-flame"></i>
          <div class="label">bxs-flame</div>
        </div>
        <div class="icon">
          <i class="bx bxs-flask"></i>
          <div class="label">bxs-flask</div>
        </div>
        <div class="icon">
          <i class="bx bxs-florist"></i>
          <div class="label">bxs-florist</div>
        </div>
        <div class="icon">
          <i class="bx bxs-folder"></i>
          <div class="label">bxs-folder</div>
        </div>
        <div class="icon">
          <i class="bx bxs-folder-minus"></i>
          <div class="label">bxs-folder-minus</div>
        </div>
        <div class="icon">
          <i class="bx bxs-folder-open"></i>
          <div class="label">bxs-folder-open</div>
        </div>
        <div class="icon">
          <i class="bx bxs-folder-plus"></i>
          <div class="label">bxs-folder-plus</div>
        </div>
        <div class="icon">
          <i class="bx bxs-food-menu"></i>
          <div class="label">bxs-food-menu</div>
        </div>
        <div class="icon">
          <i class="bx bxs-fridge"></i>
          <div class="label">bxs-fridge</div>
        </div>
        <div class="icon">
          <i class="bx bxs-game"></i>
          <div class="label">bxs-game</div>
        </div>
        <div class="icon">
          <i class="bx bxs-gas-pump"></i>
          <div class="label">bxs-gas-pump</div>
        </div>
        <div class="icon">
          <i class="bx bxs-ghost"></i>
          <div class="label">bxs-ghost</div>
        </div>
        <div class="icon">
          <i class="bx bxs-gift"></i>
          <div class="label">bxs-gift</div>
        </div>
        <div class="icon">
          <i class="bx bxs-graduation"></i>
          <div class="label">bxs-graduation</div>
        </div>
        <div class="icon">
          <i class="bx bxs-grid"></i>
          <div class="label">bxs-grid</div>
        </div>
        <div class="icon">
          <i class="bx bxs-grid-alt"></i>
          <div class="label">bxs-grid-alt</div>
        </div>
        <div class="icon">
          <i class="bx bxs-group"></i>
          <div class="label">bxs-group</div>
        </div>
        <div class="icon">
          <i class="bx bxs-guitar-amp"></i>
          <div class="label">bxs-guitar-amp</div>
        </div>
        <div class="icon">
          <i class="bx bxs-hand"></i>
          <div class="label">bxs-hand</div>
        </div>
        <div class="icon">
          <i class="bx bxs-hand-down"></i>
          <div class="label">bxs-hand-down</div>
        </div>
        <div class="icon">
          <i class="bx bxs-hand-left"></i>
          <div class="label">bxs-hand-left</div>
        </div>
        <div class="icon">
          <i class="bx bxs-hand-right"></i>
          <div class="label">bxs-hand-right</div>
        </div>
        <div class="icon">
          <i class="bx bxs-hand-up"></i>
          <div class="label">bxs-hand-up</div>
        </div>
        <div class="icon">
          <i class="bx bxs-happy"></i>
          <div class="label">bxs-happy</div>
        </div>
        <div class="icon">
          <i class="bx bxs-happy-alt"></i>
          <div class="label">bxs-happy-alt</div>
        </div>
        <div class="icon">
          <i class="bx bxs-happy-beaming"></i>
          <div class="label">bxs-happy-beaming</div>
        </div>
        <div class="icon">
          <i class="bx bxs-happy-heart-eyes"></i>
          <div class="label">bxs-happy-heart-eyes</div>
        </div>
        <div class="icon">
          <i class="bx bxs-hdd"></i>
          <div class="label">bxs-hdd</div>
        </div>
        <div class="icon">
          <i class="bx bxs-heart"></i>
          <div class="label">bxs-heart</div>
        </div>
        <div class="icon">
          <i class="bx bxs-heart-circle"></i>
          <div class="label">bxs-heart-circle</div>
        </div>
        <div class="icon">
          <i class="bx bxs-heart-square"></i>
          <div class="label">bxs-heart-square</div>
        </div>
        <div class="icon">
          <i class="bx bxs-help-circle"></i>
          <div class="label">bxs-help-circle</div>
        </div>
        <div class="icon">
          <i class="bx bxs-hide"></i>
          <div class="label">bxs-hide</div>
        </div>
        <div class="icon">
          <i class="bx bxs-home"></i>
          <div class="label">bxs-home</div>
        </div>
        <div class="icon">
          <i class="bx bxs-home-circle"></i>
          <div class="label">bxs-home-circle</div>
        </div>
        <div class="icon">
          <i class="bx bxs-home-heart"></i>
          <div class="label">bxs-home-heart</div>
        </div>
        <div class="icon">
          <i class="bx bxs-home-smile"></i>
          <div class="label">bxs-home-smile</div>
        </div>
        <div class="icon">
          <i class="bx bxs-hot"></i>
          <div class="label">bxs-hot</div>
        </div>
        <div class="icon">
          <i class="bx bxs-hotel"></i>
          <div class="label">bxs-hotel</div>
        </div>
        <div class="icon">
          <i class="bx bxs-hourglass"></i>
          <div class="label">bxs-hourglass</div>
        </div>
        <div class="icon">
          <i class="bx bxs-hourglass-bottom"></i>
          <div class="label">bxs-hourglass-bottom</div>
        </div>
        <div class="icon">
          <i class="bx bxs-hourglass-top"></i>
          <div class="label">bxs-hourglass-top</div>
        </div>
        <div class="icon">
          <i class="bx bxs-id-card"></i>
          <div class="label">bxs-id-card</div>
        </div>
        <div class="icon">
          <i class="bx bxs-image"></i>
          <div class="label">bxs-image</div>
        </div>
        <div class="icon">
          <i class="bx bxs-image-add"></i>
          <div class="label">bxs-image-add</div>
        </div>
        <div class="icon">
          <i class="bx bxs-image-alt"></i>
          <div class="label">bxs-image-alt</div>
        </div>
        <div class="icon">
          <i class="bx bxs-inbox"></i>
          <div class="label">bxs-inbox</div>
        </div>
        <div class="icon">
          <i class="bx bxs-info-circle"></i>
          <div class="label">bxs-info-circle</div>
        </div>
        <div class="icon">
          <i class="bx bxs-info-square"></i>
          <div class="label">bxs-info-square</div>
        </div>
        <div class="icon">
          <i class="bx bxs-institution"></i>
          <div class="label">bxs-institution</div>
        </div>
        <div class="icon">
          <i class="bx bxs-joystick"></i>
          <div class="label">bxs-joystick</div>
        </div>
        <div class="icon">
          <i class="bx bxs-joystick-alt"></i>
          <div class="label">bxs-joystick-alt</div>
        </div>
        <div class="icon">
          <i class="bx bxs-joystick-button"></i>
          <div class="label">bxs-joystick-button</div>
        </div>
        <div class="icon">
          <i class="bx bxs-key"></i>
          <div class="label">bxs-key</div>
        </div>
        <div class="icon">
          <i class="bx bxs-keyboard"></i>
          <div class="label">bxs-keyboard</div>
        </div>
        <div class="icon">
          <i class="bx bxs-label"></i>
          <div class="label">bxs-label</div>
        </div>
        <div class="icon">
          <i class="bx bxs-landmark"></i>
          <div class="label">bxs-landmark</div>
        </div>
        <div class="icon">
          <i class="bx bxs-landscape"></i>
          <div class="label">bxs-landscape</div>
        </div>
        <div class="icon">
          <i class="bx bxs-laugh"></i>
          <div class="label">bxs-laugh</div>
        </div>
        <div class="icon">
          <i class="bx bxs-layer"></i>
          <div class="label">bxs-layer</div>
        </div>
        <div class="icon">
          <i class="bx bxs-layer-minus"></i>
          <div class="label">bxs-layer-minus</div>
        </div>
        <div class="icon">
          <i class="bx bxs-layer-plus"></i>
          <div class="label">bxs-layer-plus</div>
        </div>
        <div class="icon">
          <i class="bx bxs-layout"></i>
          <div class="label">bxs-layout</div>
        </div>
        <div class="icon">
          <i class="bx bxs-left-arrow"></i>
          <div class="label">bxs-left-arrow</div>
        </div>
        <div class="icon">
          <i class="bx bxs-left-arrow-alt"></i>
          <div class="label">bxs-left-arrow-alt</div>
        </div>
        <div class="icon">
          <i class="bx bxs-left-arrow-circle"></i>
          <div class="label">bxs-left-arrow-circle</div>
        </div>
        <div class="icon">
          <i class="bx bxs-left-arrow-square"></i>
          <div class="label">bxs-left-arrow-square</div>
        </div>
        <div class="icon">
          <i class="bx bxs-left-down-arrow-circle"></i>
          <div class="label">bxs-left-down-arrow-circle</div>
        </div>
        <div class="icon">
          <i class="bx bxs-left-top-arrow-circle"></i>
          <div class="label">bxs-left-top-arrow-circle</div>
        </div>
        <div class="icon">
          <i class="bx bxs-like"></i>
          <div class="label">bxs-like</div>
        </div>
        <div class="icon">
          <i class="bx bxs-location-plus"></i>
          <div class="label">bxs-location-plus</div>
        </div>
        <div class="icon">
          <i class="bx bxs-lock"></i>
          <div class="label">bxs-lock</div>
        </div>
        <div class="icon">
          <i class="bx bxs-lock-alt"></i>
          <div class="label">bxs-lock-alt</div>
        </div>
        <div class="icon">
          <i class="bx bxs-lock-open"></i>
          <div class="label">bxs-lock-open</div>
        </div>
        <div class="icon">
          <i class="bx bxs-lock-open-alt"></i>
          <div class="label">bxs-lock-open-alt</div>
        </div>
        <div class="icon">
          <i class="bx bxs-log-in"></i>
          <div class="label">bxs-log-in</div>
        </div>
        <div class="icon">
          <i class="bx bxs-log-in-circle"></i>
          <div class="label">bxs-log-in-circle</div>
        </div>
        <div class="icon">
          <i class="bx bxs-log-out"></i>
          <div class="label">bxs-log-out</div>
        </div>
        <div class="icon">
          <i class="bx bxs-log-out-circle"></i>
          <div class="label">bxs-log-out-circle</div>
        </div>
        <div class="icon">
          <i class="bx bxs-low-vision"></i>
          <div class="label">bxs-low-vision</div>
        </div>
        <div class="icon">
          <i class="bx bxs-magic-wand"></i>
          <div class="label">bxs-magic-wand</div>
        </div>
        <div class="icon">
          <i class="bx bxs-magnet"></i>
          <div class="label">bxs-magnet</div>
        </div>
        <div class="icon">
          <i class="bx bxs-map"></i>
          <div class="label">bxs-map</div>
        </div>
        <div class="icon">
          <i class="bx bxs-map-alt"></i>
          <div class="label">bxs-map-alt</div>
        </div>
        <div class="icon">
          <i class="bx bxs-map-pin"></i>
          <div class="label">bxs-map-pin</div>
        </div>
        <div class="icon">
          <i class="bx bxs-mask"></i>
          <div class="label">bxs-mask</div>
        </div>
        <div class="icon">
          <i class="bx bxs-medal"></i>
          <div class="label">bxs-medal</div>
        </div>
        <div class="icon">
          <i class="bx bxs-megaphone"></i>
          <div class="label">bxs-megaphone</div>
        </div>
        <div class="icon">
          <i class="bx bxs-meh"></i>
          <div class="label">bxs-meh</div>
        </div>
        <div class="icon">
          <i class="bx bxs-meh-alt"></i>
          <div class="label">bxs-meh-alt</div>
        </div>
        <div class="icon">
          <i class="bx bxs-meh-blank"></i>
          <div class="label">bxs-meh-blank</div>
        </div>
        <div class="icon">
          <i class="bx bxs-memory-card"></i>
          <div class="label">bxs-memory-card</div>
        </div>
        <div class="icon">
          <i class="bx bxs-message"></i>
          <div class="label">bxs-message</div>
        </div>
        <div class="icon">
          <i class="bx bxs-message-add"></i>
          <div class="label">bxs-message-add</div>
        </div>
        <div class="icon">
          <i class="bx bxs-message-alt"></i>
          <div class="label">bxs-message-alt</div>
        </div>
        <div class="icon">
          <i class="bx bxs-message-alt-add"></i>
          <div class="label">bxs-message-alt-add</div>
        </div>
        <div class="icon">
          <i class="bx bxs-message-alt-check"></i>
          <div class="label">bxs-message-alt-check</div>
        </div>
        <div class="icon">
          <i class="bx bxs-message-alt-detail"></i>
          <div class="label">bxs-message-alt-detail</div>
        </div>
        <div class="icon">
          <i class="bx bxs-message-alt-dots"></i>
          <div class="label">bxs-message-alt-dots</div>
        </div>
        <div class="icon">
          <i class="bx bxs-message-alt-edit"></i>
          <div class="label">bxs-message-alt-edit</div>
        </div>
        <div class="icon">
          <i class="bx bxs-message-alt-error"></i>
          <div class="label">bxs-message-alt-error</div>
        </div>
        <div class="icon">
          <i class="bx bxs-message-alt-minus"></i>
          <div class="label">bxs-message-alt-minus</div>
        </div>
        <div class="icon">
          <i class="bx bxs-message-alt-x"></i>
          <div class="label">bxs-message-alt-x</div>
        </div>
        <div class="icon">
          <i class="bx bxs-message-check"></i>
          <div class="label">bxs-message-check</div>
        </div>
        <div class="icon">
          <i class="bx bxs-message-detail"></i>
          <div class="label">bxs-message-detail</div>
        </div>
        <div class="icon">
          <i class="bx bxs-message-dots"></i>
          <div class="label">bxs-message-dots</div>
        </div>
        <div class="icon">
          <i class="bx bxs-message-edit"></i>
          <div class="label">bxs-message-edit</div>
        </div>
        <div class="icon">
          <i class="bx bxs-message-error"></i>
          <div class="label">bxs-message-error</div>
        </div>
        <div class="icon">
          <i class="bx bxs-message-minus"></i>
          <div class="label">bxs-message-minus</div>
        </div>
        <div class="icon">
          <i class="bx bxs-message-rounded"></i>
          <div class="label">bxs-message-rounded</div>
        </div>
        <div class="icon">
          <i class="bx bxs-message-rounded-add"></i>
          <div class="label">bxs-message-rounded-add</div>
        </div>
        <div class="icon">
          <i class="bx bxs-message-rounded-check"></i>
          <div class="label">bxs-message-rounded-check</div>
        </div>
        <div class="icon">
          <i class="bx bxs-message-rounded-detail"></i>
          <div class="label">bxs-message-rounded-detail</div>
        </div>
        <div class="icon">
          <i class="bx bxs-message-rounded-dots"></i>
          <div class="label">bxs-message-rounded-dots</div>
        </div>
        <div class="icon">
          <i class="bx bxs-message-rounded-edit"></i>
          <div class="label">bxs-message-rounded-edit</div>
        </div>
        <div class="icon">
          <i class="bx bxs-message-rounded-error"></i>
          <div class="label">bxs-message-rounded-error</div>
        </div>
        <div class="icon">
          <i class="bx bxs-message-rounded-minus"></i>
          <div class="label">bxs-message-rounded-minus</div>
        </div>
        <div class="icon">
          <i class="bx bxs-message-rounded-x"></i>
          <div class="label">bxs-message-rounded-x</div>
        </div>
        <div class="icon">
          <i class="bx bxs-message-square"></i>
          <div class="label">bxs-message-square</div>
        </div>
        <div class="icon">
          <i class="bx bxs-message-square-add"></i>
          <div class="label">bxs-message-square-add</div>
        </div>
        <div class="icon">
          <i class="bx bxs-message-square-check"></i>
          <div class="label">bxs-message-square-check</div>
        </div>
        <div class="icon">
          <i class="bx bxs-message-square-detail"></i>
          <div class="label">bxs-message-square-detail</div>
        </div>
        <div class="icon">
          <i class="bx bxs-message-square-dots"></i>
          <div class="label">bxs-message-square-dots</div>
        </div>
        <div class="icon">
          <i class="bx bxs-message-square-edit"></i>
          <div class="label">bxs-message-square-edit</div>
        </div>
        <div class="icon">
          <i class="bx bxs-message-square-error"></i>
          <div class="label">bxs-message-square-error</div>
        </div>
        <div class="icon">
          <i class="bx bxs-message-square-minus"></i>
          <div class="label">bxs-message-square-minus</div>
        </div>
        <div class="icon">
          <i class="bx bxs-message-square-x"></i>
          <div class="label">bxs-message-square-x</div>
        </div>
        <div class="icon">
          <i class="bx bxs-message-x"></i>
          <div class="label">bxs-message-x</div>
        </div>
        <div class="icon">
          <i class="bx bxs-meteor"></i>
          <div class="label">bxs-meteor</div>
        </div>
        <div class="icon">
          <i class="bx bxs-microchip"></i>
          <div class="label">bxs-microchip</div>
        </div>
        <div class="icon">
          <i class="bx bxs-microphone"></i>
          <div class="label">bxs-microphone</div>
        </div>
        <div class="icon">
          <i class="bx bxs-microphone-alt"></i>
          <div class="label">bxs-microphone-alt</div>
        </div>
        <div class="icon">
          <i class="bx bxs-microphone-off"></i>
          <div class="label">bxs-microphone-off</div>
        </div>
        <div class="icon">
          <i class="bx bxs-minus-circle"></i>
          <div class="label">bxs-minus-circle</div>
        </div>
        <div class="icon">
          <i class="bx bxs-minus-square"></i>
          <div class="label">bxs-minus-square</div>
        </div>
        <div class="icon">
          <i class="bx bxs-mobile"></i>
          <div class="label">bxs-mobile</div>
        </div>
        <div class="icon">
          <i class="bx bxs-mobile-vibration"></i>
          <div class="label">bxs-mobile-vibration</div>
        </div>
        <div class="icon">
          <i class="bx bxs-moon"></i>
          <div class="label">bxs-moon</div>
        </div>
        <div class="icon">
          <i class="bx bxs-mouse"></i>
          <div class="label">bxs-mouse</div>
        </div>
        <div class="icon">
          <i class="bx bxs-mouse-alt"></i>
          <div class="label">bxs-mouse-alt</div>
        </div>
        <div class="icon">
          <i class="bx bxs-movie"></i>
          <div class="label">bxs-movie</div>
        </div>
        <div class="icon">
          <i class="bx bxs-movie-play"></i>
          <div class="label">bxs-movie-play</div>
        </div>
        <div class="icon">
          <i class="bx bxs-music"></i>
          <div class="label">bxs-music</div>
        </div>
        <div class="icon">
          <i class="bx bxs-navigation"></i>
          <div class="label">bxs-navigation</div>
        </div>
        <div class="icon">
          <i class="bx bxs-network-chart"></i>
          <div class="label">bxs-network-chart</div>
        </div>
        <div class="icon">
          <i class="bx bxs-news"></i>
          <div class="label">bxs-news</div>
        </div>
        <div class="icon">
          <i class="bx bxs-no-entry"></i>
          <div class="label">bxs-no-entry</div>
        </div>
        <div class="icon">
          <i class="bx bxs-note"></i>
          <div class="label">bxs-note</div>
        </div>
        <div class="icon">
          <i class="bx bxs-notepad"></i>
          <div class="label">bxs-notepad</div>
        </div>
        <div class="icon">
          <i class="bx bxs-notification"></i>
          <div class="label">bxs-notification</div>
        </div>
        <div class="icon">
          <i class="bx bxs-notification-off"></i>
          <div class="label">bxs-notification-off</div>
        </div>
        <div class="icon">
          <i class="bx bxs-offer"></i>
          <div class="label">bxs-offer</div>
        </div>
        <div class="icon">
          <i class="bx bxs-package"></i>
          <div class="label">bxs-package</div>
        </div>
        <div class="icon">
          <i class="bx bxs-paint"></i>
          <div class="label">bxs-paint</div>
        </div>
        <div class="icon">
          <i class="bx bxs-paint-roll"></i>
          <div class="label">bxs-paint-roll</div>
        </div>
        <div class="icon">
          <i class="bx bxs-palette"></i>
          <div class="label">bxs-palette</div>
        </div>
        <div class="icon">
          <i class="bx bxs-paper-plane"></i>
          <div class="label">bxs-paper-plane</div>
        </div>
        <div class="icon">
          <i class="bx bxs-parking"></i>
          <div class="label">bxs-parking</div>
        </div>
        <div class="icon">
          <i class="bx bxs-paste"></i>
          <div class="label">bxs-paste</div>
        </div>
        <div class="icon">
          <i class="bx bxs-pen"></i>
          <div class="label">bxs-pen</div>
        </div>
        <div class="icon">
          <i class="bx bxs-pencil"></i>
          <div class="label">bxs-pencil</div>
        </div>
        <div class="icon">
          <i class="bx bxs-phone"></i>
          <div class="label">bxs-phone</div>
        </div>
        <div class="icon">
          <i class="bx bxs-phone-call"></i>
          <div class="label">bxs-phone-call</div>
        </div>
        <div class="icon">
          <i class="bx bxs-phone-incoming"></i>
          <div class="label">bxs-phone-incoming</div>
        </div>
        <div class="icon">
          <i class="bx bxs-phone-off"></i>
          <div class="label">bxs-phone-off</div>
        </div>
        <div class="icon">
          <i class="bx bxs-phone-outgoing"></i>
          <div class="label">bxs-phone-outgoing</div>
        </div>
        <div class="icon">
          <i class="bx bxs-photo-album"></i>
          <div class="label">bxs-photo-album</div>
        </div>
        <div class="icon">
          <i class="bx bxs-piano"></i>
          <div class="label">bxs-piano</div>
        </div>
        <div class="icon">
          <i class="bx bxs-pie-chart"></i>
          <div class="label">bxs-pie-chart</div>
        </div>
        <div class="icon">
          <i class="bx bxs-pie-chart-alt"></i>
          <div class="label">bxs-pie-chart-alt</div>
        </div>
        <div class="icon">
          <i class="bx bxs-pie-chart-alt-2"></i>
          <div class="label">bxs-pie-chart-alt-2</div>
        </div>
        <div class="icon">
          <i class="bx bxs-pin"></i>
          <div class="label">bxs-pin</div>
        </div>
        <div class="icon">
          <i class="bx bxs-pizza"></i>
          <div class="label">bxs-pizza</div>
        </div>
        <div class="icon">
          <i class="bx bxs-plane"></i>
          <div class="label">bxs-plane</div>
        </div>
        <div class="icon">
          <i class="bx bxs-plane-alt"></i>
          <div class="label">bxs-plane-alt</div>
        </div>
        <div class="icon">
          <i class="bx bxs-plane-land"></i>
          <div class="label">bxs-plane-land</div>
        </div>
        <div class="icon">
          <i class="bx bxs-planet"></i>
          <div class="label">bxs-planet</div>
        </div>
        <div class="icon">
          <i class="bx bxs-plane-take-off"></i>
          <div class="label">bxs-plane-take-off</div>
        </div>
        <div class="icon">
          <i class="bx bxs-playlist"></i>
          <div class="label">bxs-playlist</div>
        </div>
        <div class="icon">
          <i class="bx bxs-plug"></i>
          <div class="label">bxs-plug</div>
        </div>
        <div class="icon">
          <i class="bx bxs-plus-circle"></i>
          <div class="label">bxs-plus-circle</div>
        </div>
        <div class="icon">
          <i class="bx bxs-plus-square"></i>
          <div class="label">bxs-plus-square</div>
        </div>
        <div class="icon">
          <i class="bx bxs-pointer"></i>
          <div class="label">bxs-pointer</div>
        </div>
        <div class="icon">
          <i class="bx bxs-polygon"></i>
          <div class="label">bxs-polygon</div>
        </div>
        <div class="icon">
          <i class="bx bxs-printer"></i>
          <div class="label">bxs-printer</div>
        </div>
        <div class="icon">
          <i class="bx bxs-purchase-tag"></i>
          <div class="label">bxs-purchase-tag</div>
        </div>
        <div class="icon">
          <i class="bx bxs-purchase-tag-alt"></i>
          <div class="label">bxs-purchase-tag-alt</div>
        </div>
        <div class="icon">
          <i class="bx bxs-pyramid"></i>
          <div class="label">bxs-pyramid</div>
        </div>
        <div class="icon">
          <i class="bx bxs-quote-alt-left"></i>
          <div class="label">bxs-quote-alt-left</div>
        </div>
        <div class="icon">
          <i class="bx bxs-quote-alt-right"></i>
          <div class="label">bxs-quote-alt-right</div>
        </div>
        <div class="icon">
          <i class="bx bxs-quote-left"></i>
          <div class="label">bxs-quote-left</div>
        </div>
        <div class="icon">
          <i class="bx bxs-quote-right"></i>
          <div class="label">bxs-quote-right</div>
        </div>
        <div class="icon">
          <i class="bx bxs-quote-single-left"></i>
          <div class="label">bxs-quote-single-left</div>
        </div>
        <div class="icon">
          <i class="bx bxs-quote-single-right"></i>
          <div class="label">bxs-quote-single-right</div>
        </div>
        <div class="icon">
          <i class="bx bxs-radiation"></i>
          <div class="label">bxs-radiation</div>
        </div>
        <div class="icon">
          <i class="bx bxs-radio"></i>
          <div class="label">bxs-radio</div>
        </div>
        <div class="icon">
          <i class="bx bxs-receipt"></i>
          <div class="label">bxs-receipt</div>
        </div>
        <div class="icon">
          <i class="bx bxs-rectangle"></i>
          <div class="label">bxs-rectangle</div>
        </div>
        <div class="icon">
          <i class="bx bxs-registered"></i>
          <div class="label">bxs-registered</div>
        </div>
        <div class="icon">
          <i class="bx bxs-rename"></i>
          <div class="label">bxs-rename</div>
        </div>
        <div class="icon">
          <i class="bx bxs-report"></i>
          <div class="label">bxs-report</div>
        </div>
        <div class="icon">
          <i class="bx bxs-rewind-circle"></i>
          <div class="label">bxs-rewind-circle</div>
        </div>
        <div class="icon">
          <i class="bx bxs-right-arrow"></i>
          <div class="label">bxs-right-arrow</div>
        </div>
        <div class="icon">
          <i class="bx bxs-right-arrow-alt"></i>
          <div class="label">bxs-right-arrow-alt</div>
        </div>
        <div class="icon">
          <i class="bx bxs-right-arrow-circle"></i>
          <div class="label">bxs-right-arrow-circle</div>
        </div>
        <div class="icon">
          <i class="bx bxs-right-arrow-square"></i>
          <div class="label">bxs-right-arrow-square</div>
        </div>
        <div class="icon">
          <i class="bx bxs-right-down-arrow-circle"></i>
          <div class="label">bxs-right-down-arrow-circle</div>
        </div>
        <div class="icon">
          <i class="bx bxs-right-top-arrow-circle"></i>
          <div class="label">bxs-right-top-arrow-circle</div>
        </div>
        <div class="icon">
          <i class="bx bxs-rocket"></i>
          <div class="label">bxs-rocket</div>
        </div>
        <div class="icon">
          <i class="bx bxs-ruler"></i>
          <div class="label">bxs-ruler</div>
        </div>
        <div class="icon">
          <i class="bx bxs-sad"></i>
          <div class="label">bxs-sad</div>
        </div>
        <div class="icon">
          <i class="bx bxs-save"></i>
          <div class="label">bxs-save</div>
        </div>
        <div class="icon">
          <i class="bx bxs-school"></i>
          <div class="label">bxs-school</div>
        </div>
        <div class="icon">
          <i class="bx bxs-search"></i>
          <div class="label">bxs-search</div>
        </div>
        <div class="icon">
          <i class="bx bxs-search-alt-2"></i>
          <div class="label">bxs-search-alt-2</div>
        </div>
        <div class="icon">
          <i class="bx bxs-select-multiple"></i>
          <div class="label">bxs-select-multiple</div>
        </div>
        <div class="icon">
          <i class="bx bxs-send"></i>
          <div class="label">bxs-send</div>
        </div>
        <div class="icon">
          <i class="bx bxs-server"></i>
          <div class="label">bxs-server</div>
        </div>
        <div class="icon">
          <i class="bx bxs-shapes"></i>
          <div class="label">bxs-shapes</div>
        </div>
        <div class="icon">
          <i class="bx bxs-share"></i>
          <div class="label">bxs-share</div>
        </div>
        <div class="icon">
          <i class="bx bxs-share-alt"></i>
          <div class="label">bxs-share-alt</div>
        </div>
        <div class="icon">
          <i class="bx bxs-shield"></i>
          <div class="label">bxs-shield</div>
        </div>
        <div class="icon">
          <i class="bx bxs-shield-alt-2"></i>
          <div class="label">bxs-shield-alt-2</div>
        </div>
        <div class="icon">
          <i class="bx bxs-shield-x"></i>
          <div class="label">bxs-shield-x</div>
        </div>
        <div class="icon">
          <i class="bx bxs-ship"></i>
          <div class="label">bxs-ship</div>
        </div>
        <div class="icon">
          <i class="bx bxs-shocked"></i>
          <div class="label">bxs-shocked</div>
        </div>
        <div class="icon">
          <i class="bx bxs-shopping-bag"></i>
          <div class="label">bxs-shopping-bag</div>
        </div>
        <div class="icon">
          <i class="bx bxs-shopping-bag-alt"></i>
          <div class="label">bxs-shopping-bag-alt</div>
        </div>
        <div class="icon">
          <i class="bx bxs-shopping-bags"></i>
          <div class="label">bxs-shopping-bags</div>
        </div>
        <div class="icon">
          <i class="bx bxs-show"></i>
          <div class="label">bxs-show</div>
        </div>
        <div class="icon">
          <i class="bx bxs-skip-next-circle"></i>
          <div class="label">bxs-skip-next-circle</div>
        </div>
        <div class="icon">
          <i class="bx bxs-skip-previous-circle"></i>
          <div class="label">bxs-skip-previous-circle</div>
        </div>
        <div class="icon">
          <i class="bx bxs-skull"></i>
          <div class="label">bxs-skull</div>
        </div>
        <div class="icon">
          <i class="bx bxs-sleepy"></i>
          <div class="label">bxs-sleepy</div>
        </div>
        <div class="icon">
          <i class="bx bxs-slideshow"></i>
          <div class="label">bxs-slideshow</div>
        </div>
        <div class="icon">
          <i class="bx bxs-smile"></i>
          <div class="label">bxs-smile</div>
        </div>
        <div class="icon">
          <i class="bx bxs-sort-alt"></i>
          <div class="label">bxs-sort-alt</div>
        </div>
        <div class="icon">
          <i class="bx bxs-spa"></i>
          <div class="label">bxs-spa</div>
        </div>
        <div class="icon">
          <i class="bx bxs-speaker"></i>
          <div class="label">bxs-speaker</div>
        </div>
        <div class="icon">
          <i class="bx bxs-spray-can"></i>
          <div class="label">bxs-spray-can</div>
        </div>
        <div class="icon">
          <i class="bx bxs-spreadsheet"></i>
          <div class="label">bxs-spreadsheet</div>
        </div>
        <div class="icon">
          <i class="bx bxs-square"></i>
          <div class="label">bxs-square</div>
        </div>
        <div class="icon">
          <i class="bx bxs-square-rounded"></i>
          <div class="label">bxs-square-rounded</div>
        </div>
        <div class="icon">
          <i class="bx bxs-star"></i>
          <div class="label">bxs-star</div>
        </div>
        <div class="icon">
          <i class="bx bxs-star-half"></i>
          <div class="label">bxs-star-half</div>
        </div>
        <div class="icon">
          <i class="bx bxs-sticker"></i>
          <div class="label">bxs-sticker</div>
        </div>
        <div class="icon">
          <i class="bx bxs-stopwatch"></i>
          <div class="label">bxs-stopwatch</div>
        </div>
        <div class="icon">
          <i class="bx bxs-store"></i>
          <div class="label">bxs-store</div>
        </div>
        <div class="icon">
          <i class="bx bxs-store-alt"></i>
          <div class="label">bxs-store-alt</div>
        </div>
        <div class="icon">
          <i class="bx bxs-sun"></i>
          <div class="label">bxs-sun</div>
        </div>
        <div class="icon">
          <i class="bx bxs-tachometer"></i>
          <div class="label">bxs-tachometer</div>
        </div>
        <div class="icon">
          <i class="bx bxs-tag"></i>
          <div class="label">bxs-tag</div>
        </div>
        <div class="icon">
          <i class="bx bxs-tag-alt"></i>
          <div class="label">bxs-tag-alt</div>
        </div>
        <div class="icon">
          <i class="bx bxs-tag-x"></i>
          <div class="label">bxs-tag-x</div>
        </div>
        <div class="icon">
          <i class="bx bxs-taxi"></i>
          <div class="label">bxs-taxi</div>
        </div>
        <div class="icon">
          <i class="bx bxs-tennis-ball"></i>
          <div class="label">bxs-tennis-ball</div>
        </div>
        <div class="icon">
          <i class="bx bxs-terminal"></i>
          <div class="label">bxs-terminal</div>
        </div>
        <div class="icon">
          <i class="bx bxs-thermometer"></i>
          <div class="label">bxs-thermometer</div>
        </div>
        <div class="icon">
          <i class="bx bxs-time"></i>
          <div class="label">bxs-time</div>
        </div>
        <div class="icon">
          <i class="bx bxs-time-five"></i>
          <div class="label">bxs-time-five</div>
        </div>
        <div class="icon">
          <i class="bx bxs-timer"></i>
          <div class="label">bxs-timer</div>
        </div>
        <div class="icon">
          <i class="bx bxs-tired"></i>
          <div class="label">bxs-tired</div>
        </div>
        <div class="icon">
          <i class="bx bxs-toggle-left"></i>
          <div class="label">bxs-toggle-left</div>
        </div>
        <div class="icon">
          <i class="bx bxs-toggle-right"></i>
          <div class="label">bxs-toggle-right</div>
        </div>
        <div class="icon">
          <i class="bx bxs-tone"></i>
          <div class="label">bxs-tone</div>
        </div>
        <div class="icon">
          <i class="bx bxs-torch"></i>
          <div class="label">bxs-torch</div>
        </div>
        <div class="icon">
          <i class="bx bxs-to-top"></i>
          <div class="label">bxs-to-top</div>
        </div>
        <div class="icon">
          <i class="bx bxs-traffic"></i>
          <div class="label">bxs-traffic</div>
        </div>
        <div class="icon">
          <i class="bx bxs-traffic-barrier"></i>
          <div class="label">bxs-traffic-barrier</div>
        </div>
        <div class="icon">
          <i class="bx bxs-traffic-cone"></i>
          <div class="label">bxs-traffic-cone</div>
        </div>
        <div class="icon">
          <i class="bx bxs-train"></i>
          <div class="label">bxs-train</div>
        </div>
        <div class="icon">
          <i class="bx bxs-trash"></i>
          <div class="label">bxs-trash</div>
        </div>
        <div class="icon">
          <i class="bx bxs-trash-alt"></i>
          <div class="label">bxs-trash-alt</div>
        </div>
        <div class="icon">
          <i class="bx bxs-tree"></i>
          <div class="label">bxs-tree</div>
        </div>
        <div class="icon">
          <i class="bx bxs-trophy"></i>
          <div class="label">bxs-trophy</div>
        </div>
        <div class="icon">
          <i class="bx bxs-truck"></i>
          <div class="label">bxs-truck</div>
        </div>
        <div class="icon">
          <i class="bx bxs-t-shirt"></i>
          <div class="label">bxs-t-shirt</div>
        </div>
        <div class="icon">
          <i class="bx bxs-tv"></i>
          <div class="label">bxs-tv</div>
        </div>
        <div class="icon">
          <i class="bx bxs-up-arrow"></i>
          <div class="label">bxs-up-arrow</div>
        </div>
        <div class="icon">
          <i class="bx bxs-up-arrow-alt"></i>
          <div class="label">bxs-up-arrow-alt</div>
        </div>
        <div class="icon">
          <i class="bx bxs-up-arrow-circle"></i>
          <div class="label">bxs-up-arrow-circle</div>
        </div>
        <div class="icon">
          <i class="bx bxs-up-arrow-square"></i>
          <div class="label">bxs-up-arrow-square</div>
        </div>
        <div class="icon">
          <i class="bx bxs-upside-down"></i>
          <div class="label">bxs-upside-down</div>
        </div>
        <div class="icon">
          <i class="bx bxs-upvote"></i>
          <div class="label">bxs-upvote</div>
        </div>
        <div class="icon">
          <i class="bx bxs-user"></i>
          <div class="label">bxs-user</div>
        </div>
        <div class="icon">
          <i class="bx bxs-user-account"></i>
          <div class="label">bxs-user-account</div>
        </div>
        <div class="icon">
          <i class="bx bxs-user-badge"></i>
          <div class="label">bxs-user-badge</div>
        </div>
        <div class="icon">
          <i class="bx bxs-user-check"></i>
          <div class="label">bxs-user-check</div>
        </div>
        <div class="icon">
          <i class="bx bxs-user-circle"></i>
          <div class="label">bxs-user-circle</div>
        </div>
        <div class="icon">
          <i class="bx bxs-user-detail"></i>
          <div class="label">bxs-user-detail</div>
        </div>
        <div class="icon">
          <i class="bx bxs-user-minus"></i>
          <div class="label">bxs-user-minus</div>
        </div>
        <div class="icon">
          <i class="bx bxs-user-pin"></i>
          <div class="label">bxs-user-pin</div>
        </div>
        <div class="icon">
          <i class="bx bxs-user-plus"></i>
          <div class="label">bxs-user-plus</div>
        </div>
        <div class="icon">
          <i class="bx bxs-user-rectangle"></i>
          <div class="label">bxs-user-rectangle</div>
        </div>
        <div class="icon">
          <i class="bx bxs-user-voice"></i>
          <div class="label">bxs-user-voice</div>
        </div>
        <div class="icon">
          <i class="bx bxs-user-x"></i>
          <div class="label">bxs-user-x</div>
        </div>
        <div class="icon">
          <i class="bx bxs-vector"></i>
          <div class="label">bxs-vector</div>
        </div>
        <div class="icon">
          <i class="bx bxs-vial"></i>
          <div class="label">bxs-vial</div>
        </div>
        <div class="icon">
          <i class="bx bxs-video"></i>
          <div class="label">bxs-video</div>
        </div>
        <div class="icon">
          <i class="bx bxs-video-off"></i>
          <div class="label">bxs-video-off</div>
        </div>
        <div class="icon">
          <i class="bx bxs-video-plus"></i>
          <div class="label">bxs-video-plus</div>
        </div>
        <div class="icon">
          <i class="bx bxs-video-recording"></i>
          <div class="label">bxs-video-recording</div>
        </div>
        <div class="icon">
          <i class="bx bxs-videos"></i>
          <div class="label">bxs-videos</div>
        </div>
        <div class="icon">
          <i class="bx bxs-virus"></i>
          <div class="label">bxs-virus</div>
        </div>
        <div class="icon">
          <i class="bx bxs-virus-block"></i>
          <div class="label">bxs-virus-block</div>
        </div>
        <div class="icon">
          <i class="bx bxs-volume"></i>
          <div class="label">bxs-volume</div>
        </div>
        <div class="icon">
          <i class="bx bxs-volume-full"></i>
          <div class="label">bxs-volume-full</div>
        </div>
        <div class="icon">
          <i class="bx bxs-volume-low"></i>
          <div class="label">bxs-volume-low</div>
        </div>
        <div class="icon">
          <i class="bx bxs-volume-mute"></i>
          <div class="label">bxs-volume-mute</div>
        </div>
        <div class="icon">
          <i class="bx bxs-wallet"></i>
          <div class="label">bxs-wallet</div>
        </div>
        <div class="icon">
          <i class="bx bxs-wallet-alt"></i>
          <div class="label">bxs-wallet-alt</div>
        </div>
        <div class="icon">
          <i class="bx bxs-washer"></i>
          <div class="label">bxs-washer</div>
        </div>
        <div class="icon">
          <i class="bx bxs-watch"></i>
          <div class="label">bxs-watch</div>
        </div>
        <div class="icon">
          <i class="bx bxs-watch-alt"></i>
          <div class="label">bxs-watch-alt</div>
        </div>
        <div class="icon">
          <i class="bx bxs-webcam"></i>
          <div class="label">bxs-webcam</div>
        </div>
        <div class="icon">
          <i class="bx bxs-widget"></i>
          <div class="label">bxs-widget</div>
        </div>
        <div class="icon">
          <i class="bx bxs-window-alt"></i>
          <div class="label">bxs-window-alt</div>
        </div>
        <div class="icon">
          <i class="bx bxs-wine"></i>
          <div class="label">bxs-wine</div>
        </div>
        <div class="icon">
          <i class="bx bxs-wink-smile"></i>
          <div class="label">bxs-wink-smile</div>
        </div>
        <div class="icon">
          <i class="bx bxs-wink-tongue"></i>
          <div class="label">bxs-wink-tongue</div>
        </div>
        <div class="icon">
          <i class="bx bxs-wrench"></i>
          <div class="label">bxs-wrench</div>
        </div>
        <div class="icon">
          <i class="bx bxs-x-circle"></i>
          <div class="label">bxs-x-circle</div>
        </div>
        <div class="icon">
          <i class="bx bxs-x-square"></i>
          <div class="label">bxs-x-square</div>
        </div>
        <div class="icon">
          <i class="bx bxs-yin-yang"></i>
          <div class="label">bxs-yin-yang</div>
        </div>
        <div class="icon">
          <i class="bx bxs-zap"></i>
          <div class="label">bxs-zap</div>
        </div>
        <div class="icon">
          <i class="bx bxs-zoom-in"></i>
          <div class="label">bxs-zoom-in</div>
        </div>
        <div class="icon">
          <i class="bx bxs-zoom-out"></i>
          <div class="label">bxs-zoom-out</div>
        </div>
        <div class="icon">
          <i class="bx bx-abacus"></i>
          <div class="label">bx-abacus</div>
        </div>
        <div class="icon">
          <i class="bx bx-accessibility"></i>
          <div class="label">bx-accessibility</div>
        </div>
        <div class="icon">
          <i class="bx bx-add-to-queue"></i>
          <div class="label">bx-add-to-queue</div>
        </div>
        <div class="icon">
          <i class="bx bx-adjust"></i>
          <div class="label">bx-adjust</div>
        </div>
        <div class="icon">
          <i class="bx bx-alarm"></i>
          <div class="label">bx-alarm</div>
        </div>
        <div class="icon">
          <i class="bx bx-alarm-add"></i>
          <div class="label">bx-alarm-add</div>
        </div>
        <div class="icon">
          <i class="bx bx-alarm-exclamation"></i>
          <div class="label">bx-alarm-exclamation</div>
        </div>
        <div class="icon">
          <i class="bx bx-alarm-off"></i>
          <div class="label">bx-alarm-off</div>
        </div>
        <div class="icon">
          <i class="bx bx-alarm-snooze"></i>
          <div class="label">bx-alarm-snooze</div>
        </div>
        <div class="icon">
          <i class="bx bx-album"></i>
          <div class="label">bx-album</div>
        </div>
        <div class="icon">
          <i class="bx bx-align-justify"></i>
          <div class="label">bx-align-justify</div>
        </div>
        <div class="icon">
          <i class="bx bx-align-left"></i>
          <div class="label">bx-align-left</div>
        </div>
        <div class="icon">
          <i class="bx bx-align-middle"></i>
          <div class="label">bx-align-middle</div>
        </div>
        <div class="icon">
          <i class="bx bx-align-right"></i>
          <div class="label">bx-align-right</div>
        </div>
        <div class="icon">
          <i class="bx bx-analyse"></i>
          <div class="label">bx-analyse</div>
        </div>
        <div class="icon">
          <i class="bx bx-anchor"></i>
          <div class="label">bx-anchor</div>
        </div>
        <div class="icon">
          <i class="bx bx-angry"></i>
          <div class="label">bx-angry</div>
        </div>
        <div class="icon">
          <i class="bx bx-aperture"></i>
          <div class="label">bx-aperture</div>
        </div>
        <div class="icon">
          <i class="bx bx-arch"></i>
          <div class="label">bx-arch</div>
        </div>
        <div class="icon">
          <i class="bx bx-archive"></i>
          <div class="label">bx-archive</div>
        </div>
        <div class="icon">
          <i class="bx bx-archive-in"></i>
          <div class="label">bx-archive-in</div>
        </div>
        <div class="icon">
          <i class="bx bx-archive-out"></i>
          <div class="label">bx-archive-out</div>
        </div>
        <div class="icon">
          <i class="bx bx-area"></i>
          <div class="label">bx-area</div>
        </div>
        <div class="icon">
          <i class="bx bx-arrow-back"></i>
          <div class="label">bx-arrow-back</div>
        </div>
        <div class="icon">
          <i class="bx bx-arrow-from-bottom"></i>
          <div class="label">bx-arrow-from-bottom</div>
        </div>
        <div class="icon">
          <i class="bx bx-arrow-from-left"></i>
          <div class="label">bx-arrow-from-left</div>
        </div>
        <div class="icon">
          <i class="bx bx-arrow-from-right"></i>
          <div class="label">bx-arrow-from-right</div>
        </div>
        <div class="icon">
          <i class="bx bx-arrow-from-top"></i>
          <div class="label">bx-arrow-from-top</div>
        </div>
        <div class="icon">
          <i class="bx bx-arrow-to-bottom"></i>
          <div class="label">bx-arrow-to-bottom</div>
        </div>
        <div class="icon">
          <i class="bx bx-arrow-to-left"></i>
          <div class="label">bx-arrow-to-left</div>
        </div>
        <div class="icon">
          <i class="bx bx-arrow-to-right"></i>
          <div class="label">bx-arrow-to-right</div>
        </div>
        <div class="icon">
          <i class="bx bx-arrow-to-top"></i>
          <div class="label">bx-arrow-to-top</div>
        </div>
        <div class="icon">
          <i class="bx bx-at"></i>
          <div class="label">bx-at</div>
        </div>
        <div class="icon">
          <i class="bx bx-atom"></i>
          <div class="label">bx-atom</div>
        </div>
        <div class="icon">
          <i class="bx bx-award"></i>
          <div class="label">bx-award</div>
        </div>
        <div class="icon">
          <i class="bx bx-badge"></i>
          <div class="label">bx-badge</div>
        </div>
        <div class="icon">
          <i class="bx bx-badge-check"></i>
          <div class="label">bx-badge-check</div>
        </div>
        <div class="icon">
          <i class="bx bx-ball"></i>
          <div class="label">bx-ball</div>
        </div>
        <div class="icon">
          <i class="bx bx-band-aid"></i>
          <div class="label">bx-band-aid</div>
        </div>
        <div class="icon">
          <i class="bx bx-bar-chart"></i>
          <div class="label">bx-bar-chart</div>
        </div>
        <div class="icon">
          <i class="bx bx-bar-chart-alt"></i>
          <div class="label">bx-bar-chart-alt</div>
        </div>
        <div class="icon">
          <i class="bx bx-bar-chart-alt-2"></i>
          <div class="label">bx-bar-chart-alt-2</div>
        </div>
        <div class="icon">
          <i class="bx bx-bar-chart-square"></i>
          <div class="label">bx-bar-chart-square</div>
        </div>
        <div class="icon">
          <i class="bx bx-barcode"></i>
          <div class="label">bx-barcode</div>
        </div>
        <div class="icon">
          <i class="bx bx-barcode-reader"></i>
          <div class="label">bx-barcode-reader</div>
        </div>
        <div class="icon">
          <i class="bx bx-baseball"></i>
          <div class="label">bx-baseball</div>
        </div>
        <div class="icon">
          <i class="bx bx-basket"></i>
          <div class="label">bx-basket</div>
        </div>
        <div class="icon">
          <i class="bx bx-basketball"></i>
          <div class="label">bx-basketball</div>
        </div>
        <div class="icon">
          <i class="bx bx-bath"></i>
          <div class="label">bx-bath</div>
        </div>
        <div class="icon">
          <i class="bx bx-battery"></i>
          <div class="label">bx-battery</div>
        </div>
        <div class="icon">
          <i class="bx bx-bed"></i>
          <div class="label">bx-bed</div>
        </div>
        <div class="icon">
          <i class="bx bx-been-here"></i>
          <div class="label">bx-been-here</div>
        </div>
        <div class="icon">
          <i class="bx bx-beer"></i>
          <div class="label">bx-beer</div>
        </div>
        <div class="icon">
          <i class="bx bx-bell"></i>
          <div class="label">bx-bell</div>
        </div>
        <div class="icon">
          <i class="bx bx-bell-minus"></i>
          <div class="label">bx-bell-minus</div>
        </div>
        <div class="icon">
          <i class="bx bx-bell-off"></i>
          <div class="label">bx-bell-off</div>
        </div>
        <div class="icon">
          <i class="bx bx-bell-plus"></i>
          <div class="label">bx-bell-plus</div>
        </div>
        <div class="icon">
          <i class="bx bx-bible"></i>
          <div class="label">bx-bible</div>
        </div>
        <div class="icon">
          <i class="bx bx-bitcoin"></i>
          <div class="label">bx-bitcoin</div>
        </div>
        <div class="icon">
          <i class="bx bx-blanket"></i>
          <div class="label">bx-blanket</div>
        </div>
        <div class="icon">
          <i class="bx bx-block"></i>
          <div class="label">bx-block</div>
        </div>
        <div class="icon">
          <i class="bx bx-bluetooth"></i>
          <div class="label">bx-bluetooth</div>
        </div>
        <div class="icon">
          <i class="bx bx-body"></i>
          <div class="label">bx-body</div>
        </div>
        <div class="icon">
          <i class="bx bx-bold"></i>
          <div class="label">bx-bold</div>
        </div>
        <div class="icon">
          <i class="bx bx-bolt-circle"></i>
          <div class="label">bx-bolt-circle</div>
        </div>
        <div class="icon">
          <i class="bx bx-bomb"></i>
          <div class="label">bx-bomb</div>
        </div>
        <div class="icon">
          <i class="bx bx-bone"></i>
          <div class="label">bx-bone</div>
        </div>
        <div class="icon">
          <i class="bx bx-bong"></i>
          <div class="label">bx-bong</div>
        </div>
        <div class="icon">
          <i class="bx bx-book"></i>
          <div class="label">bx-book</div>
        </div>
        <div class="icon">
          <i class="bx bx-book-add"></i>
          <div class="label">bx-book-add</div>
        </div>
        <div class="icon">
          <i class="bx bx-book-alt"></i>
          <div class="label">bx-book-alt</div>
        </div>
        <div class="icon">
          <i class="bx bx-book-bookmark"></i>
          <div class="label">bx-book-bookmark</div>
        </div>
        <div class="icon">
          <i class="bx bx-book-content"></i>
          <div class="label">bx-book-content</div>
        </div>
        <div class="icon">
          <i class="bx bx-book-heart"></i>
          <div class="label">bx-book-heart</div>
        </div>
        <div class="icon">
          <i class="bx bx-bookmark"></i>
          <div class="label">bx-bookmark</div>
        </div>
        <div class="icon">
          <i class="bx bx-bookmark-alt"></i>
          <div class="label">bx-bookmark-alt</div>
        </div>
        <div class="icon">
          <i class="bx bx-bookmark-alt-minus"></i>
          <div class="label">bx-bookmark-alt-minus</div>
        </div>
        <div class="icon">
          <i class="bx bx-bookmark-alt-plus"></i>
          <div class="label">bx-bookmark-alt-plus</div>
        </div>
        <div class="icon">
          <i class="bx bx-bookmark-heart"></i>
          <div class="label">bx-bookmark-heart</div>
        </div>
        <div class="icon">
          <i class="bx bx-bookmark-minus"></i>
          <div class="label">bx-bookmark-minus</div>
        </div>
        <div class="icon">
          <i class="bx bx-bookmark-plus"></i>
          <div class="label">bx-bookmark-plus</div>
        </div>
        <div class="icon">
          <i class="bx bx-bookmarks"></i>
          <div class="label">bx-bookmarks</div>
        </div>
        <div class="icon">
          <i class="bx bx-book-open"></i>
          <div class="label">bx-book-open</div>
        </div>
        <div class="icon">
          <i class="bx bx-book-reader"></i>
          <div class="label">bx-book-reader</div>
        </div>
        <div class="icon">
          <i class="bx bx-border-all"></i>
          <div class="label">bx-border-all</div>
        </div>
        <div class="icon">
          <i class="bx bx-border-bottom"></i>
          <div class="label">bx-border-bottom</div>
        </div>
        <div class="icon">
          <i class="bx bx-border-inner"></i>
          <div class="label">bx-border-inner</div>
        </div>
        <div class="icon">
          <i class="bx bx-border-left"></i>
          <div class="label">bx-border-left</div>
        </div>
        <div class="icon">
          <i class="bx bx-border-none"></i>
          <div class="label">bx-border-none</div>
        </div>
        <div class="icon">
          <i class="bx bx-border-outer"></i>
          <div class="label">bx-border-outer</div>
        </div>
        <div class="icon">
          <i class="bx bx-border-radius"></i>
          <div class="label">bx-border-radius</div>
        </div>
        <div class="icon">
          <i class="bx bx-border-right"></i>
          <div class="label">bx-border-right</div>
        </div>
        <div class="icon">
          <i class="bx bx-border-top"></i>
          <div class="label">bx-border-top</div>
        </div>
        <div class="icon">
          <i class="bx bx-bot"></i>
          <div class="label">bx-bot</div>
        </div>
        <div class="icon">
          <i class="bx bx-bowling-ball"></i>
          <div class="label">bx-bowling-ball</div>
        </div>
        <div class="icon">
          <i class="bx bx-box"></i>
          <div class="label">bx-box</div>
        </div>
        <div class="icon">
          <i class="bx bx-bracket"></i>
          <div class="label">bx-bracket</div>
        </div>
        <div class="icon">
          <i class="bx bx-braille"></i>
          <div class="label">bx-braille</div>
        </div>
        <div class="icon">
          <i class="bx bx-brain"></i>
          <div class="label">bx-brain</div>
        </div>
        <div class="icon">
          <i class="bx bx-briefcase"></i>
          <div class="label">bx-briefcase</div>
        </div>
        <div class="icon">
          <i class="bx bx-briefcase-alt"></i>
          <div class="label">bx-briefcase-alt</div>
        </div>
        <div class="icon">
          <i class="bx bx-briefcase-alt-2"></i>
          <div class="label">bx-briefcase-alt-2</div>
        </div>
        <div class="icon">
          <i class="bx bx-brightness"></i>
          <div class="label">bx-brightness</div>
        </div>
        <div class="icon">
          <i class="bx bx-brightness-half"></i>
          <div class="label">bx-brightness-half</div>
        </div>
        <div class="icon">
          <i class="bx bx-broadcast"></i>
          <div class="label">bx-broadcast</div>
        </div>
        <div class="icon">
          <i class="bx bx-brush"></i>
          <div class="label">bx-brush</div>
        </div>
        <div class="icon">
          <i class="bx bx-brush-alt"></i>
          <div class="label">bx-brush-alt</div>
        </div>
        <div class="icon">
          <i class="bx bx-bug"></i>
          <div class="label">bx-bug</div>
        </div>
        <div class="icon">
          <i class="bx bx-bug-alt"></i>
          <div class="label">bx-bug-alt</div>
        </div>
        <div class="icon">
          <i class="bx bx-building"></i>
          <div class="label">bx-building</div>
        </div>
        <div class="icon">
          <i class="bx bx-building-house"></i>
          <div class="label">bx-building-house</div>
        </div>
        <div class="icon">
          <i class="bx bx-buildings"></i>
          <div class="label">bx-buildings</div>
        </div>
        <div class="icon">
          <i class="bx bx-bulb"></i>
          <div class="label">bx-bulb</div>
        </div>
        <div class="icon">
          <i class="bx bx-bullseye"></i>
          <div class="label">bx-bullseye</div>
        </div>
        <div class="icon">
          <i class="bx bx-buoy"></i>
          <div class="label">bx-buoy</div>
        </div>
        <div class="icon">
          <i class="bx bx-bus"></i>
          <div class="label">bx-bus</div>
        </div>
        <div class="icon">
          <i class="bx bx-bus-school"></i>
          <div class="label">bx-bus-school</div>
        </div>
        <div class="icon">
          <i class="bx bx-cabinet"></i>
          <div class="label">bx-cabinet</div>
        </div>
        <div class="icon">
          <i class="bx bx-cake"></i>
          <div class="label">bx-cake</div>
        </div>
        <div class="icon">
          <i class="bx bx-calculator"></i>
          <div class="label">bx-calculator</div>
        </div>
        <div class="icon">
          <i class="bx bx-calendar"></i>
          <div class="label">bx-calendar</div>
        </div>
        <div class="icon">
          <i class="bx bx-calendar-alt"></i>
          <div class="label">bx-calendar-alt</div>
        </div>
        <div class="icon">
          <i class="bx bx-calendar-check"></i>
          <div class="label">bx-calendar-check</div>
        </div>
        <div class="icon">
          <i class="bx bx-calendar-edit"></i>
          <div class="label">bx-calendar-edit</div>
        </div>
        <div class="icon">
          <i class="bx bx-calendar-event"></i>
          <div class="label">bx-calendar-event</div>
        </div>
        <div class="icon">
          <i class="bx bx-calendar-exclamation"></i>
          <div class="label">bx-calendar-exclamation</div>
        </div>
        <div class="icon">
          <i class="bx bx-calendar-heart"></i>
          <div class="label">bx-calendar-heart</div>
        </div>
        <div class="icon">
          <i class="bx bx-calendar-minus"></i>
          <div class="label">bx-calendar-minus</div>
        </div>
        <div class="icon">
          <i class="bx bx-calendar-plus"></i>
          <div class="label">bx-calendar-plus</div>
        </div>
        <div class="icon">
          <i class="bx bx-calendar-star"></i>
          <div class="label">bx-calendar-star</div>
        </div>
        <div class="icon">
          <i class="bx bx-calendar-week"></i>
          <div class="label">bx-calendar-week</div>
        </div>
        <div class="icon">
          <i class="bx bx-calendar-x"></i>
          <div class="label">bx-calendar-x</div>
        </div>
        <div class="icon">
          <i class="bx bx-camera"></i>
          <div class="label">bx-camera</div>
        </div>
        <div class="icon">
          <i class="bx bx-camera-home"></i>
          <div class="label">bx-camera-home</div>
        </div>
        <div class="icon">
          <i class="bx bx-camera-movie"></i>
          <div class="label">bx-camera-movie</div>
        </div>
        <div class="icon">
          <i class="bx bx-camera-off"></i>
          <div class="label">bx-camera-off</div>
        </div>
        <div class="icon">
          <i class="bx bx-capsule"></i>
          <div class="label">bx-capsule</div>
        </div>
        <div class="icon">
          <i class="bx bx-captions"></i>
          <div class="label">bx-captions</div>
        </div>
        <div class="icon">
          <i class="bx bx-car"></i>
          <div class="label">bx-car</div>
        </div>
        <div class="icon">
          <i class="bx bx-card"></i>
          <div class="label">bx-card</div>
        </div>
        <div class="icon">
          <i class="bx bx-caret-down"></i>
          <div class="label">bx-caret-down</div>
        </div>
        <div class="icon">
          <i class="bx bx-caret-down-circle"></i>
          <div class="label">bx-caret-down-circle</div>
        </div>
        <div class="icon">
          <i class="bx bx-caret-down-square"></i>
          <div class="label">bx-caret-down-square</div>
        </div>
        <div class="icon">
          <i class="bx bx-caret-left"></i>
          <div class="label">bx-caret-left</div>
        </div>
        <div class="icon">
          <i class="bx bx-caret-left-circle"></i>
          <div class="label">bx-caret-left-circle</div>
        </div>
        <div class="icon">
          <i class="bx bx-caret-left-square"></i>
          <div class="label">bx-caret-left-square</div>
        </div>
        <div class="icon">
          <i class="bx bx-caret-right"></i>
          <div class="label">bx-caret-right</div>
        </div>
        <div class="icon">
          <i class="bx bx-caret-right-circle"></i>
          <div class="label">bx-caret-right-circle</div>
        </div>
        <div class="icon">
          <i class="bx bx-caret-right-square"></i>
          <div class="label">bx-caret-right-square</div>
        </div>
        <div class="icon">
          <i class="bx bx-caret-up"></i>
          <div class="label">bx-caret-up</div>
        </div>
        <div class="icon">
          <i class="bx bx-caret-up-circle"></i>
          <div class="label">bx-caret-up-circle</div>
        </div>
        <div class="icon">
          <i class="bx bx-caret-up-square"></i>
          <div class="label">bx-caret-up-square</div>
        </div>
        <div class="icon">
          <i class="bx bx-carousel"></i>
          <div class="label">bx-carousel</div>
        </div>
        <div class="icon">
          <i class="bx bx-cart"></i>
          <div class="label">bx-cart</div>
        </div>
        <div class="icon">
          <i class="bx bx-cart-alt"></i>
          <div class="label">bx-cart-alt</div>
        </div>
        <div class="icon">
          <i class="bx bx-cast"></i>
          <div class="label">bx-cast</div>
        </div>
        <div class="icon">
          <i class="bx bx-category"></i>
          <div class="label">bx-category</div>
        </div>
        <div class="icon">
          <i class="bx bx-category-alt"></i>
          <div class="label">bx-category-alt</div>
        </div>
        <div class="icon">
          <i class="bx bx-cctv"></i>
          <div class="label">bx-cctv</div>
        </div>
        <div class="icon">
          <i class="bx bx-certification"></i>
          <div class="label">bx-certification</div>
        </div>
        <div class="icon">
          <i class="bx bx-chair"></i>
          <div class="label">bx-chair</div>
        </div>
        <div class="icon">
          <i class="bx bx-chalkboard"></i>
          <div class="label">bx-chalkboard</div>
        </div>
        <div class="icon">
          <i class="bx bx-chart"></i>
          <div class="label">bx-chart</div>
        </div>
        <div class="icon">
          <i class="bx bx-chat"></i>
          <div class="label">bx-chat</div>
        </div>
        <div class="icon">
          <i class="bx bx-check"></i>
          <div class="label">bx-check</div>
        </div>
        <div class="icon">
          <i class="bx bx-checkbox"></i>
          <div class="label">bx-checkbox</div>
        </div>
        <div class="icon">
          <i class="bx bx-checkbox-checked"></i>
          <div class="label">bx-checkbox-checked</div>
        </div>
        <div class="icon">
          <i class="bx bx-checkbox-minus"></i>
          <div class="label">bx-checkbox-minus</div>
        </div>
        <div class="icon">
          <i class="bx bx-checkbox-square"></i>
          <div class="label">bx-checkbox-square</div>
        </div>
        <div class="icon">
          <i class="bx bx-check-circle"></i>
          <div class="label">bx-check-circle</div>
        </div>
        <div class="icon">
          <i class="bx bx-check-double"></i>
          <div class="label">bx-check-double</div>
        </div>
        <div class="icon">
          <i class="bx bx-check-shield"></i>
          <div class="label">bx-check-shield</div>
        </div>
        <div class="icon">
          <i class="bx bx-check-square"></i>
          <div class="label">bx-check-square</div>
        </div>
        <div class="icon">
          <i class="bx bx-chevron-down"></i>
          <div class="label">bx-chevron-down</div>
        </div>
        <div class="icon">
          <i class="bx bx-chevron-down-circle"></i>
          <div class="label">bx-chevron-down-circle</div>
        </div>
        <div class="icon">
          <i class="bx bx-chevron-down-square"></i>
          <div class="label">bx-chevron-down-square</div>
        </div>
        <div class="icon">
          <i class="bx bx-chevron-left"></i>
          <div class="label">bx-chevron-left</div>
        </div>
        <div class="icon">
          <i class="bx bx-chevron-left-circle"></i>
          <div class="label">bx-chevron-left-circle</div>
        </div>
        <div class="icon">
          <i class="bx bx-chevron-left-square"></i>
          <div class="label">bx-chevron-left-square</div>
        </div>
        <div class="icon">
          <i class="bx bx-chevron-right"></i>
          <div class="label">bx-chevron-right</div>
        </div>
        <div class="icon">
          <i class="bx bx-chevron-right-circle"></i>
          <div class="label">bx-chevron-right-circle</div>
        </div>
        <div class="icon">
          <i class="bx bx-chevron-right-square"></i>
          <div class="label">bx-chevron-right-square</div>
        </div>
        <div class="icon">
          <i class="bx bx-chevrons-down"></i>
          <div class="label">bx-chevrons-down</div>
        </div>
        <div class="icon">
          <i class="bx bx-chevrons-left"></i>
          <div class="label">bx-chevrons-left</div>
        </div>
        <div class="icon">
          <i class="bx bx-chevrons-right"></i>
          <div class="label">bx-chevrons-right</div>
        </div>
        <div class="icon">
          <i class="bx bx-chevrons-up"></i>
          <div class="label">bx-chevrons-up</div>
        </div>
        <div class="icon">
          <i class="bx bx-chevron-up"></i>
          <div class="label">bx-chevron-up</div>
        </div>
        <div class="icon">
          <i class="bx bx-chevron-up-circle"></i>
          <div class="label">bx-chevron-up-circle</div>
        </div>
        <div class="icon">
          <i class="bx bx-chevron-up-square"></i>
          <div class="label">bx-chevron-up-square</div>
        </div>
        <div class="icon">
          <i class="bx bx-chip"></i>
          <div class="label">bx-chip</div>
        </div>
        <div class="icon">
          <i class="bx bx-church"></i>
          <div class="label">bx-church</div>
        </div>
        <div class="icon">
          <i class="bx bx-circle"></i>
          <div class="label">bx-circle</div>
        </div>
        <div class="icon">
          <i class="bx bx-clinic"></i>
          <div class="label">bx-clinic</div>
        </div>
        <div class="icon">
          <i class="bx bx-clipboard"></i>
          <div class="label">bx-clipboard</div>
        </div>
        <div class="icon">
          <i class="bx bx-closet"></i>
          <div class="label">bx-closet</div>
        </div>
        <div class="icon">
          <i class="bx bx-cloud"></i>
          <div class="label">bx-cloud</div>
        </div>
        <div class="icon">
          <i class="bx bx-cloud-download"></i>
          <div class="label">bx-cloud-download</div>
        </div>
        <div class="icon">
          <i class="bx bx-cloud-drizzle"></i>
          <div class="label">bx-cloud-drizzle</div>
        </div>
        <div class="icon">
          <i class="bx bx-cloud-lightning"></i>
          <div class="label">bx-cloud-lightning</div>
        </div>
        <div class="icon">
          <i class="bx bx-cloud-light-rain"></i>
          <div class="label">bx-cloud-light-rain</div>
        </div>
        <div class="icon">
          <i class="bx bx-cloud-rain"></i>
          <div class="label">bx-cloud-rain</div>
        </div>
        <div class="icon">
          <i class="bx bx-cloud-snow"></i>
          <div class="label">bx-cloud-snow</div>
        </div>
        <div class="icon">
          <i class="bx bx-cloud-upload"></i>
          <div class="label">bx-cloud-upload</div>
        </div>
        <div class="icon">
          <i class="bx bx-code"></i>
          <div class="label">bx-code</div>
        </div>
        <div class="icon">
          <i class="bx bx-code-alt"></i>
          <div class="label">bx-code-alt</div>
        </div>
        <div class="icon">
          <i class="bx bx-code-block"></i>
          <div class="label">bx-code-block</div>
        </div>
        <div class="icon">
          <i class="bx bx-code-curly"></i>
          <div class="label">bx-code-curly</div>
        </div>
        <div class="icon">
          <i class="bx bx-coffee"></i>
          <div class="label">bx-coffee</div>
        </div>
        <div class="icon">
          <i class="bx bx-coffee-togo"></i>
          <div class="label">bx-coffee-togo</div>
        </div>
        <div class="icon">
          <i class="bx bx-cog"></i>
          <div class="label">bx-cog</div>
        </div>
        <div class="icon">
          <i class="bx bx-coin"></i>
          <div class="label">bx-coin</div>
        </div>
        <div class="icon">
          <i class="bx bx-coin-stack"></i>
          <div class="label">bx-coin-stack</div>
        </div>
        <div class="icon">
          <i class="bx bx-collapse"></i>
          <div class="label">bx-collapse</div>
        </div>
        <div class="icon">
          <i class="bx bx-collection"></i>
          <div class="label">bx-collection</div>
        </div>
        <div class="icon">
          <i class="bx bx-color-fill"></i>
          <div class="label">bx-color-fill</div>
        </div>
        <div class="icon">
          <i class="bx bx-columns"></i>
          <div class="label">bx-columns</div>
        </div>
        <div class="icon">
          <i class="bx bx-command"></i>
          <div class="label">bx-command</div>
        </div>
        <div class="icon">
          <i class="bx bx-comment"></i>
          <div class="label">bx-comment</div>
        </div>
        <div class="icon">
          <i class="bx bx-comment-add"></i>
          <div class="label">bx-comment-add</div>
        </div>
        <div class="icon">
          <i class="bx bx-comment-check"></i>
          <div class="label">bx-comment-check</div>
        </div>
        <div class="icon">
          <i class="bx bx-comment-detail"></i>
          <div class="label">bx-comment-detail</div>
        </div>
        <div class="icon">
          <i class="bx bx-comment-dots"></i>
          <div class="label">bx-comment-dots</div>
        </div>
        <div class="icon">
          <i class="bx bx-comment-edit"></i>
          <div class="label">bx-comment-edit</div>
        </div>
        <div class="icon">
          <i class="bx bx-comment-error"></i>
          <div class="label">bx-comment-error</div>
        </div>
        <div class="icon">
          <i class="bx bx-comment-minus"></i>
          <div class="label">bx-comment-minus</div>
        </div>
        <div class="icon">
          <i class="bx bx-comment-x"></i>
          <div class="label">bx-comment-x</div>
        </div>
        <div class="icon">
          <i class="bx bx-compass"></i>
          <div class="label">bx-compass</div>
        </div>
        <div class="icon">
          <i class="bx bx-confused"></i>
          <div class="label">bx-confused</div>
        </div>
        <div class="icon">
          <i class="bx bx-conversation"></i>
          <div class="label">bx-conversation</div>
        </div>
        <div class="icon">
          <i class="bx bx-cookie"></i>
          <div class="label">bx-cookie</div>
        </div>
        <div class="icon">
          <i class="bx bx-cool"></i>
          <div class="label">bx-cool</div>
        </div>
        <div class="icon">
          <i class="bx bx-copy"></i>
          <div class="label">bx-copy</div>
        </div>
        <div class="icon">
          <i class="bx bx-copy-alt"></i>
          <div class="label">bx-copy-alt</div>
        </div>
        <div class="icon">
          <i class="bx bx-copyright"></i>
          <div class="label">bx-copyright</div>
        </div>
        <div class="icon">
          <i class="bx bx-credit-card"></i>
          <div class="label">bx-credit-card</div>
        </div>
        <div class="icon">
          <i class="bx bx-credit-card-alt"></i>
          <div class="label">bx-credit-card-alt</div>
        </div>
        <div class="icon">
          <i class="bx bx-credit-card-front"></i>
          <div class="label">bx-credit-card-front</div>
        </div>
        <div class="icon">
          <i class="bx bx-crop"></i>
          <div class="label">bx-crop</div>
        </div>
        <div class="icon">
          <i class="bx bx-crosshair"></i>
          <div class="label">bx-crosshair</div>
        </div>
        <div class="icon">
          <i class="bx bx-crown"></i>
          <div class="label">bx-crown</div>
        </div>
        <div class="icon">
          <i class="bx bx-cube"></i>
          <div class="label">bx-cube</div>
        </div>
        <div class="icon">
          <i class="bx bx-cube-alt"></i>
          <div class="label">bx-cube-alt</div>
        </div>
        <div class="icon">
          <i class="bx bx-cuboid"></i>
          <div class="label">bx-cuboid</div>
        </div>
        <div class="icon">
          <i class="bx bx-current-location"></i>
          <div class="label">bx-current-location</div>
        </div>
        <div class="icon">
          <i class="bx bx-customize"></i>
          <div class="label">bx-customize</div>
        </div>
        <div class="icon">
          <i class="bx bx-cut"></i>
          <div class="label">bx-cut</div>
        </div>
        <div class="icon">
          <i class="bx bx-cycling"></i>
          <div class="label">bx-cycling</div>
        </div>
        <div class="icon">
          <i class="bx bx-cylinder"></i>
          <div class="label">bx-cylinder</div>
        </div>
        <div class="icon">
          <i class="bx bx-data"></i>
          <div class="label">bx-data</div>
        </div>
        <div class="icon">
          <i class="bx bx-desktop"></i>
          <div class="label">bx-desktop</div>
        </div>
        <div class="icon">
          <i class="bx bx-detail"></i>
          <div class="label">bx-detail</div>
        </div>
        <div class="icon">
          <i class="bx bx-devices"></i>
          <div class="label">bx-devices</div>
        </div>
        <div class="icon">
          <i class="bx bx-dialpad"></i>
          <div class="label">bx-dialpad</div>
        </div>
        <div class="icon">
          <i class="bx bx-dialpad-alt"></i>
          <div class="label">bx-dialpad-alt</div>
        </div>
        <div class="icon">
          <i class="bx bx-diamond"></i>
          <div class="label">bx-diamond</div>
        </div>
        <div class="icon">
          <i class="bx bx-dice-1"></i>
          <div class="label">bx-dice-1</div>
        </div>
        <div class="icon">
          <i class="bx bx-dice-2"></i>
          <div class="label">bx-dice-2</div>
        </div>
        <div class="icon">
          <i class="bx bx-dice-3"></i>
          <div class="label">bx-dice-3</div>
        </div>
        <div class="icon">
          <i class="bx bx-dice-4"></i>
          <div class="label">bx-dice-4</div>
        </div>
        <div class="icon">
          <i class="bx bx-dice-5"></i>
          <div class="label">bx-dice-5</div>
        </div>
        <div class="icon">
          <i class="bx bx-dice-6"></i>
          <div class="label">bx-dice-6</div>
        </div>
        <div class="icon">
          <i class="bx bx-directions"></i>
          <div class="label">bx-directions</div>
        </div>
        <div class="icon">
          <i class="bx bx-disc"></i>
          <div class="label">bx-disc</div>
        </div>
        <div class="icon">
          <i class="bx bx-dish"></i>
          <div class="label">bx-dish</div>
        </div>
        <div class="icon">
          <i class="bx bx-dislike"></i>
          <div class="label">bx-dislike</div>
        </div>
        <div class="icon">
          <i class="bx bx-dizzy"></i>
          <div class="label">bx-dizzy</div>
        </div>
        <div class="icon">
          <i class="bx bx-dna"></i>
          <div class="label">bx-dna</div>
        </div>
        <div class="icon">
          <i class="bx bx-dock-bottom"></i>
          <div class="label">bx-dock-bottom</div>
        </div>
        <div class="icon">
          <i class="bx bx-dock-left"></i>
          <div class="label">bx-dock-left</div>
        </div>
        <div class="icon">
          <i class="bx bx-dock-right"></i>
          <div class="label">bx-dock-right</div>
        </div>
        <div class="icon">
          <i class="bx bx-dock-top"></i>
          <div class="label">bx-dock-top</div>
        </div>
        <div class="icon">
          <i class="bx bx-dollar"></i>
          <div class="label">bx-dollar</div>
        </div>
        <div class="icon">
          <i class="bx bx-dollar-circle"></i>
          <div class="label">bx-dollar-circle</div>
        </div>
        <div class="icon">
          <i class="bx bx-donate-blood"></i>
          <div class="label">bx-donate-blood</div>
        </div>
        <div class="icon">
          <i class="bx bx-donate-heart"></i>
          <div class="label">bx-donate-heart</div>
        </div>
        <div class="icon">
          <i class="bx bx-door-open"></i>
          <div class="label">bx-door-open</div>
        </div>
        <div class="icon">
          <i class="bx bx-dots-horizontal"></i>
          <div class="label">bx-dots-horizontal</div>
        </div>
        <div class="icon">
          <i class="bx bx-dots-horizontal-rounded"></i>
          <div class="label">bx-dots-horizontal-rounded</div>
        </div>
        <div class="icon">
          <i class="bx bx-dots-vertical"></i>
          <div class="label">bx-dots-vertical</div>
        </div>
        <div class="icon">
          <i class="bx bx-dots-vertical-rounded"></i>
          <div class="label">bx-dots-vertical-rounded</div>
        </div>
        <div class="icon">
          <i class="bx bx-doughnut-chart"></i>
          <div class="label">bx-doughnut-chart</div>
        </div>
        <div class="icon">
          <i class="bx bx-down-arrow"></i>
          <div class="label">bx-down-arrow</div>
        </div>
        <div class="icon">
          <i class="bx bx-down-arrow-alt"></i>
          <div class="label">bx-down-arrow-alt</div>
        </div>
        <div class="icon">
          <i class="bx bx-down-arrow-circle"></i>
          <div class="label">bx-down-arrow-circle</div>
        </div>
        <div class="icon">
          <i class="bx bx-download"></i>
          <div class="label">bx-download</div>
        </div>
        <div class="icon">
          <i class="bx bx-downvote"></i>
          <div class="label">bx-downvote</div>
        </div>
        <div class="icon">
          <i class="bx bx-drink"></i>
          <div class="label">bx-drink</div>
        </div>
        <div class="icon">
          <i class="bx bx-droplet"></i>
          <div class="label">bx-droplet</div>
        </div>
        <div class="icon">
          <i class="bx bx-dumbbell"></i>
          <div class="label">bx-dumbbell</div>
        </div>
        <div class="icon">
          <i class="bx bx-duplicate"></i>
          <div class="label">bx-duplicate</div>
        </div>
        <div class="icon">
          <i class="bx bx-edit"></i>
          <div class="label">bx-edit</div>
        </div>
        <div class="icon">
          <i class="bx bx-edit-alt"></i>
          <div class="label">bx-edit-alt</div>
        </div>
        <div class="icon">
          <i class="bx bx-envelope"></i>
          <div class="label">bx-envelope</div>
        </div>
        <div class="icon">
          <i class="bx bx-envelope-open"></i>
          <div class="label">bx-envelope-open</div>
        </div>
        <div class="icon">
          <i class="bx bx-equalizer"></i>
          <div class="label">bx-equalizer</div>
        </div>
        <div class="icon">
          <i class="bx bx-eraser"></i>
          <div class="label">bx-eraser</div>
        </div>
        <div class="icon">
          <i class="bx bx-error"></i>
          <div class="label">bx-error</div>
        </div>
        <div class="icon">
          <i class="bx bx-error-alt"></i>
          <div class="label">bx-error-alt</div>
        </div>
        <div class="icon">
          <i class="bx bx-error-circle"></i>
          <div class="label">bx-error-circle</div>
        </div>
        <div class="icon">
          <i class="bx bx-euro"></i>
          <div class="label">bx-euro</div>
        </div>
        <div class="icon">
          <i class="bx bx-exclude"></i>
          <div class="label">bx-exclude</div>
        </div>
        <div class="icon">
          <i class="bx bx-exit"></i>
          <div class="label">bx-exit</div>
        </div>
        <div class="icon">
          <i class="bx bx-exit-fullscreen"></i>
          <div class="label">bx-exit-fullscreen</div>
        </div>
        <div class="icon">
          <i class="bx bx-expand"></i>
          <div class="label">bx-expand</div>
        </div>
        <div class="icon">
          <i class="bx bx-expand-alt"></i>
          <div class="label">bx-expand-alt</div>
        </div>
        <div class="icon">
          <i class="bx bx-export"></i>
          <div class="label">bx-export</div>
        </div>
        <div class="icon">
          <i class="bx bx-extension"></i>
          <div class="label">bx-extension</div>
        </div>
        <div class="icon">
          <i class="bx bx-face"></i>
          <div class="label">bx-face</div>
        </div>
        <div class="icon">
          <i class="bx bx-fast-forward"></i>
          <div class="label">bx-fast-forward</div>
        </div>
        <div class="icon">
          <i class="bx bx-fast-forward-circle"></i>
          <div class="label">bx-fast-forward-circle</div>
        </div>
        <div class="icon">
          <i class="bx bx-female"></i>
          <div class="label">bx-female</div>
        </div>
        <div class="icon">
          <i class="bx bx-female-sign"></i>
          <div class="label">bx-female-sign</div>
        </div>
        <div class="icon">
          <i class="bx bx-file"></i>
          <div class="label">bx-file</div>
        </div>
        <div class="icon">
          <i class="bx bx-file-blank"></i>
          <div class="label">bx-file-blank</div>
        </div>
        <div class="icon">
          <i class="bx bx-file-find"></i>
          <div class="label">bx-file-find</div>
        </div>
        <div class="icon">
          <i class="bx bx-film"></i>
          <div class="label">bx-film</div>
        </div>
        <div class="icon">
          <i class="bx bx-filter"></i>
          <div class="label">bx-filter</div>
        </div>
        <div class="icon">
          <i class="bx bx-filter-alt"></i>
          <div class="label">bx-filter-alt</div>
        </div>
        <div class="icon">
          <i class="bx bx-fingerprint"></i>
          <div class="label">bx-fingerprint</div>
        </div>
        <div class="icon">
          <i class="bx bx-first-aid"></i>
          <div class="label">bx-first-aid</div>
        </div>
        <div class="icon">
          <i class="bx bx-first-page"></i>
          <div class="label">bx-first-page</div>
        </div>
        <div class="icon">
          <i class="bx bx-flag"></i>
          <div class="label">bx-flag</div>
        </div>
        <div class="icon">
          <i class="bx bx-folder"></i>
          <div class="label">bx-folder</div>
        </div>
        <div class="icon">
          <i class="bx bx-folder-minus"></i>
          <div class="label">bx-folder-minus</div>
        </div>
        <div class="icon">
          <i class="bx bx-folder-open"></i>
          <div class="label">bx-folder-open</div>
        </div>
        <div class="icon">
          <i class="bx bx-folder-plus"></i>
          <div class="label">bx-folder-plus</div>
        </div>
        <div class="icon">
          <i class="bx bx-font"></i>
          <div class="label">bx-font</div>
        </div>
        <div class="icon">
          <i class="bx bx-font-color"></i>
          <div class="label">bx-font-color</div>
        </div>
        <div class="icon">
          <i class="bx bx-font-family"></i>
          <div class="label">bx-font-family</div>
        </div>
        <div class="icon">
          <i class="bx bx-font-size"></i>
          <div class="label">bx-font-size</div>
        </div>
        <div class="icon">
          <i class="bx bx-food-menu"></i>
          <div class="label">bx-food-menu</div>
        </div>
        <div class="icon">
          <i class="bx bx-food-tag"></i>
          <div class="label">bx-food-tag</div>
        </div>
        <div class="icon">
          <i class="bx bx-football"></i>
          <div class="label">bx-football</div>
        </div>
        <div class="icon">
          <i class="bx bx-fridge"></i>
          <div class="label">bx-fridge</div>
        </div>
        <div class="icon">
          <i class="bx bx-fullscreen"></i>
          <div class="label">bx-fullscreen</div>
        </div>
        <div class="icon">
          <i class="bx bx-game"></i>
          <div class="label">bx-game</div>
        </div>
        <div class="icon">
          <i class="bx bx-gas-pump"></i>
          <div class="label">bx-gas-pump</div>
        </div>
        <div class="icon">
          <i class="bx bx-ghost"></i>
          <div class="label">bx-ghost</div>
        </div>
        <div class="icon">
          <i class="bx bx-gift"></i>
          <div class="label">bx-gift</div>
        </div>
        <div class="icon">
          <i class="bx bx-git-branch"></i>
          <div class="label">bx-git-branch</div>
        </div>
        <div class="icon">
          <i class="bx bx-git-commit"></i>
          <div class="label">bx-git-commit</div>
        </div>
        <div class="icon">
          <i class="bx bx-git-compare"></i>
          <div class="label">bx-git-compare</div>
        </div>
        <div class="icon">
          <i class="bx bx-git-merge"></i>
          <div class="label">bx-git-merge</div>
        </div>
        <div class="icon">
          <i class="bx bx-git-pull-request"></i>
          <div class="label">bx-git-pull-request</div>
        </div>
        <div class="icon">
          <i class="bx bx-git-repo-forked"></i>
          <div class="label">bx-git-repo-forked</div>
        </div>
        <div class="icon">
          <i class="bx bx-glasses"></i>
          <div class="label">bx-glasses</div>
        </div>
        <div class="icon">
          <i class="bx bx-glasses-alt"></i>
          <div class="label">bx-glasses-alt</div>
        </div>
        <div class="icon">
          <i class="bx bx-globe"></i>
          <div class="label">bx-globe</div>
        </div>
        <div class="icon">
          <i class="bx bx-globe-alt"></i>
          <div class="label">bx-globe-alt</div>
        </div>
        <div class="icon">
          <i class="bx bx-grid"></i>
          <div class="label">bx-grid</div>
        </div>
        <div class="icon">
          <i class="bx bx-grid-alt"></i>
          <div class="label">bx-grid-alt</div>
        </div>
        <div class="icon">
          <i class="bx bx-grid-horizontal"></i>
          <div class="label">bx-grid-horizontal</div>
        </div>
        <div class="icon">
          <i class="bx bx-grid-small"></i>
          <div class="label">bx-grid-small</div>
        </div>
        <div class="icon">
          <i class="bx bx-grid-vertical"></i>
          <div class="label">bx-grid-vertical</div>
        </div>
        <div class="icon">
          <i class="bx bx-group"></i>
          <div class="label">bx-group</div>
        </div>
        <div class="icon">
          <i class="bx bx-handicap"></i>
          <div class="label">bx-handicap</div>
        </div>
        <div class="icon">
          <i class="bx bx-happy"></i>
          <div class="label">bx-happy</div>
        </div>
        <div class="icon">
          <i class="bx bx-happy-alt"></i>
          <div class="label">bx-happy-alt</div>
        </div>
        <div class="icon">
          <i class="bx bx-happy-beaming"></i>
          <div class="label">bx-happy-beaming</div>
        </div>
        <div class="icon">
          <i class="bx bx-happy-heart-eyes"></i>
          <div class="label">bx-happy-heart-eyes</div>
        </div>
        <div class="icon">
          <i class="bx bx-hash"></i>
          <div class="label">bx-hash</div>
        </div>
        <div class="icon">
          <i class="bx bx-hdd"></i>
          <div class="label">bx-hdd</div>
        </div>
        <div class="icon">
          <i class="bx bx-heading"></i>
          <div class="label">bx-heading</div>
        </div>
        <div class="icon">
          <i class="bx bx-headphone"></i>
          <div class="label">bx-headphone</div>
        </div>
        <div class="icon">
          <i class="bx bx-health"></i>
          <div class="label">bx-health</div>
        </div>
        <div class="icon">
          <i class="bx bx-heart"></i>
          <div class="label">bx-heart</div>
        </div>
        <div class="icon">
          <i class="bx bx-heart-circle"></i>
          <div class="label">bx-heart-circle</div>
        </div>
        <div class="icon">
          <i class="bx bx-heart-square"></i>
          <div class="label">bx-heart-square</div>
        </div>
        <div class="icon">
          <i class="bx bx-help-circle"></i>
          <div class="label">bx-help-circle</div>
        </div>
        <div class="icon">
          <i class="bx bx-hide"></i>
          <div class="label">bx-hide</div>
        </div>
        <div class="icon">
          <i class="bx bx-highlight"></i>
          <div class="label">bx-highlight</div>
        </div>
        <div class="icon">
          <i class="bx bx-history"></i>
          <div class="label">bx-history</div>
        </div>
        <div class="icon">
          <i class="bx bx-hive"></i>
          <div class="label">bx-hive</div>
        </div>
        <div class="icon">
          <i class="bx bx-home"></i>
          <div class="label">bx-home</div>
        </div>
        <div class="icon">
          <i class="bx bx-home-alt"></i>
          <div class="label">bx-home-alt</div>
        </div>
        <div class="icon">
          <i class="bx bx-home-circle"></i>
          <div class="label">bx-home-circle</div>
        </div>
        <div class="icon">
          <i class="bx bx-home-heart"></i>
          <div class="label">bx-home-heart</div>
        </div>
        <div class="icon">
          <i class="bx bx-home-smile"></i>
          <div class="label">bx-home-smile</div>
        </div>
        <div class="icon">
          <i class="bx bx-horizontal-center"></i>
          <div class="label">bx-horizontal-center</div>
        </div>
        <div class="icon">
          <i class="bx bx-hotel"></i>
          <div class="label">bx-hotel</div>
        </div>
        <div class="icon">
          <i class="bx bx-hourglass"></i>
          <div class="label">bx-hourglass</div>
        </div>
        <div class="icon">
          <i class="bx bx-id-card"></i>
          <div class="label">bx-id-card</div>
        </div>
        <div class="icon">
          <i class="bx bx-image"></i>
          <div class="label">bx-image</div>
        </div>
        <div class="icon">
          <i class="bx bx-image-add"></i>
          <div class="label">bx-image-add</div>
        </div>
        <div class="icon">
          <i class="bx bx-image-alt"></i>
          <div class="label">bx-image-alt</div>
        </div>
        <div class="icon">
          <i class="bx bx-images"></i>
          <div class="label">bx-images</div>
        </div>
        <div class="icon">
          <i class="bx bx-import"></i>
          <div class="label">bx-import</div>
        </div>
        <div class="icon">
          <i class="bx bx-infinite"></i>
          <div class="label">bx-infinite</div>
        </div>
        <div class="icon">
          <i class="bx bx-info-circle"></i>
          <div class="label">bx-info-circle</div>
        </div>
        <div class="icon">
          <i class="bx bx-info-square"></i>
          <div class="label">bx-info-square</div>
        </div>
        <div class="icon">
          <i class="bx bx-intersect"></i>
          <div class="label">bx-intersect</div>
        </div>
        <div class="icon">
          <i class="bx bx-italic"></i>
          <div class="label">bx-italic</div>
        </div>
        <div class="icon">
          <i class="bx bx-joystick"></i>
          <div class="label">bx-joystick</div>
        </div>
        <div class="icon">
          <i class="bx bx-joystick-alt"></i>
          <div class="label">bx-joystick-alt</div>
        </div>
        <div class="icon">
          <i class="bx bx-joystick-button"></i>
          <div class="label">bx-joystick-button</div>
        </div>
        <div class="icon">
          <i class="bx bx-key"></i>
          <div class="label">bx-key</div>
        </div>
        <div class="icon">
          <i class="bx bx-label"></i>
          <div class="label">bx-label</div>
        </div>
        <div class="icon">
          <i class="bx bx-landscape"></i>
          <div class="label">bx-landscape</div>
        </div>
        <div class="icon">
          <i class="bx bx-laptop"></i>
          <div class="label">bx-laptop</div>
        </div>
        <div class="icon">
          <i class="bx bx-last-page"></i>
          <div class="label">bx-last-page</div>
        </div>
        <div class="icon">
          <i class="bx bx-laugh"></i>
          <div class="label">bx-laugh</div>
        </div>
        <div class="icon">
          <i class="bx bx-layer"></i>
          <div class="label">bx-layer</div>
        </div>
        <div class="icon">
          <i class="bx bx-layer-minus"></i>
          <div class="label">bx-layer-minus</div>
        </div>
        <div class="icon">
          <i class="bx bx-layer-plus"></i>
          <div class="label">bx-layer-plus</div>
        </div>
        <div class="icon">
          <i class="bx bx-layout"></i>
          <div class="label">bx-layout</div>
        </div>
        <div class="icon">
          <i class="bx bx-left-arrow"></i>
          <div class="label">bx-left-arrow</div>
        </div>
        <div class="icon">
          <i class="bx bx-left-arrow-alt"></i>
          <div class="label">bx-left-arrow-alt</div>
        </div>
        <div class="icon">
          <i class="bx bx-left-arrow-circle"></i>
          <div class="label">bx-left-arrow-circle</div>
        </div>
        <div class="icon">
          <i class="bx bx-left-down-arrow-circle"></i>
          <div class="label">bx-left-down-arrow-circle</div>
        </div>
        <div class="icon">
          <i class="bx bx-left-indent"></i>
          <div class="label">bx-left-indent</div>
        </div>
        <div class="icon">
          <i class="bx bx-left-top-arrow-circle"></i>
          <div class="label">bx-left-top-arrow-circle</div>
        </div>
        <div class="icon">
          <i class="bx bx-library"></i>
          <div class="label">bx-library</div>
        </div>
        <div class="icon">
          <i class="bx bx-like"></i>
          <div class="label">bx-like</div>
        </div>
        <div class="icon">
          <i class="bx bx-line-chart"></i>
          <div class="label">bx-line-chart</div>
        </div>
        <div class="icon">
          <i class="bx bx-line-chart-down"></i>
          <div class="label">bx-line-chart-down</div>
        </div>
        <div class="icon">
          <i class="bx bx-link"></i>
          <div class="label">bx-link</div>
        </div>
        <div class="icon">
          <i class="bx bx-link-alt"></i>
          <div class="label">bx-link-alt</div>
        </div>
        <div class="icon">
          <i class="bx bx-link-external"></i>
          <div class="label">bx-link-external</div>
        </div>
        <div class="icon">
          <i class="bx bx-lira"></i>
          <div class="label">bx-lira</div>
        </div>
        <div class="icon">
          <i class="bx bx-list-check"></i>
          <div class="label">bx-list-check</div>
        </div>
        <div class="icon">
          <i class="bx bx-list-minus"></i>
          <div class="label">bx-list-minus</div>
        </div>
        <div class="icon">
          <i class="bx bx-list-ol"></i>
          <div class="label">bx-list-ol</div>
        </div>
        <div class="icon">
          <i class="bx bx-list-plus"></i>
          <div class="label">bx-list-plus</div>
        </div>
        <div class="icon">
          <i class="bx bx-list-ul"></i>
          <div class="label">bx-list-ul</div>
        </div>
        <div class="icon">
          <i class="bx bx-loader"></i>
          <div class="label">bx-loader</div>
        </div>
        <div class="icon">
          <i class="bx bx-loader-alt"></i>
          <div class="label">bx-loader-alt</div>
        </div>
        <div class="icon">
          <i class="bx bx-loader-circle"></i>
          <div class="label">bx-loader-circle</div>
        </div>
        <div class="icon">
          <i class="bx bx-location-plus"></i>
          <div class="label">bx-location-plus</div>
        </div>
        <div class="icon">
          <i class="bx bx-lock"></i>
          <div class="label">bx-lock</div>
        </div>
        <div class="icon">
          <i class="bx bx-lock-alt"></i>
          <div class="label">bx-lock-alt</div>
        </div>
        <div class="icon">
          <i class="bx bx-lock-open"></i>
          <div class="label">bx-lock-open</div>
        </div>
        <div class="icon">
          <i class="bx bx-lock-open-alt"></i>
          <div class="label">bx-lock-open-alt</div>
        </div>
        <div class="icon">
          <i class="bx bx-log-in"></i>
          <div class="label">bx-log-in</div>
        </div>
        <div class="icon">
          <i class="bx bx-log-in-circle"></i>
          <div class="label">bx-log-in-circle</div>
        </div>
        <div class="icon">
          <i class="bx bx-log-out"></i>
          <div class="label">bx-log-out</div>
        </div>
        <div class="icon">
          <i class="bx bx-log-out-circle"></i>
          <div class="label">bx-log-out-circle</div>
        </div>
        <div class="icon">
          <i class="bx bx-low-vision"></i>
          <div class="label">bx-low-vision</div>
        </div>
        <div class="icon">
          <i class="bx bx-magnet"></i>
          <div class="label">bx-magnet</div>
        </div>
        <div class="icon">
          <i class="bx bx-mail-send"></i>
          <div class="label">bx-mail-send</div>
        </div>
        <div class="icon">
          <i class="bx bx-male"></i>
          <div class="label">bx-male</div>
        </div>
        <div class="icon">
          <i class="bx bx-male-sign"></i>
          <div class="label">bx-male-sign</div>
        </div>
        <div class="icon">
          <i class="bx bx-map"></i>
          <div class="label">bx-map</div>
        </div>
        <div class="icon">
          <i class="bx bx-map-alt"></i>
          <div class="label">bx-map-alt</div>
        </div>
        <div class="icon">
          <i class="bx bx-map-pin"></i>
          <div class="label">bx-map-pin</div>
        </div>
        <div class="icon">
          <i class="bx bx-mask"></i>
          <div class="label">bx-mask</div>
        </div>
        <div class="icon">
          <i class="bx bx-medal"></i>
          <div class="label">bx-medal</div>
        </div>
        <div class="icon">
          <i class="bx bx-meh"></i>
          <div class="label">bx-meh</div>
        </div>
        <div class="icon">
          <i class="bx bx-meh-alt"></i>
          <div class="label">bx-meh-alt</div>
        </div>
        <div class="icon">
          <i class="bx bx-meh-blank"></i>
          <div class="label">bx-meh-blank</div>
        </div>
        <div class="icon">
          <i class="bx bx-memory-card"></i>
          <div class="label">bx-memory-card</div>
        </div>
        <div class="icon">
          <i class="bx bx-menu"></i>
          <div class="label">bx-menu</div>
        </div>
        <div class="icon">
          <i class="bx bx-menu-alt-left"></i>
          <div class="label">bx-menu-alt-left</div>
        </div>
        <div class="icon">
          <i class="bx bx-menu-alt-right"></i>
          <div class="label">bx-menu-alt-right</div>
        </div>
        <div class="icon">
          <i class="bx bx-merge"></i>
          <div class="label">bx-merge</div>
        </div>
        <div class="icon">
          <i class="bx bx-message"></i>
          <div class="label">bx-message</div>
        </div>
        <div class="icon">
          <i class="bx bx-message-add"></i>
          <div class="label">bx-message-add</div>
        </div>
        <div class="icon">
          <i class="bx bx-message-alt"></i>
          <div class="label">bx-message-alt</div>
        </div>
        <div class="icon">
          <i class="bx bx-message-alt-add"></i>
          <div class="label">bx-message-alt-add</div>
        </div>
        <div class="icon">
          <i class="bx bx-message-alt-check"></i>
          <div class="label">bx-message-alt-check</div>
        </div>
        <div class="icon">
          <i class="bx bx-message-alt-detail"></i>
          <div class="label">bx-message-alt-detail</div>
        </div>
        <div class="icon">
          <i class="bx bx-message-alt-dots"></i>
          <div class="label">bx-message-alt-dots</div>
        </div>
        <div class="icon">
          <i class="bx bx-message-alt-edit"></i>
          <div class="label">bx-message-alt-edit</div>
        </div>
        <div class="icon">
          <i class="bx bx-message-alt-error"></i>
          <div class="label">bx-message-alt-error</div>
        </div>
        <div class="icon">
          <i class="bx bx-message-alt-minus"></i>
          <div class="label">bx-message-alt-minus</div>
        </div>
        <div class="icon">
          <i class="bx bx-message-alt-x"></i>
          <div class="label">bx-message-alt-x</div>
        </div>
        <div class="icon">
          <i class="bx bx-message-check"></i>
          <div class="label">bx-message-check</div>
        </div>
        <div class="icon">
          <i class="bx bx-message-detail"></i>
          <div class="label">bx-message-detail</div>
        </div>
        <div class="icon">
          <i class="bx bx-message-dots"></i>
          <div class="label">bx-message-dots</div>
        </div>
        <div class="icon">
          <i class="bx bx-message-edit"></i>
          <div class="label">bx-message-edit</div>
        </div>
        <div class="icon">
          <i class="bx bx-message-error"></i>
          <div class="label">bx-message-error</div>
        </div>
        <div class="icon">
          <i class="bx bx-message-minus"></i>
          <div class="label">bx-message-minus</div>
        </div>
        <div class="icon">
          <i class="bx bx-message-rounded"></i>
          <div class="label">bx-message-rounded</div>
        </div>
        <div class="icon">
          <i class="bx bx-message-rounded-add"></i>
          <div class="label">bx-message-rounded-add</div>
        </div>
        <div class="icon">
          <i class="bx bx-message-rounded-check"></i>
          <div class="label">bx-message-rounded-check</div>
        </div>
        <div class="icon">
          <i class="bx bx-message-rounded-detail"></i>
          <div class="label">bx-message-rounded-detail</div>
        </div>
        <div class="icon">
          <i class="bx bx-message-rounded-dots"></i>
          <div class="label">bx-message-rounded-dots</div>
        </div>
        <div class="icon">
          <i class="bx bx-message-rounded-edit"></i>
          <div class="label">bx-message-rounded-edit</div>
        </div>
        <div class="icon">
          <i class="bx bx-message-rounded-error"></i>
          <div class="label">bx-message-rounded-error</div>
        </div>
        <div class="icon">
          <i class="bx bx-message-rounded-minus"></i>
          <div class="label">bx-message-rounded-minus</div>
        </div>
        <div class="icon">
          <i class="bx bx-message-rounded-x"></i>
          <div class="label">bx-message-rounded-x</div>
        </div>
        <div class="icon">
          <i class="bx bx-message-square"></i>
          <div class="label">bx-message-square</div>
        </div>
        <div class="icon">
          <i class="bx bx-message-square-add"></i>
          <div class="label">bx-message-square-add</div>
        </div>
        <div class="icon">
          <i class="bx bx-message-square-check"></i>
          <div class="label">bx-message-square-check</div>
        </div>
        <div class="icon">
          <i class="bx bx-message-square-detail"></i>
          <div class="label">bx-message-square-detail</div>
        </div>
        <div class="icon">
          <i class="bx bx-message-square-dots"></i>
          <div class="label">bx-message-square-dots</div>
        </div>
        <div class="icon">
          <i class="bx bx-message-square-edit"></i>
          <div class="label">bx-message-square-edit</div>
        </div>
        <div class="icon">
          <i class="bx bx-message-square-error"></i>
          <div class="label">bx-message-square-error</div>
        </div>
        <div class="icon">
          <i class="bx bx-message-square-minus"></i>
          <div class="label">bx-message-square-minus</div>
        </div>
        <div class="icon">
          <i class="bx bx-message-square-x"></i>
          <div class="label">bx-message-square-x</div>
        </div>
        <div class="icon">
          <i class="bx bx-message-x"></i>
          <div class="label">bx-message-x</div>
        </div>
        <div class="icon">
          <i class="bx bx-meteor"></i>
          <div class="label">bx-meteor</div>
        </div>
        <div class="icon">
          <i class="bx bx-microchip"></i>
          <div class="label">bx-microchip</div>
        </div>
        <div class="icon">
          <i class="bx bx-microphone"></i>
          <div class="label">bx-microphone</div>
        </div>
        <div class="icon">
          <i class="bx bx-microphone-off"></i>
          <div class="label">bx-microphone-off</div>
        </div>
        <div class="icon">
          <i class="bx bx-minus"></i>
          <div class="label">bx-minus</div>
        </div>
        <div class="icon">
          <i class="bx bx-minus-back"></i>
          <div class="label">bx-minus-back</div>
        </div>
        <div class="icon">
          <i class="bx bx-minus-circle"></i>
          <div class="label">bx-minus-circle</div>
        </div>
        <div class="icon">
          <i class="bx bx-minus-front"></i>
          <div class="label">bx-minus-front</div>
        </div>
        <div class="icon">
          <i class="bx bx-mobile"></i>
          <div class="label">bx-mobile</div>
        </div>
        <div class="icon">
          <i class="bx bx-mobile-alt"></i>
          <div class="label">bx-mobile-alt</div>
        </div>
        <div class="icon">
          <i class="bx bx-mobile-landscape"></i>
          <div class="label">bx-mobile-landscape</div>
        </div>
        <div class="icon">
          <i class="bx bx-mobile-vibration"></i>
          <div class="label">bx-mobile-vibration</div>
        </div>
        <div class="icon">
          <i class="bx bx-money"></i>
          <div class="label">bx-money</div>
        </div>
        <div class="icon">
          <i class="bx bx-moon"></i>
          <div class="label">bx-moon</div>
        </div>
        <div class="icon">
          <i class="bx bx-mouse"></i>
          <div class="label">bx-mouse</div>
        </div>
        <div class="icon">
          <i class="bx bx-mouse-alt"></i>
          <div class="label">bx-mouse-alt</div>
        </div>
        <div class="icon">
          <i class="bx bx-move"></i>
          <div class="label">bx-move</div>
        </div>
        <div class="icon">
          <i class="bx bx-move-horizontal"></i>
          <div class="label">bx-move-horizontal</div>
        </div>
        <div class="icon">
          <i class="bx bx-move-vertical"></i>
          <div class="label">bx-move-vertical</div>
        </div>
        <div class="icon">
          <i class="bx bx-movie"></i>
          <div class="label">bx-movie</div>
        </div>
        <div class="icon">
          <i class="bx bx-movie-play"></i>
          <div class="label">bx-movie-play</div>
        </div>
        <div class="icon">
          <i class="bx bx-music"></i>
          <div class="label">bx-music</div>
        </div>
        <div class="icon">
          <i class="bx bx-navigation"></i>
          <div class="label">bx-navigation</div>
        </div>
        <div class="icon">
          <i class="bx bx-network-chart"></i>
          <div class="label">bx-network-chart</div>
        </div>
        <div class="icon">
          <i class="bx bx-news"></i>
          <div class="label">bx-news</div>
        </div>
        <div class="icon">
          <i class="bx bx-no-entry"></i>
          <div class="label">bx-no-entry</div>
        </div>
        <div class="icon">
          <i class="bx bx-note"></i>
          <div class="label">bx-note</div>
        </div>
        <div class="icon">
          <i class="bx bx-notepad"></i>
          <div class="label">bx-notepad</div>
        </div>
        <div class="icon">
          <i class="bx bx-notification"></i>
          <div class="label">bx-notification</div>
        </div>
        <div class="icon">
          <i class="bx bx-notification-off"></i>
          <div class="label">bx-notification-off</div>
        </div>
        <div class="icon">
          <i class="bx bx-outline"></i>
          <div class="label">bx-outline</div>
        </div>
        <div class="icon">
          <i class="bx bx-package"></i>
          <div class="label">bx-package</div>
        </div>
        <div class="icon">
          <i class="bx bx-paint"></i>
          <div class="label">bx-paint</div>
        </div>
        <div class="icon">
          <i class="bx bx-paint-roll"></i>
          <div class="label">bx-paint-roll</div>
        </div>
        <div class="icon">
          <i class="bx bx-palette"></i>
          <div class="label">bx-palette</div>
        </div>
        <div class="icon">
          <i class="bx bx-paperclip"></i>
          <div class="label">bx-paperclip</div>
        </div>
        <div class="icon">
          <i class="bx bx-paper-plane"></i>
          <div class="label">bx-paper-plane</div>
        </div>
        <div class="icon">
          <i class="bx bx-paragraph"></i>
          <div class="label">bx-paragraph</div>
        </div>
        <div class="icon">
          <i class="bx bx-paste"></i>
          <div class="label">bx-paste</div>
        </div>
        <div class="icon">
          <i class="bx bx-pause"></i>
          <div class="label">bx-pause</div>
        </div>
        <div class="icon">
          <i class="bx bx-pause-circle"></i>
          <div class="label">bx-pause-circle</div>
        </div>
        <div class="icon">
          <i class="bx bx-pen"></i>
          <div class="label">bx-pen</div>
        </div>
        <div class="icon">
          <i class="bx bx-pencil"></i>
          <div class="label">bx-pencil</div>
        </div>
        <div class="icon">
          <i class="bx bx-phone"></i>
          <div class="label">bx-phone</div>
        </div>
        <div class="icon">
          <i class="bx bx-phone-call"></i>
          <div class="label">bx-phone-call</div>
        </div>
        <div class="icon">
          <i class="bx bx-phone-incoming"></i>
          <div class="label">bx-phone-incoming</div>
        </div>
        <div class="icon">
          <i class="bx bx-phone-off"></i>
          <div class="label">bx-phone-off</div>
        </div>
        <div class="icon">
          <i class="bx bx-phone-outgoing"></i>
          <div class="label">bx-phone-outgoing</div>
        </div>
        <div class="icon">
          <i class="bx bx-photo-album"></i>
          <div class="label">bx-photo-album</div>
        </div>
        <div class="icon">
          <i class="bx bx-pie-chart"></i>
          <div class="label">bx-pie-chart</div>
        </div>
        <div class="icon">
          <i class="bx bx-pie-chart-alt"></i>
          <div class="label">bx-pie-chart-alt</div>
        </div>
        <div class="icon">
          <i class="bx bx-pie-chart-alt-2"></i>
          <div class="label">bx-pie-chart-alt-2</div>
        </div>
        <div class="icon">
          <i class="bx bx-pin"></i>
          <div class="label">bx-pin</div>
        </div>
        <div class="icon">
          <i class="bx bx-planet"></i>
          <div class="label">bx-planet</div>
        </div>
        <div class="icon">
          <i class="bx bx-play"></i>
          <div class="label">bx-play</div>
        </div>
        <div class="icon">
          <i class="bx bx-play-circle"></i>
          <div class="label">bx-play-circle</div>
        </div>
        <div class="icon">
          <i class="bx bx-plug"></i>
          <div class="label">bx-plug</div>
        </div>
        <div class="icon">
          <i class="bx bx-plus"></i>
          <div class="label">bx-plus</div>
        </div>
        <div class="icon">
          <i class="bx bx-plus-circle"></i>
          <div class="label">bx-plus-circle</div>
        </div>
        <div class="icon">
          <i class="bx bx-plus-medical"></i>
          <div class="label">bx-plus-medical</div>
        </div>
        <div class="icon">
          <i class="bx bx-podcast"></i>
          <div class="label">bx-podcast</div>
        </div>
        <div class="icon">
          <i class="bx bx-pointer"></i>
          <div class="label">bx-pointer</div>
        </div>
        <div class="icon">
          <i class="bx bx-poll"></i>
          <div class="label">bx-poll</div>
        </div>
        <div class="icon">
          <i class="bx bx-polygon"></i>
          <div class="label">bx-polygon</div>
        </div>
        <div class="icon">
          <i class="bx bx-pound"></i>
          <div class="label">bx-pound</div>
        </div>
        <div class="icon">
          <i class="bx bx-power-off"></i>
          <div class="label">bx-power-off</div>
        </div>
        <div class="icon">
          <i class="bx bx-printer"></i>
          <div class="label">bx-printer</div>
        </div>
        <div class="icon">
          <i class="bx bx-pulse"></i>
          <div class="label">bx-pulse</div>
        </div>
        <div class="icon">
          <i class="bx bx-purchase-tag"></i>
          <div class="label">bx-purchase-tag</div>
        </div>
        <div class="icon">
          <i class="bx bx-purchase-tag-alt"></i>
          <div class="label">bx-purchase-tag-alt</div>
        </div>
        <div class="icon">
          <i class="bx bx-pyramid"></i>
          <div class="label">bx-pyramid</div>
        </div>
        <div class="icon">
          <i class="bx bx-qr"></i>
          <div class="label">bx-qr</div>
        </div>
        <div class="icon">
          <i class="bx bx-qr-scan"></i>
          <div class="label">bx-qr-scan</div>
        </div>
        <div class="icon">
          <i class="bx bx-question-mark"></i>
          <div class="label">bx-question-mark</div>
        </div>
        <div class="icon">
          <i class="bx bx-radar"></i>
          <div class="label">bx-radar</div>
        </div>
        <div class="icon">
          <i class="bx bx-radio"></i>
          <div class="label">bx-radio</div>
        </div>
        <div class="icon">
          <i class="bx bx-radio-circle"></i>
          <div class="label">bx-radio-circle</div>
        </div>
        <div class="icon">
          <i class="bx bx-radio-circle-marked"></i>
          <div class="label">bx-radio-circle-marked</div>
        </div>
        <div class="icon">
          <i class="bx bx-receipt"></i>
          <div class="label">bx-receipt</div>
        </div>
        <div class="icon">
          <i class="bx bx-rectangle"></i>
          <div class="label">bx-rectangle</div>
        </div>
        <div class="icon">
          <i class="bx bx-recycle"></i>
          <div class="label">bx-recycle</div>
        </div>
        <div class="icon">
          <i class="bx bx-redo"></i>
          <div class="label">bx-redo</div>
        </div>
        <div class="icon">
          <i class="bx bx-refresh"></i>
          <div class="label">bx-refresh</div>
        </div>
        <div class="icon">
          <i class="bx bx-registered"></i>
          <div class="label">bx-registered</div>
        </div>
        <div class="icon">
          <i class="bx bx-rename"></i>
          <div class="label">bx-rename</div>
        </div>
        <div class="icon">
          <i class="bx bx-repeat"></i>
          <div class="label">bx-repeat</div>
        </div>
        <div class="icon">
          <i class="bx bx-reply"></i>
          <div class="label">bx-reply</div>
        </div>
        <div class="icon">
          <i class="bx bx-reply-all"></i>
          <div class="label">bx-reply-all</div>
        </div>
        <div class="icon">
          <i class="bx bx-repost"></i>
          <div class="label">bx-repost</div>
        </div>
        <div class="icon">
          <i class="bx bx-reset"></i>
          <div class="label">bx-reset</div>
        </div>
        <div class="icon">
          <i class="bx bx-restaurant"></i>
          <div class="label">bx-restaurant</div>
        </div>
        <div class="icon">
          <i class="bx bx-revision"></i>
          <div class="label">bx-revision</div>
        </div>
        <div class="icon">
          <i class="bx bx-rewind"></i>
          <div class="label">bx-rewind</div>
        </div>
        <div class="icon">
          <i class="bx bx-rewind-circle"></i>
          <div class="label">bx-rewind-circle</div>
        </div>
        <div class="icon">
          <i class="bx bx-right-arrow"></i>
          <div class="label">bx-right-arrow</div>
        </div>
        <div class="icon">
          <i class="bx bx-right-arrow-alt"></i>
          <div class="label">bx-right-arrow-alt</div>
        </div>
        <div class="icon">
          <i class="bx bx-right-arrow-circle"></i>
          <div class="label">bx-right-arrow-circle</div>
        </div>
        <div class="icon">
          <i class="bx bx-right-down-arrow-circle"></i>
          <div class="label">bx-right-down-arrow-circle</div>
        </div>
        <div class="icon">
          <i class="bx bx-right-indent"></i>
          <div class="label">bx-right-indent</div>
        </div>
        <div class="icon">
          <i class="bx bx-right-top-arrow-circle"></i>
          <div class="label">bx-right-top-arrow-circle</div>
        </div>
        <div class="icon">
          <i class="bx bx-rocket"></i>
          <div class="label">bx-rocket</div>
        </div>
        <div class="icon">
          <i class="bx bx-rotate-left"></i>
          <div class="label">bx-rotate-left</div>
        </div>
        <div class="icon">
          <i class="bx bx-rotate-right"></i>
          <div class="label">bx-rotate-right</div>
        </div>
        <div class="icon">
          <i class="bx bx-rss"></i>
          <div class="label">bx-rss</div>
        </div>
        <div class="icon">
          <i class="bx bx-ruble"></i>
          <div class="label">bx-ruble</div>
        </div>
        <div class="icon">
          <i class="bx bx-ruler"></i>
          <div class="label">bx-ruler</div>
        </div>
        <div class="icon">
          <i class="bx bx-run"></i>
          <div class="label">bx-run</div>
        </div>
        <div class="icon">
          <i class="bx bx-rupee"></i>
          <div class="label">bx-rupee</div>
        </div>
        <div class="icon">
          <i class="bx bx-sad"></i>
          <div class="label">bx-sad</div>
        </div>
        <div class="icon">
          <i class="bx bx-save"></i>
          <div class="label">bx-save</div>
        </div>
        <div class="icon">
          <i class="bx bx-scan"></i>
          <div class="label">bx-scan</div>
        </div>
        <div class="icon">
          <i class="bx bx-screenshot"></i>
          <div class="label">bx-screenshot</div>
        </div>
        <div class="icon">
          <i class="bx bx-search"></i>
          <div class="label">bx-search</div>
        </div>
        <div class="icon">
          <i class="bx bx-search-alt"></i>
          <div class="label">bx-search-alt</div>
        </div>
        <div class="icon">
          <i class="bx bx-search-alt-2"></i>
          <div class="label">bx-search-alt-2</div>
        </div>
        <div class="icon">
          <i class="bx bx-selection"></i>
          <div class="label">bx-selection</div>
        </div>
        <div class="icon">
          <i class="bx bx-select-multiple"></i>
          <div class="label">bx-select-multiple</div>
        </div>
        <div class="icon">
          <i class="bx bx-send"></i>
          <div class="label">bx-send</div>
        </div>
        <div class="icon">
          <i class="bx bx-server"></i>
          <div class="label">bx-server</div>
        </div>
        <div class="icon">
          <i class="bx bx-shape-circle"></i>
          <div class="label">bx-shape-circle</div>
        </div>
        <div class="icon">
          <i class="bx bx-shape-polygon"></i>
          <div class="label">bx-shape-polygon</div>
        </div>
        <div class="icon">
          <i class="bx bx-shape-square"></i>
          <div class="label">bx-shape-square</div>
        </div>
        <div class="icon">
          <i class="bx bx-shape-triangle"></i>
          <div class="label">bx-shape-triangle</div>
        </div>
        <div class="icon">
          <i class="bx bx-share"></i>
          <div class="label">bx-share</div>
        </div>
        <div class="icon">
          <i class="bx bx-share-alt"></i>
          <div class="label">bx-share-alt</div>
        </div>
        <div class="icon">
          <i class="bx bx-shekel"></i>
          <div class="label">bx-shekel</div>
        </div>
        <div class="icon">
          <i class="bx bx-shield"></i>
          <div class="label">bx-shield</div>
        </div>
        <div class="icon">
          <i class="bx bx-shield-alt"></i>
          <div class="label">bx-shield-alt</div>
        </div>
        <div class="icon">
          <i class="bx bx-shield-alt-2"></i>
          <div class="label">bx-shield-alt-2</div>
        </div>
        <div class="icon">
          <i class="bx bx-shield-quarter"></i>
          <div class="label">bx-shield-quarter</div>
        </div>
        <div class="icon">
          <i class="bx bx-shield-x"></i>
          <div class="label">bx-shield-x</div>
        </div>
        <div class="icon">
          <i class="bx bx-shocked"></i>
          <div class="label">bx-shocked</div>
        </div>
        <div class="icon">
          <i class="bx bx-shopping-bag"></i>
          <div class="label">bx-shopping-bag</div>
        </div>
        <div class="icon">
          <i class="bx bx-show"></i>
          <div class="label">bx-show</div>
        </div>
        <div class="icon">
          <i class="bx bx-show-alt"></i>
          <div class="label">bx-show-alt</div>
        </div>
        <div class="icon">
          <i class="bx bx-shuffle"></i>
          <div class="label">bx-shuffle</div>
        </div>
        <div class="icon">
          <i class="bx bx-sidebar"></i>
          <div class="label">bx-sidebar</div>
        </div>
        <div class="icon">
          <i class="bx bx-sitemap"></i>
          <div class="label">bx-sitemap</div>
        </div>
        <div class="icon">
          <i class="bx bx-skip-next"></i>
          <div class="label">bx-skip-next</div>
        </div>
        <div class="icon">
          <i class="bx bx-skip-next-circle"></i>
          <div class="label">bx-skip-next-circle</div>
        </div>
        <div class="icon">
          <i class="bx bx-skip-previous"></i>
          <div class="label">bx-skip-previous</div>
        </div>
        <div class="icon">
          <i class="bx bx-skip-previous-circle"></i>
          <div class="label">bx-skip-previous-circle</div>
        </div>
        <div class="icon">
          <i class="bx bx-sleepy"></i>
          <div class="label">bx-sleepy</div>
        </div>
        <div class="icon">
          <i class="bx bx-slider"></i>
          <div class="label">bx-slider</div>
        </div>
        <div class="icon">
          <i class="bx bx-slider-alt"></i>
          <div class="label">bx-slider-alt</div>
        </div>
        <div class="icon">
          <i class="bx bx-slideshow"></i>
          <div class="label">bx-slideshow</div>
        </div>
        <div class="icon">
          <i class="bx bx-smile"></i>
          <div class="label">bx-smile</div>
        </div>
        <div class="icon">
          <i class="bx bx-sort"></i>
          <div class="label">bx-sort</div>
        </div>
        <div class="icon">
          <i class="bx bx-sort-alt-2"></i>
          <div class="label">bx-sort-alt-2</div>
        </div>
        <div class="icon">
          <i class="bx bx-sort-a-z"></i>
          <div class="label">bx-sort-a-z</div>
        </div>
        <div class="icon">
          <i class="bx bx-sort-down"></i>
          <div class="label">bx-sort-down</div>
        </div>
        <div class="icon">
          <i class="bx bx-sort-up"></i>
          <div class="label">bx-sort-up</div>
        </div>
        <div class="icon">
          <i class="bx bx-sort-z-a"></i>
          <div class="label">bx-sort-z-a</div>
        </div>
        <div class="icon">
          <i class="bx bx-spa"></i>
          <div class="label">bx-spa</div>
        </div>
        <div class="icon">
          <i class="bx bx-space-bar"></i>
          <div class="label">bx-space-bar</div>
        </div>
        <div class="icon">
          <i class="bx bx-speaker"></i>
          <div class="label">bx-speaker</div>
        </div>
        <div class="icon">
          <i class="bx bx-spray-can"></i>
          <div class="label">bx-spray-can</div>
        </div>
        <div class="icon">
          <i class="bx bx-spreadsheet"></i>
          <div class="label">bx-spreadsheet</div>
        </div>
        <div class="icon">
          <i class="bx bx-square"></i>
          <div class="label">bx-square</div>
        </div>
        <div class="icon">
          <i class="bx bx-square-rounded"></i>
          <div class="label">bx-square-rounded</div>
        </div>
        <div class="icon">
          <i class="bx bx-star"></i>
          <div class="label">bx-star</div>
        </div>
        <div class="icon">
          <i class="bx bx-station"></i>
          <div class="label">bx-station</div>
        </div>
        <div class="icon">
          <i class="bx bx-stats"></i>
          <div class="label">bx-stats</div>
        </div>
        <div class="icon">
          <i class="bx bx-sticker"></i>
          <div class="label">bx-sticker</div>
        </div>
        <div class="icon">
          <i class="bx bx-stop"></i>
          <div class="label">bx-stop</div>
        </div>
        <div class="icon">
          <i class="bx bx-stop-circle"></i>
          <div class="label">bx-stop-circle</div>
        </div>
        <div class="icon">
          <i class="bx bx-stopwatch"></i>
          <div class="label">bx-stopwatch</div>
        </div>
        <div class="icon">
          <i class="bx bx-store"></i>
          <div class="label">bx-store</div>
        </div>
        <div class="icon">
          <i class="bx bx-store-alt"></i>
          <div class="label">bx-store-alt</div>
        </div>
        <div class="icon">
          <i class="bx bx-street-view"></i>
          <div class="label">bx-street-view</div>
        </div>
        <div class="icon">
          <i class="bx bx-strikethrough"></i>
          <div class="label">bx-strikethrough</div>
        </div>
        <div class="icon">
          <i class="bx bx-subdirectory-left"></i>
          <div class="label">bx-subdirectory-left</div>
        </div>
        <div class="icon">
          <i class="bx bx-subdirectory-right"></i>
          <div class="label">bx-subdirectory-right</div>
        </div>
        <div class="icon">
          <i class="bx bx-sun"></i>
          <div class="label">bx-sun</div>
        </div>
        <div class="icon">
          <i class="bx bx-support"></i>
          <div class="label">bx-support</div>
        </div>
        <div class="icon">
          <i class="bx bx-swim"></i>
          <div class="label">bx-swim</div>
        </div>
        <div class="icon">
          <i class="bx bx-sync"></i>
          <div class="label">bx-sync</div>
        </div>
        <div class="icon">
          <i class="bx bx-tab"></i>
          <div class="label">bx-tab</div>
        </div>
        <div class="icon">
          <i class="bx bx-table"></i>
          <div class="label">bx-table</div>
        </div>
        <div class="icon">
          <i class="bx bx-tachometer"></i>
          <div class="label">bx-tachometer</div>
        </div>
        <div class="icon">
          <i class="bx bx-tag"></i>
          <div class="label">bx-tag</div>
        </div>
        <div class="icon">
          <i class="bx bx-tag-alt"></i>
          <div class="label">bx-tag-alt</div>
        </div>
        <div class="icon">
          <i class="bx bx-target-lock"></i>
          <div class="label">bx-target-lock</div>
        </div>
        <div class="icon">
          <i class="bx bx-task"></i>
          <div class="label">bx-task</div>
        </div>
        <div class="icon">
          <i class="bx bx-task-x"></i>
          <div class="label">bx-task-x</div>
        </div>
        <div class="icon">
          <i class="bx bx-taxi"></i>
          <div class="label">bx-taxi</div>
        </div>
        <div class="icon">
          <i class="bx bx-tennis-ball"></i>
          <div class="label">bx-tennis-ball</div>
        </div>
        <div class="icon">
          <i class="bx bx-terminal"></i>
          <div class="label">bx-terminal</div>
        </div>
        <div class="icon">
          <i class="bx bx-test-tube"></i>
          <div class="label">bx-test-tube</div>
        </div>
        <div class="icon">
          <i class="bx bx-text"></i>
          <div class="label">bx-text</div>
        </div>
        <div class="icon">
          <i class="bx bx-time"></i>
          <div class="label">bx-time</div>
        </div>
        <div class="icon">
          <i class="bx bx-time-five"></i>
          <div class="label">bx-time-five</div>
        </div>
        <div class="icon">
          <i class="bx bx-timer"></i>
          <div class="label">bx-timer</div>
        </div>
        <div class="icon">
          <i class="bx bx-tired"></i>
          <div class="label">bx-tired</div>
        </div>
        <div class="icon">
          <i class="bx bx-toggle-left"></i>
          <div class="label">bx-toggle-left</div>
        </div>
        <div class="icon">
          <i class="bx bx-toggle-right"></i>
          <div class="label">bx-toggle-right</div>
        </div>
        <div class="icon">
          <i class="bx bx-tone"></i>
          <div class="label">bx-tone</div>
        </div>
        <div class="icon">
          <i class="bx bx-traffic-cone"></i>
          <div class="label">bx-traffic-cone</div>
        </div>
        <div class="icon">
          <i class="bx bx-train"></i>
          <div class="label">bx-train</div>
        </div>
        <div class="icon">
          <i class="bx bx-transfer"></i>
          <div class="label">bx-transfer</div>
        </div>
        <div class="icon">
          <i class="bx bx-transfer-alt"></i>
          <div class="label">bx-transfer-alt</div>
        </div>
        <div class="icon">
          <i class="bx bx-trash"></i>
          <div class="label">bx-trash</div>
        </div>
        <div class="icon">
          <i class="bx bx-trash-alt"></i>
          <div class="label">bx-trash-alt</div>
        </div>
        <div class="icon">
          <i class="bx bx-trending-down"></i>
          <div class="label">bx-trending-down</div>
        </div>
        <div class="icon">
          <i class="bx bx-trending-up"></i>
          <div class="label">bx-trending-up</div>
        </div>
        <div class="icon">
          <i class="bx bx-trim"></i>
          <div class="label">bx-trim</div>
        </div>
        <div class="icon">
          <i class="bx bx-trip"></i>
          <div class="label">bx-trip</div>
        </div>
        <div class="icon">
          <i class="bx bx-trophy"></i>
          <div class="label">bx-trophy</div>
        </div>
        <div class="icon">
          <i class="bx bx-tv"></i>
          <div class="label">bx-tv</div>
        </div>
        <div class="icon">
          <i class="bx bx-underline"></i>
          <div class="label">bx-underline</div>
        </div>
        <div class="icon">
          <i class="bx bx-undo"></i>
          <div class="label">bx-undo</div>
        </div>
        <div class="icon">
          <i class="bx bx-unite"></i>
          <div class="label">bx-unite</div>
        </div>
        <div class="icon">
          <i class="bx bx-unlink"></i>
          <div class="label">bx-unlink</div>
        </div>
        <div class="icon">
          <i class="bx bx-up-arrow"></i>
          <div class="label">bx-up-arrow</div>
        </div>
        <div class="icon">
          <i class="bx bx-up-arrow-alt"></i>
          <div class="label">bx-up-arrow-alt</div>
        </div>
        <div class="icon">
          <i class="bx bx-up-arrow-circle"></i>
          <div class="label">bx-up-arrow-circle</div>
        </div>
        <div class="icon">
          <i class="bx bx-upload"></i>
          <div class="label">bx-upload</div>
        </div>
        <div class="icon">
          <i class="bx bx-upside-down"></i>
          <div class="label">bx-upside-down</div>
        </div>
        <div class="icon">
          <i class="bx bx-upvote"></i>
          <div class="label">bx-upvote</div>
        </div>
        <div class="icon">
          <i class="bx bx-usb"></i>
          <div class="label">bx-usb</div>
        </div>
        <div class="icon">
          <i class="bx bx-user"></i>
          <div class="label">bx-user</div>
        </div>
        <div class="icon">
          <i class="bx bx-user-check"></i>
          <div class="label">bx-user-check</div>
        </div>
        <div class="icon">
          <i class="bx bx-user-circle"></i>
          <div class="label">bx-user-circle</div>
        </div>
        <div class="icon">
          <i class="bx bx-user-minus"></i>
          <div class="label">bx-user-minus</div>
        </div>
        <div class="icon">
          <i class="bx bx-user-pin"></i>
          <div class="label">bx-user-pin</div>
        </div>
        <div class="icon">
          <i class="bx bx-user-plus"></i>
          <div class="label">bx-user-plus</div>
        </div>
        <div class="icon">
          <i class="bx bx-user-voice"></i>
          <div class="label">bx-user-voice</div>
        </div>
        <div class="icon">
          <i class="bx bx-user-x"></i>
          <div class="label">bx-user-x</div>
        </div>
        <div class="icon">
          <i class="bx bx-vector"></i>
          <div class="label">bx-vector</div>
        </div>
        <div class="icon">
          <i class="bx bx-vertical-center"></i>
          <div class="label">bx-vertical-center</div>
        </div>
        <div class="icon">
          <i class="bx bx-vial"></i>
          <div class="label">bx-vial</div>
        </div>
        <div class="icon">
          <i class="bx bx-video"></i>
          <div class="label">bx-video</div>
        </div>
        <div class="icon">
          <i class="bx bx-video-off"></i>
          <div class="label">bx-video-off</div>
        </div>
        <div class="icon">
          <i class="bx bx-video-plus"></i>
          <div class="label">bx-video-plus</div>
        </div>
        <div class="icon">
          <i class="bx bx-video-recording"></i>
          <div class="label">bx-video-recording</div>
        </div>
        <div class="icon">
          <i class="bx bx-voicemail"></i>
          <div class="label">bx-voicemail</div>
        </div>
        <div class="icon">
          <i class="bx bx-volume"></i>
          <div class="label">bx-volume</div>
        </div>
        <div class="icon">
          <i class="bx bx-volume-full"></i>
          <div class="label">bx-volume-full</div>
        </div>
        <div class="icon">
          <i class="bx bx-volume-low"></i>
          <div class="label">bx-volume-low</div>
        </div>
        <div class="icon">
          <i class="bx bx-volume-mute"></i>
          <div class="label">bx-volume-mute</div>
        </div>
        <div class="icon">
          <i class="bx bx-walk"></i>
          <div class="label">bx-walk</div>
        </div>
        <div class="icon">
          <i class="bx bx-wallet"></i>
          <div class="label">bx-wallet</div>
        </div>
        <div class="icon">
          <i class="bx bx-wallet-alt"></i>
          <div class="label">bx-wallet-alt</div>
        </div>
        <div class="icon">
          <i class="bx bx-water"></i>
          <div class="label">bx-water</div>
        </div>
        <div class="icon">
          <i class="bx bx-webcam"></i>
          <div class="label">bx-webcam</div>
        </div>
        <div class="icon">
          <i class="bx bx-wifi"></i>
          <div class="label">bx-wifi</div>
        </div>
        <div class="icon">
          <i class="bx bx-wifi-0"></i>
          <div class="label">bx-wifi-0</div>
        </div>
        <div class="icon">
          <i class="bx bx-wifi-1"></i>
          <div class="label">bx-wifi-1</div>
        </div>
        <div class="icon">
          <i class="bx bx-wifi-2"></i>
          <div class="label">bx-wifi-2</div>
        </div>
        <div class="icon">
          <i class="bx bx-wifi-off"></i>
          <div class="label">bx-wifi-off</div>
        </div>
        <div class="icon">
          <i class="bx bx-wind"></i>
          <div class="label">bx-wind</div>
        </div>
        <div class="icon">
          <i class="bx bx-window"></i>
          <div class="label">bx-window</div>
        </div>
        <div class="icon">
          <i class="bx bx-window-alt"></i>
          <div class="label">bx-window-alt</div>
        </div>
        <div class="icon">
          <i class="bx bx-window-close"></i>
          <div class="label">bx-window-close</div>
        </div>
        <div class="icon">
          <i class="bx bx-window-open"></i>
          <div class="label">bx-window-open</div>
        </div>
        <div class="icon">
          <i class="bx bx-windows"></i>
          <div class="label">bx-windows</div>
        </div>
        <div class="icon">
          <i class="bx bx-wine"></i>
          <div class="label">bx-wine</div>
        </div>
        <div class="icon">
          <i class="bx bx-wink-smile"></i>
          <div class="label">bx-wink-smile</div>
        </div>
        <div class="icon">
          <i class="bx bx-wink-tongue"></i>
          <div class="label">bx-wink-tongue</div>
        </div>
        <div class="icon">
          <i class="bx bx-won"></i>
          <div class="label">bx-won</div>
        </div>
        <div class="icon">
          <i class="bx bx-world"></i>
          <div class="label">bx-world</div>
        </div>
        <div class="icon">
          <i class="bx bx-wrench"></i>
          <div class="label">bx-wrench</div>
        </div>
        <div class="icon">
          <i class="bx bx-x"></i>
          <div class="label">bx-x</div>
        </div>
        <div class="icon">
          <i class="bx bx-x-circle"></i>
          <div class="label">bx-x-circle</div>
        </div>
        <div class="icon">
          <i class="bx bx-yen"></i>
          <div class="label">bx-yen</div>
        </div>
        <div class="icon">
          <i class="bx bx-zoom-in"></i>
          <div class="label">bx-zoom-in</div>
        </div>
        <div class="icon">
          <i class="bx bx-zoom-out"></i>
          <div class="label">bx-zoom-out</div>
        </div>

      </div>

    </section>

  </main><!-- End #main -->

  <!-- ======= Footer ======= -->
  <footer id="footer" class="footer">
    <div class="copyright">
      &copy; Copyright <strong><span>NiceAdmin</span></strong>. All Rights Reserved
    </div>
    <div class="credits">
      <!-- All the links in the footer should remain intact. -->
      <!-- You can delete the links only if you purchased the pro version. -->
      <!-- Licensing information: https://bootstrapmade.com/license/ -->
      <!-- Purchase the pro version with working PHP/AJAX contact form: https://bootstrapmade.com/nice-admin-bootstrap-admin-html-template/ -->
      Designed by <a href="https://bootstrapmade.com/">BootstrapMade</a>
    </div>
  </footer><!-- End Footer -->

  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  <!-- Vendor JS Files -->
  <script src="assets/vendor/apexcharts/apexcharts.min.js"></script>
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/chart.js/chart.umd.js"></script>
  <script src="assets/vendor/echarts/echarts.min.js"></script>
  <script src="assets/vendor/quill/quill.min.js"></script>
  <script src="assets/vendor/simple-datatables/simple-datatables.js"></script>
  <script src="assets/vendor/tinymce/tinymce.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>

  <!-- Template Main JS File -->
  <script src="assets/js/main.js"></script>

</body>

</html>